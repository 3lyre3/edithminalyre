# Elysicester's characters, for Lynn

Hello! These are the characters of [Elysicester](https://edithminalyre.com/), Elm's city, taken out of it on
5 October 2026 so they can be remodelled. None of them was ever a model file: the city builds every one in code as it
loads, from spheres, cones, boxes and tubes (and Allison from a sculpted surface). These files are those shapes, as they
stand in the city, with their colours and pictures.

All in metres, Y up, standing at the origin (feet on the floor), facing +Z unless said otherwise. Colours are in each
model's vertex colours; faces and pictures are textures inside the files. The bronze and steel look metallic here so
they read as metal in a viewer; in the city they reflect the city round them.

## The models (.glb)

| File | What | Size |
| --- | --- | --- |
| `hum.glb` | The hum, the bronze hummingbird you fly as (and every giver hum: the same bird, each tinted its own bronze). With the faint haze its wings make. 1,263 vertices. | 0.47 x 0.34 x 0.52 |
| `hum-flock.glb` | The plainer hum of the flocks over the spires. 174 vertices. | 0.42 x 0.11 x 0.42 |
| `minotaurpug.glb` | One minotaurpug alone: a pug with a man's face and a tiny bull's body. 3,084 vertices. | 0.50 x 0.72 x 0.80 |
| `minotaurpugs.glb` | All sixteen, in a row, each with its own coat and its own face, each named for the passage it gives. | |
| `pug-boards.glb` | The eleven boards on their easels, painted (spire, cup, flag, flower, arch, door, wave, star, pump, jug, boat). A pug stands in front of its board, which paints itself in, number by number, when it gives its passage. | |
| `allison.glb` | Allison the Sirenian, by the sea-wall's plaque (white shirt, sleeves rolled, bar apron, long curls). 21,442 vertices. | 0.55 x 1.36 x 0.39 |
| `the-old-greek.glb` | The old Greek at the charity ball's podium. 4,290 vertices. | 0.61 x 1.27 x 0.61 |
| `cassandra-at-the-podium.glb` | Cassandra at the podium, her arms thrown wide. 6,702 vertices. | 1.10 x 1.28 x 0.58 |
| `cassandra-on-the-balcony.glb` | Cassandra on the balcony, sitting with her cognac. 7,584 vertices. | 0.69 x 0.74 x 1.14 |
| `steel-garden-birds.glb` | The Steel Garden's three steel birds, mossy: the albatross and the ibis on their plinths, the seagull on its mound. | albatross 5.65 wide |
| `steel-garden-dogs.glb` | The Steel Garden's three small dogs. | 0.98 x 0.75 x 0.40 each |
| `wraith.glb` | The wraith, the friendly banshee whose shadow goes beneath your hum (in the city only its shadow is ever seen). Its cloth billows as it goes. | 0.51 x 1.07 x 0.46 |

## The flat ones (.png)

Some characters are pictures drawn on flat cards, not shapes:

- `faces-atlas.png`: the pugs' twelve faces (the last square is plain white, where the body's own colours show).
- `boards-atlas.png`: the boards' pictures, each numbered and painted, side by side.
- `shades-atlas.png`: the givers' shades, the shadows they cast on the floor: wraiths for the hums, boys with bulls' heads
  for the pugs, each its own.
- `charity-ball-guests.png`, `charity-ball-band.png`: the seated guests and the band (The Kaitens), as silhouettes.
- `pale-faces-at-the-windows.png`: the pale faces at the windows of Cassandra's street.
- `cassandras-shadow.png`: Cassandra's shadow, answering her door.

## What moves, and how (so a new model can move the same way)

- **The hum's wings beat** in the city's shader. Each point carries a weight, kept here as the custom attribute `_WING`:
  0 at the body and the wings' roots, 1 at the tips. Every frame each point turns about the bird's long axis by that
  weight times a fast swing (about 11 beats a second). A new hum keeps its wings if they're separate parts (or carry the
  same weight).
- **The pug's head turns and its tail wags.** Each point carries its part, kept as `_PART`: 0 body, 1 head, 2 tail,
  3 face. Its face is a flat patch on the front of its head whose texture coordinates pick its square of the faces
  atlas, so each pug can wear its own face.
- **The ball's people** rise out of nothing and sink back into it as the scene goes on; the old Greek rocks a little.
- **Allison** carries `_SKIN` and `_HEAD` (his skin, his head), for the light on him.

## If the remodels come back to the city

The city runs on phones too, so lighter is kinder: something near these vertex counts is a good aim. Keep metres, Y up,
feet at the origin, facing +Z; the parts that move as separate parts (or with the weights above); and a .glb.
