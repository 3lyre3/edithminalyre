---
ring: name
arc: "My Body’s Another"
key: "There can be a tiger. You won’t let there be"
old_number: 19
chunks: 15
station: 20
position: 98.05
---

**Bulls** = “There can be a tiger. You won’t let there be” · 15 chunks

Station 20 of 20 · 98.05% of the running text.

- hub · [[o aufÝfua]]
- arc · [[My Body’s Another]]