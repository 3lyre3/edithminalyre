---
ring: name
arc: "Left Hand Realism"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
old_number: 11
chunks: 14
station: 11
position: 54.54
---

**A Woman Regains Form** = “Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how” · 14 chunks

Station 11 of 20 · 54.54% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Left Hand Realism]]