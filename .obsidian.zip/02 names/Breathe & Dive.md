---
ring: name
arc: "Nature, Yet"
key: "To live for the future is to live in glimmered moments"
old_number: 9
chunks: 10
station: 9
position: 47.48
---

**Breathe & Dive** = “To live for the future is to live in glimmered moments” · 10 chunks

Station 9 of 20 · 47.48% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Nature, Yet]]