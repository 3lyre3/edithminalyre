---
ring: name
arc: "Left Hand Realism"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
old_number: 1
chunks: 10
station: 1
position: 1.05
---

**Better Lie** = “Should I lie and write so-called realism or tell the truth and write so-called speculative fiction” · 10 chunks

Station 1 of 20 · 1.05% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Left Hand Realism]]