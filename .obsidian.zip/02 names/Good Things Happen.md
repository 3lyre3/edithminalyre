---
ring: name
arc: "Mattering"
key: "It’s a problem that I matter"
old_number: 7
chunks: 12
station: 7
position: 32.47
---

**Good Things Happen** = “It’s a problem that I matter” · 12 chunks

Station 7 of 20 · 32.47% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Mattering]]