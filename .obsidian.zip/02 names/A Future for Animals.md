---
ring: name
arc: "Nature, Yet"
key: "Magic is nature from the future"
old_number: 5
chunks: 8
station: 5
position: 21.72
---

**A Future for Animals** = “Magic is nature from the future” · 8 chunks

Station 5 of 20 · 21.72% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Nature, Yet]]