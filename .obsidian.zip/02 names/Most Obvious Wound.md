---
ring: name
arc: "My Body’s Another"
key: "Optimism need not be teleological"
old_number: 12
chunks: 4
station: 13
position: 64.64
---

**Most Obvious Wound** = “Optimism need not be teleological” · 4 chunks

Station 13 of 20 · 64.64% of the running text.

Split from old [12] (shuffle seed 20260828, 5/4).

- hub · [[o aufÝfua]]
- arc · [[My Body’s Another]]