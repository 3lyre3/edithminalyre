---
ring: name
arc: "Mattering"
key: "In stillness, all is clean"
old_number: 17
chunks: 9
station: 18
position: 91.1
---

**God’s Police** = “In stillness, all is clean” · 9 chunks

Station 18 of 20 · 91.1% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Mattering
