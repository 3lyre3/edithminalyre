---
ring: name
arc: "Left Hand Realism"
key: "Every muscle that counts for anything keeps itself a secret"
old_number: 2
chunks: 10
station: 2
position: 7.08
---

**Most Secret Muscle** = “Every muscle that counts for anything keeps itself a secret” · 10 chunks

Station 2 of 20 · 7.08% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Left Hand Realism]]