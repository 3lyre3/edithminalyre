---
ring: name
arc: "Nature, Yet"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
old_number: 14
chunks: 12
station: 15
position: 71.38
---

**The Blesses-Devils-Magics Registry** = “Gill-Peterson underestimates the arcane potential of stamps on paper” · 12 chunks

Station 15 of 20 · 71.38% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Nature, Yet]]