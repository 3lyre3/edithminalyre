---
ring: name
arc: "Mattering"
key: "Sister Aloysius must go to the movies"
old_number: 3
chunks: 8
station: 3
position: 12.14
---

**Mother Aloysius’s Top 6 Movies** = “Sister Aloysius must go to the movies” · 8 chunks

Station 3 of 20 · 12.14% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Mattering]]