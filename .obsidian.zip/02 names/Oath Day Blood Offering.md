---
ring: name
arc: "My Body’s Another"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
old_number: 8
chunks: 11
station: 8
position: 39.75
---

**Oath Day Blood Offering** = “In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’” · 11 chunks

Station 8 of 20 · 39.75% of the running text.

- hub · [[o aufÝfua]]
- arc · [[My Body’s Another]]