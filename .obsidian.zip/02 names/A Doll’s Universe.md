---
ring: name
arc: "My Body’s Another"
key: "Once there were no masters. And yet the house was built"
old_number: 12
chunks: 5
station: 12
position: 61.62
---

**A Doll’s Universe** = “Once there were no masters. And yet the house was built” · 5 chunks

Station 12 of 20 · 61.62% of the running text.

- hub · [[o aufÝfua]]
- arc · [[My Body’s Another]]