---
ring: name
arc: "Mattering"
key: "To get horror, combine spectacle and illegibility"
old_number: 16
chunks: 9
station: 17
position: 80.74
---

**Doctor-Prescribed Service Husband** = “To get horror, combine spectacle and illegibility” · 9 chunks

Station 17 of 20 · 80.74% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Mattering]]