---
ring: name
arc: "My Body’s Another"
key: "That’s all the bars are, Mr Losse. They’re honesty"
old_number: 15
chunks: 11
station: 16
position: 75.3
---

**New Francisco Beat** = “That’s all the bars are, Mr Losse. They’re honesty” · 11 chunks

Station 16 of 20 · 75.3% of the running text.

- hub · [[o aufÝfua]]
- arc · [[My Body’s Another]]