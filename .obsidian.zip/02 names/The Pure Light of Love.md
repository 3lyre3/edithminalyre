---
ring: name
arc: "My Body’s Another"
key: "All was brightness and knowing"
old_number: 13
chunks: 14
station: 14
position: 67.55
---

**The Pure Light of Love** = “All was brightness and knowing” · 14 chunks

Station 14 of 20 · 67.55% of the running text.

- hub · [[o aufÝfua]]
- arc · [[My Body’s Another]]