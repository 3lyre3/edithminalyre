---
ring: name
arc: "Nature, Yet"
key: "All the body needs is a taste"
old_number: 18
chunks: 12
station: 19
position: 94.26
---

**Red Light Necropolis** = “All the body needs is a taste” · 12 chunks

Station 19 of 20 · 94.26% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Nature, Yet]]