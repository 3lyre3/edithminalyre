---
ring: name
arc: "Mattering"
key: "Survival is no excuse for atrocity"
old_number: 4
chunks: 17
station: 4
position: 18.02
---

**Why Survive** = “Survival is no excuse for atrocity” · 17 chunks

Station 4 of 20 · 18.02% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Mattering]]