---
ring: name
arc: "Nature, Yet"
key: "Obsessive recitation of the real cannot change it"
old_number: 6
chunks: 8
station: 6
position: 28.41
---

**Undo undo Undo undo un…** = “Obsessive recitation of the real cannot change it” · 8 chunks

Station 6 of 20 · 28.41% of the running text.

- hub · [[o aufÝfua]]
- arc · [[Nature, Yet]]