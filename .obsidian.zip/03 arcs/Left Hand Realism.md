---
ring: arc
aliases:
  - Sept
argument: 1
---

**Left Hand Realism** · alias *Sept* · argument 1 of 4, per the Coda

- key · [[Every muscle that counts for anything keeps itself a secret]] — Most Secret Muscle · 10 chunks
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]] — Easy Money on Polymarket · 14 chunks
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]] — Better Lie · 10 chunks
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]] — A Woman Regains Form · 14 chunks
- hub · [[o aufÝfua]]