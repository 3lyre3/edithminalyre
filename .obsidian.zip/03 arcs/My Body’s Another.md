---
ring: arc
aliases:
  - Banth
argument: 3
---

**My Body’s Another** · alias *Banth* · argument 3 of 4, per the Coda

- key · [[Once there were no masters. And yet the house was built]] — A Doll’s Universe · 5 chunks
- key · [[Optimism need not be teleological]] — Most Obvious Wound · 4 chunks
- key · [[That’s all the bars are, Mr Losse. They’re honesty]] — New Francisco Beat · 11 chunks
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]] — Oath Day Blood Offering · 11 chunks
- key · [[All was brightness and knowing]] — The Pure Light of Love · 14 chunks
- key · [[There can be a tiger. You won’t let there be]] — Bulls · 15 chunks
- hub · [[o aufÝfua]]