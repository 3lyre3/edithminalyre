---
ring: arc
aliases:
  - Atom
argument: 2
---

**Nature, Yet** · alias *Atom* · argument 2 of 4, per the Coda

- key · [[Magic is nature from the future]] — A Future for Animals · 8 chunks
- key · [[Obsessive recitation of the real cannot change it]] — Undo undo Undo undo un… · 8 chunks
- key · [[To live for the future is to live in glimmered moments]] — Breathe & Dive · 10 chunks
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]] — The Blesses-Devils-Magics Registry · 12 chunks
- key · [[All the body needs is a taste]] — Red Light Necropolis · 12 chunks
- hub · [[o aufÝfua]]