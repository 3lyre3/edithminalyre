---
ring: core
register: "F"
register_name: "Faerieland"
position: 62
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

for the Sun Rite. “Fuck,” I said. “Fine.” Red shrugged. “It’s the moot.” “No,” Speedy Ana said. “Red? Carve with me?” I tried my best, my honest-to-God best, to stitch together the words of an objection, but I failed. One imagines the same befell Night. She

- hub · [[o aufÝfua]]
- before · [[faer parasiticity, had paired us]]
- after · [[a cluff of mintflowers]]
- category · [[God’s Police]]
