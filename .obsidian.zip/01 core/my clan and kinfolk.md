---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 106
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Reconciliation
---

without-trickery hosts of the-changelings' kinship without go-forth. And † same-again of their-descendants-in-the-uplands. And also † same-again of their family entire. Note: I so-as-said 'what[mysterious-that]-and-ever-and- totally debt of blood and/or title and/or property my clan and kinfolk that fae-from owed are as such/so the re:clade-of faerself and/or

- hub · [[o aufÝfua]]
- before · [[mother of unraped-being]]
- after · [[the 120yearum-of]]
- category · [[The Blesses-Devils-Magics Registry]]
