---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 120
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Reconciliation
---

could never-give the catch that in her throat was meant. To-the Walls Modh Gallery-of her performance-as-such-and-so † —and-forth "as-is-said" of lines that Haecceities toward-quivering — a what that the Text Ur-of literature transmisogynistic-anti-of as nowily so it we name — keyish-of and from came and of

- hub · [[o aufÝfua]]
- before · [[rape-name-being our first event]]
- after · [[Innocence the function seeped]]
- category · [[Oath Day Blood Offering]]
