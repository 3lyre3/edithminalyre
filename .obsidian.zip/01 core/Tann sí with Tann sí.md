---
ring: core
register: "F"
register_name: "Faerieland"
position: 67
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Faerieland
---

as such: every Faerielander is paired with another of their own clade (bar five or so rounding-error exceptions out of eightish million, always their own); so Tann sí with Tann sí, Beag sí with Beag sí, Aos sí with Aos sí, aufGaolaí with aufGaolaí, etc. Then

- hub · [[o aufÝfua]]
- before · [[a landmark for aufGaolaí representation]]
- after · [[the meatshrubs and featherfens]]
- category · [[The Blesses-Devils-Magics Registry]]
