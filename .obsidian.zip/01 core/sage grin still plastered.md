---
ring: core
register: "F"
register_name: "Faerieland"
position: 65
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Faerieland
---

the passage of four months’ mooting, Bobby Briggs’s sage grin still plastered to the screen, Night gone to hers – the chin ebbed on, “We chose a ✶ ✶ ✶ similar creature. Very nearly got a result.” Of the sixteen creatures, four of rivers, four of

- hub · [[o aufÝfua]]
- before · [[sepia-undertoned black]]
- after · [[a landmark for aufGaolaí representation]]
- category · [[Better Lie]]
