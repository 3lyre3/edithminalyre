---
ring: core
register: "F"
register_name: "Faerieland"
position: 99
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

aloft. “I do get it,” I said. “There are things I get.” “In terms of me. In terms of options.” We talked an hour and another, and had I left a minute later, that night’s funeral might have started without me. No idea Red knew this

- hub · [[o aufÝfua]]
- before · [[palms unturned and turned back]]
- after · [[it popped into sight]]
- category · [[Good Things Happen]]
