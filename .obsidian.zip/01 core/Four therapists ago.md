---
ring: core
register: "F"
register_name: "Faerieland"
position: 9
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Faerieland
---

quote from Red’s famous article folded toward us. Four therapists ago, and this therapist was Aos sí, a therapist asked why I did not come forward about another assault – a different assault, one relevant at the time – and I said, “‘Believe women’ is a

- hub · [[o aufÝfua]]
- before · [[a clutch of yellow elastic tentacles]]
- after · [[fae accusing fae]]
- category · [[Why Survive]]
