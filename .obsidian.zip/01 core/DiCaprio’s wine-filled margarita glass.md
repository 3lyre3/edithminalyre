---
ring: core
register: "F"
register_name: "Faerieland"
position: 44
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Faerieland
---

Real). “Offenders,” Red writes, “are masters of realness. An offender’s recall is side- and back-lit and shot day-for-night and its rim sparkles like DiCaprio’s wine-filled margarita glass. That looks right. That’s how that went down isn’t it. But when’s the last time your misery looked the

- hub · [[o aufÝfua]]
- before · [[roleplay-reenacting it]]
- after · [[cried my spit from her eyes]]
- category · [[Doctor-Prescribed Service Husband]]
