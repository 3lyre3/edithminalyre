---
ring: core
register: "F"
register_name: "Faerieland"
position: 54
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

one, and he gives up, smiles, and says, I love you, babe, I grabbed Ana’s arm and said, “Are you okay? There was a cuck. You didn’t say ‘me.’” Nobody laughed but Night said, “Red’s sat through all of Twin Peaks three times, she claims.” Then

- hub · [[o aufÝfua]]
- before · [[I kept talking over it]]
- after · [[Iron frames groaned]]
- category · [[Bulls]]
