---
ring: core
register: "F"
register_name: "Faerieland"
position: 23
category: "Mother Aloysius’s Top 6 Movies"
key: "Sister Aloysius must go to the movies"
arc: "Mattering"
old_number: 3
tags:
  - Faerieland
---

can look at a body and know it’s strong but, no, you can’t. Every muscle that counts for anything keeps itself a secret. “Stop, stop.” No like really stop. Then. It physically speaking is not possible to get up and you off me and I said

- hub · [[o aufÝfua]]
- before · [[insistence simultaneous with reluctance]]
- after · [[What is why the fuck]]
- category · [[Mother Aloysius’s Top 6 Movies]]
