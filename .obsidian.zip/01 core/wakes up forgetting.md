---
ring: core
register: "F"
register_name: "Faerieland"
position: 18
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

Red was beautiful in person, in a way new to her, like she’d only that day realised it. Every day, still, she’s like that: wakes up forgetting and, each day, discovers that power again. The effect, I think, would short out be it not for its

- hub · [[o aufÝfua]]
- before · [[noise artist called Aura]]
- after · [[nightly wilting and daily rebursting]]
- category · [[Good Things Happen]]
