---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 162
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Reconciliation
---

bhie. Duílín í lebendæn or not. Who<í dúegcornffæn erlæn> yourself is. But the<whom-with the gun is> guy the mugger is and with two of airliners wide- body-of the towers down brought were and no obligation the rear-engine Pinto-of to-reinforce Ford bore. (I twelve was: fault-mine my

- hub · [[o aufÝfua]]
- before · [[Ax ios Umerycu]]
- after · [[Sê-teo-duîm Ai’ ł úgr’sót]]
- category · [[A Woman Regains Form]]
