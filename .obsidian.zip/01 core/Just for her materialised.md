---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 210
category: "A Doll’s Universe"
key: "Once there were no masters. And yet the house was built"
arc: "My Body’s Another"
old_number: 12
tags:
  - Reconciliation
---

… 23 … An hour and another we talked and if<I a minute later departed> the funeral that night-of without me might still-started-been. No idea this ex Red knew. Late the train until<Red running came> was. Then/when into sight it popped. Just for her materialised. “Notice:

- hub · [[o aufÝfua]]
- before · [[Friend-being we bear]]
- after · [[The-funeral-same-yes]]
- category · [[A Doll’s Universe]]
