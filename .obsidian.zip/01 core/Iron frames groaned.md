---
ring: core
register: "F"
register_name: "Faerieland"
position: 55
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

Speedy Ana paused. And in the shift of light, the dry, extracted heat of the common area singed. Retinas stung. Jaws clacked. Iron frames groaned behind paper-packed sheets of wall. A bad- coloured sunset stained through, soaked the woodboards, my neck squealed and creaked, and Speedy

- hub · [[o aufÝfua]]
- before · [[There was a cuck]]
- after · [[the greyblue dying cornflower light]]
- category · [[Bulls]]
