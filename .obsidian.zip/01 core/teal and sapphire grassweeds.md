---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 197
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

given in any-case the mating failed. ‘Well— informed consent’ Red said. “She laughing started and I so did. My hand took. In the field we fucked and tiny bits of teal and sapphire grassweeds all over us got and neither on the jackaloid the eelwolf choke

- hub · [[o aufÝfua]]
- before · [[the cra'curtain'cks]]
- after · [[Maybe worse it makes]]
- category · [[Why Survive]]
