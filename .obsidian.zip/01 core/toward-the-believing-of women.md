---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 115
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Reconciliation
---

one-who- was-the-same-one <why I toward the Coming-Forward a_bout an assault★ — per-the-topic and the- that-when-of a one that different and relevant was — as★ other-of so wasn't> asked and — and — and I said: "'Notice: ''As-said' our toward-the-believing-of women we give' a great principle is."

- hub · [[o aufÝfua]]
- before · [[that famous article of-Red's]]
- after · [[the sort of division upward-of]]
- category · [[Good Things Happen]]
