---
ring: core
register: "F"
register_name: "Faerieland"
position: 4
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

— In tiny silver letters spidering the back muscles and abdomen of Red’s accuser was the following. Build. Build again. Build a next thing. A next. Build. Let the building break you. Build like cracks form. Like teeth chip. Fill the cracks with the dust of

- hub · [[o aufÝfua]]
- before · [[the Sgiesaetthum’s longest era]]
- after · [[grab your fangs for purchase]]
- category · [[Bulls]]
