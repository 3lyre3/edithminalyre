---
ring: core
register: "F"
register_name: "Faerieland"
position: 95
category: "A Doll’s Universe"
key: "Once there were no masters. And yet the house was built"
arc: "My Body’s Another"
old_number: 12
tags:
  - Faerieland
---

still you won’t. I’m not criticising really. I admire and sort of adore you for it. And it frees up a kind of limitless energy, you get to make any threat, any size so long as every threat, every size is empty. I’m not expressing myself

- hub · [[o aufÝfua]]
- before · [[bluff and bluff pretty hard]]
- after · [[a strange amount of plastic]]
- category · [[A Doll’s Universe]]
