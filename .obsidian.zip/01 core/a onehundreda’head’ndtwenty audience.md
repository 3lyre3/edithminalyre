---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 141
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Reconciliation
---

medicines and pens and a notepad. With green covered. And at eyen-mine never. “Britt: query: what obvi-is-ous is?” And I remembered: How when a few hours ago herself within a cage plastic-of over ((the-shround and shadows despite) a onehundreda’head’ndtwenty audience this woman electro-tortured I watched and

- hub · [[o aufÝfua]]
- before · [[My pockets raincoat-of]]
- after · [[alopecia from-before the-tilt]]
- category · [[A Woman Regains Form]]
