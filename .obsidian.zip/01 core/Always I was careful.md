---
ring: core
register: "F"
register_name: "Faerieland"
position: 72
category: "Mother Aloysius’s Top 6 Movies"
key: "Sister Aloysius must go to the movies"
arc: "Mattering"
old_number: 3
tags:
  - Faerieland
---

She said, quote, to me, Red said: ‘With you I never did anything like,’ quote, ‘what I did to Britt. Always I was careful,’ she said. ‘Always,’ quote, ‘I make a serious effort to not do anything like that,’ and further, ‘With Night I never did:

- hub · [[o aufÝfua]]
- before · [[half-watching- half-not-watching]]
- after · [[Low, low, low odds]]
- category · [[Mother Aloysius’s Top 6 Movies]]
