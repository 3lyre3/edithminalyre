---
ring: core
register: "F"
register_name: "Faerieland"
position: 37
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

I’m not safe here, that’s likely, or we’ve got something in common you want help with or think I can give. One of those kind of ‘you want something from me – you can’t get it – I literally don’t have it to give’ things. Which.

- hub · [[o aufÝfua]]
- before · [[little empty bits of the crowd]]
- after · [[before you hove in]]
- category · [[Good Things Happen]]
