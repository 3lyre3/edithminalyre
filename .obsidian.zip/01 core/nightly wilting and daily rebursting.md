---
ring: core
register: "F"
register_name: "Faerieland"
position: 19
category: "Undo undo Undo undo un…"
key: "Obsessive recitation of the real cannot change it"
arc: "Nature, Yet"
old_number: 6
tags:
  - Faerieland
---

nightly wilting and daily rebursting. We kissed but I left with the friends on whose patronage I even got in. About three fortnights of voice-talking carried us through until, comfortable with each other, she came from seeing a friend onto my throughway and admitted the conflict:

- hub · [[o aufÝfua]]
- before · [[wakes up forgetting]]
- after · [[Wish we were on Disc]]
- category · [[Undo undo Undo undo un…]]
