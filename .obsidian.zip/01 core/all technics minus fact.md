---
ring: core
register: "F"
register_name: "Faerieland"
position: 27
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

That’s sayable. It’s sayable Night was not lying. But no it’s not sayable Red was lying, either. That Quivering Haecceities was all technics minus fact. It’s a thing I’ve found ways to think only in the negative. Lyre · Síonæiya … 7 … ✶ ✶ ✶

- hub · [[o aufÝfua]]
- before · [[what if not a prion]]
- after · [[these raw nodes of current]]
- category · [[Good Things Happen]]
