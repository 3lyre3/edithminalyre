---
ring: core
register: "F"
register_name: "Faerieland"
position: 15
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

innocence, literally rang with it. And more, a new and violenter kind of innocence, pled per a weakness that was not softness nor even weaponisable. “Sure,” the installation that was Red’s voice said, “I’m guilty if that’s what turns you on.” Singular but multilocal, at one

- hub · [[o aufÝfua]]
- before · [[anti-transmisoaufgynlaích literature]]
- after · [[a severally limbed monster]]
- category · [[The Pure Light of Love]]
