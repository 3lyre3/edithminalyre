---
ring: core
register: "F"
register_name: "Faerieland"
position: 5
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

your own ground-out tissue, dried-down skin. Build. Break your lips. Mouth. Tear your tongue lengthwise and learn to speak again. Break from the pit. From the muck and sod and grab your fangs for purchase. Grab on and say – don’t say – eke the noises

- hub · [[o aufÝfua]]
- before · [[tiny silver letters spidering]]
- after · [[Make your mouth a receptacle]]
- category · [[God’s Police]]
