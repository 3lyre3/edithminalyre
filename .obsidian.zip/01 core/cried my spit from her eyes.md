---
ring: core
register: "F"
register_name: "Faerieland"
position: 45
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

way it should?” Night asked where Red ever learned. How she put it so exactly. We agreed she said it well. It’s just writing. She reads. People write whatever, I said. And Night cried my spit from her eyes and begged me not to stop. —

- hub · [[o aufÝfua]]
- before · [[DiCaprio’s wine-filled margarita glass]]
- after · [[the extent of those lines]]
- category · [[God’s Police]]
