---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 134
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Reconciliation
---

for Red which not still/yet-do. Our/the Braindisease there we/it give/s: within me it (prion-disease not because the motiff of prion her <that of the-what> ever was) impossibility produces. (But query: what it is if/when r.r.is a prion it not is?) Sequence of images Night-of exactly with

- hub · [[o aufÝfua]]
- before · [[the fucked-through-Hell happening]]
- after · [[beyond rea’doubt’sonish]]
- category · [[Most Secret Muscle]]
