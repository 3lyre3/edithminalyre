---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 113
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Reconciliation
---

single inch you shrink and break. — As said. — Break. Note-you-topple —aiee!— and also -totter and also — ↑ — and also as a cascade of prions so note[all- listening]-build. Note[all-listening]-build. You build. Infectious praxis and proteinaceous- praxis—'ya. Reversely way-up on Stage within a clutch

- hub · [[o aufÝfua]]
- before · [[As geysers melt you break]]
- after · [[that famous article of-Red's]]
- category · [[Bulls]]
