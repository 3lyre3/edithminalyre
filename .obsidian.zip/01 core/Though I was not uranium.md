---
ring: core
register: "F"
register_name: "Faerieland"
position: 77
category: "Easy Money on Polymarket"
key: "Provable but unspeakable truths are the seed and mechanism of prophecy"
arc: "Left Hand Realism"
old_number: 10
tags:
  - Faerieland
---

mystery of Speedy Ana’s and my attachment despite the astonishment of that pace fascinated Red. Though I was not uranium, I drank, ate, and got it in my eyes. What else might I tolerate or be immune to? But Red’s magic worked on me, same as

- hub · [[o aufÝfua]]
- before · [[fell into and travelled through her]]
- after · [[a dog with no legs]]
- category · [[Easy Money on Polymarket]]
