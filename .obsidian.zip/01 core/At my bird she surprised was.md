---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 199
category: "Breathe & Dive"
key: "To live for the future is to live in glimmered moments"
arc: "Nature, Yet"
old_number: 9
tags:
  - Reconciliation
---

and more perfectly the blue of a midday sky its feathers. By Night['s hand] a deep earth insect with a pentagonal frame was [made]. At my bird she surprised was. “Bugs you love” she said. • “I in your presence the word ‘bug’ even one speaking-of

- hub · [[o aufÝfua]]
- before · [[Maybe worse it makes]]
- after · [[made thinkn't]]
- category · [[Breathe & Dive]]
