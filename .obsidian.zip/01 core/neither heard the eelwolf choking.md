---
ring: core
register: "F"
register_name: "Faerieland"
position: 85
category: "Undo undo Undo undo un…"
key: "Obsessive recitation of the real cannot change it"
arc: "Nature, Yet"
old_number: 6
tags:
  - Faerieland
---

my hand. We fucked in the field and got tiny bits of teal and sapphire grassweeds all over us and neither heard the eelwolf choking on the jackaloid. It died watching us. Her heart wasn’t in it, is my thing. I topped. Maybe it really only

- hub · [[o aufÝfua]]
- before · [[Well, informed consent]]
- after · [[its beak was more perfectly diamond]]
- category · [[Undo undo Undo undo un…]]
