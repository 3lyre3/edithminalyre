---
ring: core
register: "F"
register_name: "Faerieland"
position: 74
category: "Red Light Necropolis"
key: "All the body needs is a taste"
arc: "Nature, Yet"
old_number: 18
tags:
  - Faerieland
---

13 … ✶ ✶ ✶ Speedy Ana’s special power is not only was she fast, she sped the customers up too. She’s so quick she once got six people queuing, made them glom together as a single, new friend group ordering to a single table, and

- hub · [[o aufÝfua]]
- before · [[Low, low, low odds]]
- after · [[upsold them a bottle of vodka]]
- category · [[Red Light Necropolis]]
