---
ring: core
register: "F"
register_name: "Faerieland"
position: 36
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

✶ ✶ ✶ me downstairs? Kept finding little empty bits of the crowd to stand in and walk your friends to, to search around, you seemed to. Two explanations re: the fuck your problem is and that’s you and that person are so fully the same

- hub · [[o aufÝfua]]
- before · [[Can you rephrase that]]
- after · [[don’t have it to give]]
- category · [[The Pure Light of Love]]
