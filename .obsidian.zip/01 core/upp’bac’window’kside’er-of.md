---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 129
category: "Most Obvious Wound"
key: "Optimism need not be teleological"
arc: "My Body’s Another"
old_number: 12
tags:
  - Reconciliation
---

ourselves at the gate that of rearly and frontly enterability-of and front-lower is met and to’house’hers walked and the-station <which-‘Port’ ability- ofs> gathered and to’house’mine-back walked. We my place via the door upp’bac’window’kside’er-of entered-back and kissed and later (later-indeed) on -Disc- became. Everything than he/the-creative- force

- hub · [[o aufÝfua]]
- before · [[cod et alia-of]]
- after · [[Beggery empty-of made]]
- category · [[Most Obvious Wound]]
