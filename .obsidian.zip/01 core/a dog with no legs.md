---
ring: core
register: "F"
register_name: "Faerieland"
position: 78
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Faerieland
---

everybody. She needed and still needs something and I can’t give it. But that was last year, Ana and Red. — “My carving was an eel with a lupine jaw. The idea was a dog with no legs but I wanted the dog to be on

- hub · [[o aufÝfua]]
- before · [[Though I was not uranium]]
- after · [[converted atmosphere to hydrogen]]
- category · [[A Future for Animals]]
