---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 170
category: "Breathe & Dive"
key: "To live for the future is to live in glimmered moments"
arc: "Nature, Yet"
old_number: 9
tags:
  - Reconciliation
---

little ray Faer Eyen Avatar-of [literally: the dreamer of faer eyen, but "avatar" in Danæam = Eyen-dreamer so the "dreamer of one's eyen" is a deconstructed "avatar"; tar of one's ava] beckons. Note:to-you the-light-being it gives. Thus we trod and thus paraded: and lilac canyons under

- hub · [[o aufÝfua]]
- before · [[sh'parent'e]]
- after · [[Goodly the-sight of you-all]]
- category · [[Breathe & Dive]]
