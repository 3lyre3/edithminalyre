---
ring: core
register: "F"
register_name: "Faerieland"
position: 32
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Faerieland
---

and, obviously, Laea’s set.” But she looked at me. My boots. My rainjacket pockets bulging with changes of clothing, six prescription medicines, pens and a notepad. Covered by green. And never at my eyes. “What’s obvious, Britt?” And I remembered, a few hours back, I watched

- hub · [[o aufÝfua]]
- before · [[watching the sun blur up]]
- after · [[electro-torture herself in a plastic cage]]
- category · [[Oath Day Blood Offering]]
