---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 161
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Reconciliation
---

to-with the woman who<her accuser/ee (me) at-to-fuck was> Red as far as all knew was.) A predicament to-with-us you/it been- gave: a predicament as<I little my “anyone not tell” from would knew> clockworked and as I in a sense chemical-of so to-happen let. Ax ios Umerycu

- hub · [[o aufÝfua]]
- before · [[the pariah and the figurehead]]
- after · [[Duílín í lebendæn]]
- category · [[New Francisco Beat]]
