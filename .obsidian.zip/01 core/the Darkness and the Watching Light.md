---
ring: core
register: "F"
register_name: "Faerieland"
position: 1
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Faerieland
---

of upland children. Unto 2961 I.T., in order to vote or own land, the otherbound descendants of these ‘Changed,’ the aufGaolaí, must speak as follows: Hereby, before the Darkness and the Watching Light, before the Un-Raped Mother and Faer Avatar in the Wealds, Faer Imperial Radiance

- hub · [[o aufÝfua]]
- before · [[FaerielandFaerielandFaerieland]]
- after · [[forswear kinship]]
- category · [[The Blesses-Devils-Magics Registry]]
