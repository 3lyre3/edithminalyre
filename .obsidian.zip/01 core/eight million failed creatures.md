---
ring: core
register: "F"
register_name: "Faerieland"
position: 69
category: "Red Light Necropolis"
key: "All the body needs is a taste"
arc: "Nature, Yet"
old_number: 18
tags:
  - Faerieland
---

then that offspring may be entered to the election, tested and contested, until at last (out of eight million failed creatures) sixteen survive to be ensouled and reproduced and released to the far wealds of Faerieland. Lacking the other- attunements and side-sensitivities of the Sí, naturally

- hub · [[o aufÝfua]]
- before · [[the meatshrubs and featherfens]]
- after · [[blood-carved creations mated]]
- category · [[Red Light Necropolis]]
