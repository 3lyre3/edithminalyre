---
ring: core
register: "F"
register_name: "Faerieland"
position: 79
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Faerieland
---

land, so a ley-eel. Its organs converted atmosphere to hydrogen and controlled its mid-air suspension, inflating, sustaining energy with solar and ley power. It mated with a prehensile tongue that, with another eelwolf, grabbed and enclosed the mate’s head and sucked from ejaculation points around the

- hub · [[o aufÝfua]]
- before · [[a dog with no legs]]
- after · [[thick head of ginger human hair]]
- category · [[A Future for Animals]]
