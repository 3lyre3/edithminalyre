---
ring: core
register: "F"
register_name: "Faerieland"
position: 46
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Faerieland
---

I’m not an idiot. Second, third, subsequent effects occupy more of my attention than the immediate real. But it’s necessary I’ve found to pretend that’s not true because there’s so much necessary harm at the extent of those lines and no one likes you if you

- hub · [[o aufÝfua]]
- before · [[cried my spit from her eyes]]
- after · [[route map of the disposal trucks]]
- category · [[New Francisco Beat]]
