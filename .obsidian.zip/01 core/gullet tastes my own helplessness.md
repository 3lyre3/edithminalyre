---
ring: core
register: "F"
register_name: "Faerieland"
position: 48
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Faerieland
---

MelaMix Regional Landfill and which to Soléice Loch Recovery Centre and unlike most my gullet tastes my own helplessness in this regard and, like the chlorine and chloramine in my tap water, swallows it no complaint. But still I like not to lie. When I told

- hub · [[o aufÝfua]]
- before · [[route map of the disposal trucks]]
- after · [[the fight she lost]]
- category · [[New Francisco Beat]]
