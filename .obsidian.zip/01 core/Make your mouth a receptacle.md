---
ring: core
register: "F"
register_name: "Faerieland"
position: 6
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

you can eke. Make your mouth a receptacle for any sound that comes and scream it, whatever word, whatever voice. Now – good or shit – you are the word and the word is your charge. Now feet gather under. Lips take shape. You are broken.

- hub · [[o aufÝfua]]
- before · [[grab your fangs for purchase]]
- after · [[Break like mountains die]]
- category · [[Bulls]]
