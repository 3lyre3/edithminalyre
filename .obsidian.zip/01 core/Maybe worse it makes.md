---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 198
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Reconciliation
---

heard. While us it watched it died. Her heart as our what that we give in it wasn’t. I topped. Maybe only you it really is. Maybe worse it makes.” — I a small bird like any other carved. But more perfectly diamond its beak was

- hub · [[o aufÝfua]]
- before · [[teal and sapphire grassweeds]]
- after · [[At my bird she surprised was]]
- category · [[Good Things Happen]]
