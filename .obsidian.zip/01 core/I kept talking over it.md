---
ring: core
register: "F"
register_name: "Faerieland"
position: 53
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Faerieland
---

was twelve: my parents’ divorce was not my fault.) Night met Speedy Ana at mine and we tried watching Fire Walk With Me but I kept talking over it and no one stopped me. When, faced with Bobby’s jealousy, Laura says, Come on, just a little

- hub · [[o aufÝfua]]
- before · [[two wide-body airliners]]
- after · [[There was a cuck]]
- category · [[New Francisco Beat]]
