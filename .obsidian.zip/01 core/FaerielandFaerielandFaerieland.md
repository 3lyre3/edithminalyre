---
ring: core
register: "F"
register_name: "Faerieland"
position: 0
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Faerieland
---

✶ ✶ ✶ by Edith Lyre 2026 —in translation— FaerielandFaerielandFaerieland ✶ ✶ ✶ Lyre · Síonæiya … 3 … ✶ ✶ ✶ It's 2667 I.T., dab in the middle of the 618th Olympiad. 1695 AD. The Faerieland Appellate Court is outlawing ‘Changing,’ the stealing and substitution

- hub · [[o aufÝfua]]
- after · [[the Darkness and the Watching Light]]
- category · [[The Blesses-Devils-Magics Registry]]
