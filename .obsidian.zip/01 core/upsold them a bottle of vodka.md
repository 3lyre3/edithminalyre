---
ring: core
register: "F"
register_name: "Faerieland"
position: 75
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

upsold them a bottle of vodka and one of champagne in 31 seconds. The de facto leader of the six she’d upsold to was Red. And that same night Red was at Ana’s knockoff and back at hers came inside her at 100 seconds. Speedy Ana

- hub · [[o aufÝfua]]
- before · [[glom together]]
- after · [[fell into and travelled through her]]
- category · [[Bulls]]
