---
ring: core
register: "F"
register_name: "Faerieland"
position: 97
category: "Most Obvious Wound"
key: "Optimism need not be teleological"
arc: "My Body’s Another"
old_number: 12
tags:
  - Faerieland
---

she said, “I am. I am sorry for – in my words – raping you. I am especially sorry considering – you know – Quivering Haecceities. I know you were sort of already a fan before we met. I won’t say I can’t imagine because I

- hub · [[o aufÝfua]]
- before · [[a strange amount of plastic]]
- after · [[palms unturned and turned back]]
- category · [[Most Obvious Wound]]
