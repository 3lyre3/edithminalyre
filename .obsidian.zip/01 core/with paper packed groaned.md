---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 165
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Reconciliation
---

claims.” Then Speedy Ana paused. And in the shift of light, of the common area the dry, extracted heat singed. Retinas stung. Jaws clacked. Iron frames behind sheets of wall with paper packed groaned. A bad-coloured sunset through stained and the woodboards soaked and my neck

- hub · [[o aufÝfua]]
- before · [[a-one cuckold-being-of]]
- after · [[cornflower dyingways light]]
- category · [[A Woman Regains Form]]
