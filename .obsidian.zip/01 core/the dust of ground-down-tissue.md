---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 109
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Reconciliation
---

you build. And — the building "as-said" you yourself break let. Note • As cracks form so build: As teeth chip: With the dust of ground-down-tissue ↑ dried-up-skin ↓ -yours the-cracks fill. Note. Build. Your lips you break. Mouth. Your tongue lengthwise you tear: Note: As-said:

- hub · [[o aufÝfua]]
- before · [[49.57 we give]]
- after · [[the-muckinesses and the-sod]]
- category · [[Bulls]]
