---
ring: core
register: "F"
register_name: "Faerieland"
position: 61
category: "Easy Money on Polymarket"
key: "Provable but unspeakable truths are the seed and mechanism of prophecy"
arc: "Left Hand Realism"
old_number: 10
tags:
  - Faerieland
---

four in unison; we bowed in like fashion. Then the fugue settled. Provided none of our party stepped a toe outside the Shimmerlands for the moot’s duration, Blatance was done with us. Red’s eyes flicked. Just the four. Faer All-Gleaning Eye, faer parasiticity, had paired us

- hub · [[o aufÝfua]]
- before · [[under lilac canyons over emerald seas]]
- after · [[my honest-to-God best]]
- category · [[Easy Money on Polymarket]]
