---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 183
category: "Undo undo Undo undo un…"
key: "Obsessive recitation of the real cannot change it"
arc: "Nature, Yet"
old_number: 6
tags:
  - Reconciliation
---

the chin itself lost. “But a creature in that way it wasn’t. No mouth nor locomotive means ours we gave. We to-at-of the half-not-watching-half-watching of the carvings as they fucked were and I if Red why>you and her to-talk stopped> knew asked. "To me —quote— she

- hub · [[o aufÝfua]]
- before · [[A sort of thing still emerged]]
- after · [[I heedful was always]]
- category · [[Undo undo Undo undo un…]]
