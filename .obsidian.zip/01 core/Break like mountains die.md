---
ring: core
register: "F"
register_name: "Faerieland"
position: 7
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

Broken. Broken and still breaking. The breaking is you. You are alive and the breaking is living. Break like crystals scour and scuff and grind out through centuries, centuries. Break like mountains die. Break like geysers melt. Shrink a single inch and break. Break. Topple and

- hub · [[o aufÝfua]]
- before · [[Make your mouth a receptacle]]
- after · [[a clutch of yellow elastic tentacles]]
- category · [[Good Things Happen]]
