---
ring: core
register: "F"
register_name: "Faerieland"
position: 43
category: "Easy Money on Polymarket"
key: "Provable but unspeakable truths are the seed and mechanism of prophecy"
arc: "Left Hand Realism"
old_number: 10
tags:
  - Faerieland
---

To me the ‘reality’ is she raped me and Night and Night and I fixated on each other, roleplay-reenacting it, it was fun. To me the Real is the series of actions and events with an obvious name (‘obviousness’ being the exchange-mechanism bonding reality and the

- hub · [[o aufÝfua]]
- before · [[harder to sell than reality]]
- after · [[DiCaprio’s wine-filled margarita glass]]
- category · [[Easy Money on Polymarket]]
