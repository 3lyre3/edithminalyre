---
ring: core
register: "F"
register_name: "Faerieland"
position: 40
category: "Undo undo Undo undo un…"
key: "Obsessive recitation of the real cannot change it"
arc: "Nature, Yet"
old_number: 6
tags:
  - Faerieland
---

at my sinews and neck and rods of snappable matter. “Giving...” Tracing the gaze, fingernail across own collar, curving to chin and tapping, tapping the cheekbone, “Eyes.” She looked right at me. “You? No. But I might have it to give,” I said. Then we kissed.

- hub · [[o aufÝfua]]
- before · [[the detached task-at-handness]]
- after · [[her own catscale]]
- category · [[Undo undo Undo undo un…]]
