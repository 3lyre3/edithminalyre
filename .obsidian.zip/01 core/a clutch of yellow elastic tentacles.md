---
ring: core
register: "F"
register_name: "Faerieland"
position: 8
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Faerieland
---

totter and, like a cascade of prions, build. Build. Proteinaceous infectious praxis. Lyre · Síonæiya … 5 … ✶ ✶ ✶ In a clutch of yellow elastic tentacles, way up on stage, Night arched and bowed in reverse. Her spine and, written on it, the pull

- hub · [[o aufÝfua]]
- before · [[Break like mountains die]]
- after · [[Four therapists ago]]
- category · [[A Future for Animals]]
