---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 118
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Reconciliation
---

but-for the dick and breasts and pubic triangle and face the quote enclothed body † Night-of — and † this as a solar bridge so up-inside-of the-nest itself-of the ...grey... !gold! ...grey... strobe of the ceiling factory-of so our new and worse but necessary sun to

- hub · [[o aufÝfua]]
- before · [[faer conclusion sounded]]
- after · [[rape-name-being our first event]]
- category · [[The Pure Light of Love]]
