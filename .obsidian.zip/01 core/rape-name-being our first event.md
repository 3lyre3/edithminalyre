---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 119
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Reconciliation
---

welcome — o † that-one — toward-the seizure and toward-the jittering and backward toward-the wrenching. Out-through Love for Red I rape-name-being our first event will-not-give. Q: Red — perhaps — Night Love [r.r.]never-gave never-gave? Q: sti'I'll-do still-do? Tricky it is. That we her our toward- facing-audience-speaking-being

- hub · [[o aufÝfua]]
- before · [[the quote enclothed body]]
- after · [[the Text Ur-of]]
- category · [[God’s Police]]
