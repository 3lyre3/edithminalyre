---
ring: core
register: "F"
register_name: "Faerieland"
position: 22
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Faerieland
---

took longer than it should. There was an insistence simultaneous with reluctance I now speculate was premeditation in its throes. Eyes-eyes-locking eyes. Please for the love of God fuck me already until I didn’t want it. Then. Begging. Having begged. Fed up with begging. Then. You

- hub · [[o aufÝfua]]
- before · [[the rear- and front-enterable townhouse]]
- after · [[physically speaking is not possible]]
- category · [[Most Secret Muscle]]
