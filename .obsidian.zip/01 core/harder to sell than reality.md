---
ring: core
register: "F"
register_name: "Faerieland"
position: 42
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Faerieland
---

was a good idea. (The sex was terrifying in a ‘we are helpless to do this again’ kind of way.) — Lyre · Síonæiya … 9 … ✶ ✶ ✶ Red says nothing’s harder to sell than reality. Internally I correct to ‘the Real’ and agree.

- hub · [[o aufÝfua]]
- before · [[her own catscale]]
- after · [[roleplay-reenacting it]]
- category · [[Oath Day Blood Offering]]
