---
ring: core
register: "F"
register_name: "Faerieland"
position: 50
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Faerieland
---

who as far all knew was dear friends with Night’s accusee/er. And Speedy ✶ ✶ ✶ Ana’s partner was, that is, I was, fucking and/or dear friends with, across the battlements of this mutual accusation and public discourse, the pariah and figurehead of either faction. (Red

- hub · [[o aufÝfua]]
- before · [[the fight she lost]]
- after · [[a predicament that clockworked]]
- category · [[Why Survive]]
