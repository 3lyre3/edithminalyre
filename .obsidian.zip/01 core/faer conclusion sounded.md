---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 117
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

the accusing women-of it not-insufficiently-had-and-still-gives." Whatever muscle that smile constantly-gave-into-perpetuity failed. The-jaw-region a slacking of negative space filled. A minute passed. "Exact" faer conclusion sounded. "Exact." The accuser Red-of Night was. On bare skin Night-of the words of defence Ruth-of and Counter-accusation written were. † That

- hub · [[o aufÝfua]]
- before · [[the sort of division upward-of]]
- after · [[the quote enclothed body]]
- category · [[Why Survive]]
