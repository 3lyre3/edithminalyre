---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 154
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Reconciliation
---

the of DiCaprio glass margarita-of that-wine-filled-is sparkles. Right that seems. How downwardly the ruin rose that is or is-indeed. But query: of when the nearest time ago the-way<itself-so He gave[ the way it should]> your r.r. misery seemed was?” Where Red ever learned Night asked. How

- hub · [[o aufÝfua]]
- before · [[the-mechanism-exchange-of]]
- after · [[As just our writing]]
- category · [[Oath Day Blood Offering]]
