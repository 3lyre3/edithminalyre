---
ring: core
register: "F"
register_name: "Faerieland"
position: 13
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Faerieland
---

I will not give the name “rape” to our first event. Night, I guess, never loved Red. Do I still? It’s tricky. The catch in her throat meant she could never speak facing an audience. Her “performance” of key lines from Quivering Haecceities – now the

- hub · [[o aufÝfua]]
- before · [[new and worse, but necessary sun]]
- after · [[anti-transmisoaufgynlaích literature]]
- category · [[Doctor-Prescribed Service Husband]]
