---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 179
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Reconciliation
---

is; so/and Wave people-with Wave people'ya and Small people-with small people-'ya and Mound people-with Mound people'ya and Uplings-with Uplings'ya. Then faerself the company other-of each departs and the meatshrubs and featherfens and wooden forests a lifeform from carves. While yet unensouled to-its partner the form escorted

- hub · [[o aufÝfua]]
- before · [[Up-trill]]
- after · [[sixteen of fauna at-last survive]]
- category · [[The Blesses-Devils-Magics Registry]]
