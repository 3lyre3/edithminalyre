---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 105
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Reconciliation
---

note I and note all. Before/under the-darkness and the- watching light and mother of unraped-being whose avatar that in the wealds [is] I also before/under am and Faer Radiant Holyself. e.g. Artea and God so-as-said I † who of the Changed-Ones descended am singly-so and so

- hub · [[o aufÝfua]]
- before · [[the otherbound descendants]]
- after · [[my clan and kinfolk]]
- category · [[Better Lie]]
