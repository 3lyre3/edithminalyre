---
ring: core
register: "F"
register_name: "Faerieland"
position: 2
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Faerieland
---

[Artea e.g.], and before God, do I, [Legal Name], Grand-descendent of the Changed, singly and without trickery, forswear kinship with the changelings’ hosts; their descendants in the Uplands; their families entire. I forswear what-and-ever debt of blood, title, and property is owed my clan and kin

- hub · [[o aufÝfua]]
- before · [[the Darkness and the Watching Light]]
- after · [[the Sgiesaetthum’s longest era]]
- category · [[The Blesses-Devils-Magics Registry]]
