---
ring: core
register: "F"
register_name: "Faerieland"
position: 101
category: "Most Obvious Wound"
key: "Optimism need not be teleological"
arc: "My Body’s Another"
old_number: 12
tags:
  - Faerieland
---

… 17 … ✶ ✶ ✶ I waved the train on. I mean why not. Pointing, nodding, “You lead.” A solitary, unchained car-remote entered Red’s hand. “It’s my ex. The funeral.” “She never told me,” that much was true. The stripes on Red’s mini were faded

- hub · [[o aufÝfua]]
- before · [[it popped into sight]]
- after · [[She’s mine as well]]
- category · [[Most Obvious Wound]]
