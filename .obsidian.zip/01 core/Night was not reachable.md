---
ring: core
register: "F"
register_name: "Faerieland"
position: 89
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

of our home, then, I told Speedy Ana and she said, “Maybe it’s what Red mentioned,” then briefed me on the carving and Red’s plea, Red’s counter-accusation, Red’s shortcomings. Night was not reachable. And I was not about to chase Night’s friends, read them in on

- hub · [[o aufÝfua]]
- before · [[the long, fugueless trudge]]
- after · [[stories have that quality]]
- category · [[Good Things Happen]]
