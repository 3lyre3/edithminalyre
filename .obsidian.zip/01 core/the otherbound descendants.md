---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 104
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

† Children the- † stealing-of and the- † substitution-of [is] is. Topic: of-to land own NAND to vote Sub-topic: Years through-to 2961 ([4.9.21]) per-i.t. So toward- the farther-aforementioned-such so the otherbound descendants (who from these-much-farther- aforementioned abductees are) as follows must speak: Note: this-when and subsequent-from

- hub · [[o aufÝfua]]
- before · [[smackbang within the-middle]]
- after · [[mother of unraped-being]]
- category · [[Why Survive]]
