---
ring: core
register: "F"
register_name: "Faerieland"
position: 93
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Faerieland
---

home thinking very seriously about the fingernail-sized Beag sí scarification tattooist I saw but never spoke to in the days I still went to dungeons and where on my body I would ask faer to scar the passage in Quivering Haecceities about artificial productions of realness.)

- hub · [[o aufÝfua]]
- before · [[Let’s get back together]]
- after · [[bluff and bluff pretty hard]]
- category · [[Most Secret Muscle]]
