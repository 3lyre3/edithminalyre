---
ring: core
register: "F"
register_name: "Faerieland"
position: 31
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

on the rooftop like you’d expect and took the final third of her cigarette, smoked it watching the sun blur up between two sheets of railside cement way down, looked anywhere but at her. “Sorry,” I said. “Awful,” Night said. “Whose was awful? I loved you

- hub · [[o aufÝfua]]
- before · [[the factory’s darkness cheered her name]]
- after · [[Covered by green]]
- category · [[Bulls]]
