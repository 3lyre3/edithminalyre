---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 212
category: "Most Obvious Wound"
key: "Optimism need not be teleological"
arc: "My Body’s Another"
old_number: 12
tags:
  - Reconciliation
---

hand Red-of a solitary unchained remote car-of entered. “My ex we give. Our funeral.” • “Me telling she eternally-never-gave,” true that amount was. On mini Red-of the stripes faded were and of shopping-bags the backseat full was. "She to-myself ex-being gives-in-turn" I said.

- hub · [[o aufÝfua]]
- before · [[The-funeral-same-yes]]
- category · [[Most Obvious Wound]]
