---
ring: core
register: "F"
register_name: "Faerieland"
position: 16
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Faerieland
---

turn of the hall this speaking bore the face of an inner child or, back another alcove, a severally limbed monster (the style of narration suggested). But it all shouted “seems like you want me to be guilty?” with a high-rising terminal or question-tone not native

- hub · [[o aufÝfua]]
- before · [[not softness nor even weaponisable]]
- after · [[noise artist called Aura]]
- category · [[Oath Day Blood Offering]]
