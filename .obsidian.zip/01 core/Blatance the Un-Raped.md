---
ring: core
register: "F"
register_name: "Faerieland"
position: 58
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Faerieland
---

we could to answer the moot call of Faer Imperial Radiance, Blatance the Un-Raped. Nothing else mattered. Aos sí tread so light the rumble interrupted their lives not a whit. But the call sounded for all, every citizen, person, localisable region of sentience in Mionchain. Sí

- hub · [[o aufÝfua]]
- before · [[the fifth of six alarms]]
- after · [[goose tremors through the leyweb]]
- category · [[Better Lie]]
