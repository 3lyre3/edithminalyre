---
ring: core
register: "F"
register_name: "Faerieland"
position: 81
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Faerieland
---

forgot they do that. So they were both mammals, but it was all my eelwolf’s mouth closing on ginger locks, clamping the neck, and drinking dry, filling its eelwolf uterus with jackaloid blood. The rodent tried to mate, too, the way ✶ ✶ ✶ carvings will.

- hub · [[o aufÝfua]]
- before · [[thick head of ginger human hair]]
- after · [[until the bunny kicked limp]]
- category · [[A Future for Animals]]
