---
ring: core
register: "F"
register_name: "Faerieland"
position: 49
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Faerieland
---

Night all this I said also of course don’t tell anybody, I don’t want the fight she lost and plus Red’s someone I care about. The broad strokes of what I told Speedy Ana were the same. But Night was fucking somebody – fucking me –

- hub · [[o aufÝfua]]
- before · [[gullet tastes my own helplessness]]
- after · [[across the battlements]]
- category · [[Why Survive]]
