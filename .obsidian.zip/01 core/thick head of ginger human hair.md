---
ring: core
register: "F"
register_name: "Faerieland"
position: 80
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Faerieland
---

neckscruff, drawing in when the tongue retracted. Red’s carving was a jackalope with, in place of horns, an ordinary thick head of ginger human hair on its little rabbit head, and nothing else unusual except, unlike a jackalope, it didn’t lay eggs because (Red says) she

- hub · [[o aufÝfua]]
- before · [[converted atmosphere to hydrogen]]
- after · [[eelwolf uterus with jackaloid blood]]
- category · [[A Future for Animals]]
