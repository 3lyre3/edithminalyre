---
ring: core
register: "F"
register_name: "Faerieland"
position: 33
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Faerieland
---

this woman electro-torture herself in a plastic cage over a hundred-head audience (despite the shrouding and shadows) and rethought, as when the terminal’s rivets coursed her, these same words the pattern of her alopecia matches mine before the tilt and she raped you one time. One.

- hub · [[o aufÝfua]]
- before · [[Covered by green]]
- after · [[my capacity’s semi reduced]]
- category · [[Most Secret Muscle]]
