---
ring: core
register: "F"
register_name: "Faerieland"
position: 92
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

sent to Speedy Ana and Speedy Ana sent to Red, sort of describing the terms of the roleplay and proving Night’s screenshots were not, in fact, evidence. So Red claims. I asked to see the images and she said, “Let’s get back together,” so I walked

- hub · [[o aufÝfua]]
- before · [[I roleplayed as Red]]
- after · [[artificial productions of realness]]
- category · [[The Pure Light of Love]]
