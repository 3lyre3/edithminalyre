---
ring: core
register: "F"
register_name: "Faerieland"
position: 51
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Faerieland
---

as far as all knew was dear friends, too, with the woman fucking her accuser/ee (me.)) We had a predicament, a predicament that clockworked as I knew it would from my little “don’t tell anyone” and that I, in a chemical sense, let happen. But that’s

- hub · [[o aufÝfua]]
- before · [[across the battlements]]
- after · [[two wide-body airliners]]
- category · [[Good Things Happen]]
