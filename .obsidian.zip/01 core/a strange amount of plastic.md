---
ring: core
register: "F"
register_name: "Faerieland"
position: 96
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

well. I respect it. I respect you.” There was nothing in the back garden of that overstaffed and underclienteled café-bar except a miniature gumtree wrapped in a strange amount of plastic and the ash-stink of a faraway housefire. And eyes. Red’s. Taking in mine. Palms turned,

- hub · [[o aufÝfua]]
- before · [[every threat, every size is empty]]
- after · [[a fan before we met]]
- category · [[God’s Police]]
