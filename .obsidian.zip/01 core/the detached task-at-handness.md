---
ring: core
register: "F"
register_name: "Faerieland"
position: 39
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Faerieland
---

“The word I’m not using is rape,” I said. “Which I never used.” “Am I mistaken yours wasn’t penetration?” With the detached task-at-handness of the plausible victim, “If with you it was then.” “Then. Three it was. Two it wasn’t. Then.” Glancing up, past the jacket,

- hub · [[o aufÝfua]]
- before · [[before you hove in]]
- after · [[tapping, tapping the cheekbone]]
- category · [[Doctor-Prescribed Service Husband]]
