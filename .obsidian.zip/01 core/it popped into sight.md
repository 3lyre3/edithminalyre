---
ring: core
register: "F"
register_name: "Faerieland"
position: 100
category: "Easy Money on Polymarket"
key: "Provable but unspeakable truths are the seed and mechanism of prophecy"
arc: "Left Hand Realism"
old_number: 10
tags:
  - Faerieland
---

ex. The train was late until Red came running. Then it popped into sight. Materialised, just for her. “Ignore it,” she said, out of breath. “You’ll be late. I’ll drive. We’re going to the same place, I remembered.” “Are we?” “The same funeral.” Lyre · Síonæiya

- hub · [[o aufÝfua]]
- before · [[funeral might have started without me]]
- after · [[A solitary, unchained car-remote]]
- category · [[Easy Money on Polymarket]]
