---
ring: core
register: "F"
register_name: "Faerieland"
position: 30
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Faerieland
---

she said, “Dream,” and the yellow tentacles fluttered open to a sound like applause and the factory’s darkness cheered her name. I looked for Night in the later a.m. I wanted to talk, or at least, look at her and think about talking. Found her alone

- hub · [[o aufÝfua]]
- before · [[dreaming is dying]]
- after · [[watching the sun blur up]]
- category · [[A Future for Animals]]
