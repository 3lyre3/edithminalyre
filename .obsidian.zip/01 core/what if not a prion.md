---
ring: core
register: "F"
register_name: "Faerieland"
position: 26
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

prion disease; the prion motif was ever her thing), that makes it not possible. (But what if not a prion?) Night’s sequence of images aligns exactly with my firsthand visions of my own body in play, beneath Red’s, and is beyond reasonable doubt not a lie.

- hub · [[o aufÝfua]]
- before · [[Eyes-eyes-eyes-eyes]]
- after · [[all technics minus fact]]
- category · [[God’s Police]]
