---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 150
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Reconciliation
---

the cheekbone curving and tapping and tapping: “Eyen.” She right at me looked. “Q:you’n’t? A:no. But I-indeed ours/it might to give given be,” I said. When(/then) ourself-we kissed. Shuddered. She vomited. Again[iteratively] kissed. She our/the catscale-hers we/it gave. I to-my Speedy Ana I leaving was texted

- hub · [[o aufÝfua]]
- before · [[snappable matter rods-of]]
- after · [[within good-idea-being]]
- category · [[A Woman Regains Form]]
