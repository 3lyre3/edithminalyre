---
ring: core
register: "F"
register_name: "Faerieland"
position: 24
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

what I said so why’s it still. Then. Locking eyes-eyes-eyes. Then she’s inside and you’re trying stop a couple extra times and “look at me.” You idiot you are raping me she must not know. If she knows then. What is why the fuck is happening.

- hub · [[o aufÝfua]]
- before · [[physically speaking is not possible]]
- after · [[Eyes-eyes-eyes-eyes]]
- category · [[God’s Police]]
