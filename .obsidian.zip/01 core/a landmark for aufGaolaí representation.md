---
ring: core
register: "F"
register_name: "Faerieland"
position: 66
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Faerieland
---

sky, four of land, and four of deep places, newly created this moot three – one of deep places, two of rivers – were aufGaolaí inventions. A new record, a landmark for aufGaolaí representation. It’s a record unlikely to be surpassed. The election of creatures works

- hub · [[o aufÝfua]]
- before · [[sage grin still plastered]]
- after · [[Tann sí with Tann sí]]
- category · [[The Blesses-Devils-Magics Registry]]
