---
ring: core
register: "F"
register_name: "Faerieland"
position: 34
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Faerieland
---

Non-penetrative. It did that much? and not everyone can hack it and unexpected that I’m strong and stronger versus others. Other women. Comparatively. Never planned to be. “I’m sure we’re both high and awake,” I said. “But it’s the next morning and my capacity’s semi reduced.”

- hub · [[o aufÝfua]]
- before · [[electro-torture herself in a plastic cage]]
- after · [[Can you rephrase that]]
- category · [[Most Secret Muscle]]
