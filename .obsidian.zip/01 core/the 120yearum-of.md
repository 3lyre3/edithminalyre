---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 107
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

theirself in-of and as itself no-concern gives - without go-forth. And the/our right-in-full for-to seek and/or ask and/or from the closure thereof benefit to me it/we shall-give-not. The most length-of period † the 120yearum-of without an execution — ifly formal or otherwise — of Incar'aufGaolaí'cerated †

- hub · [[o aufÝfua]]
- before · [[my clan and kinfolk]]
- after · [[49.57 we give]]
- category · [[Why Survive]]
