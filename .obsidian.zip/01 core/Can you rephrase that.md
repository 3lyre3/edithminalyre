---
ring: core
register: "F"
register_name: "Faerieland"
position: 35
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Faerieland
---

Then I looked Night in the eye and said, “Can you rephrase that?” All scuffed and silver, the sunrise flattened the bones and narrow arches of her face and summoned a revised comment to the lips and second cigarette to the fingers. “Were you scanning for

- hub · [[o aufÝfua]]
- before · [[my capacity’s semi reduced]]
- after · [[little empty bits of the crowd]]
- category · [[New Francisco Beat]]
