---
ring: core
register: "F"
register_name: "Faerieland"
position: 71
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Faerieland
---

danced, the TV darkened, chin lost in the pitch black of the room. “But it wasn’t a creature in that way. Had no mouth nor locomotive means. We were half-watching- half-not-watching the carvings fuck and I asked if Red got why you and her stopped talking.

- hub · [[o aufÝfua]]
- before · [[blood-carved creations mated]]
- after · [[Always I was careful]]
- category · [[Better Lie]]
