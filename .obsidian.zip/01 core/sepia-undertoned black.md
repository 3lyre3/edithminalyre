---
ring: core
register: "F"
register_name: "Faerieland"
position: 64
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Faerieland
---

To hear Ana’s chin tell it, “Forget me meeting Red in Mionchain. All it was, was she asked to meet, but the asking was in person. Was at her place seeing Ess.” But – the TV room now a warm and delightful, sepia-undertoned black, undisturbed by

- hub · [[o aufÝfua]]
- before · [[a cluff of mintflowers]]
- after · [[sage grin still plastered]]
- category · [[Oath Day Blood Offering]]
