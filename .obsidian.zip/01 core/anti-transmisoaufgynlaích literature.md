---
ring: core
register: "F"
register_name: "Faerieland"
position: 14
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Faerieland
---

urtext of what we’ll call anti-transmisoaufgynlaích literature – and other of her finest works of short fiction was cutups pasted to Modh Gallery’s walls and small boxy speakers pasted underneath, repeating a scratch in her natural affect as the scratch of the audio. The function seeped

- hub · [[o aufÝfua]]
- before · [[The catch in her throat]]
- after · [[not softness nor even weaponisable]]
- category · [[Oath Day Blood Offering]]
