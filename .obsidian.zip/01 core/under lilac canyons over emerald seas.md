---
ring: core
register: "F"
register_name: "Faerieland"
position: 60
category: "Breathe & Dive"
key: "To live for the future is to live in glimmered moments"
arc: "Nature, Yet"
old_number: 9
tags:
  - Faerieland
---

Thus we trod, thus paraded, under lilac canyons over emerald seas, to the Shimmerlands and the realm of festival there raised. Red hailed our arrival and the summerlight alternately crackled and oozed, oozed and crackled, rivuled-through and messy with leystick. “Good to see you,” sang we

- hub · [[o aufÝfua]]
- before · [[goose tremors through the leyweb]]
- after · [[faer parasiticity, had paired us]]
- category · [[Breathe & Dive]]
