---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 138
category: "A Future for Animals"
key: "Magic is nature from the future"
arc: "Nature, Yet"
old_number: 5
tags:
  - Reconciliation
---

9 … Offward the ∆ gold grey gold V sun blinkered and in the-dark “Dreams” she said and open to-a sound that like applause was yellowy the-tentacles fluttered and her name the factory-ish darkness cheered. I in the later post-night for her searched. I to-talk or

- hub · [[o aufÝfua]]
- before · [[overdebted-enough conclusion]]
- after · [[the sun up-of Blurring]]
- category · [[A Future for Animals]]
