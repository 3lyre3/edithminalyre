---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 193
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Reconciliation
---

and no else unusual except unlike a jackalope eggs it lay didn’t because (Red says) she that they that do forgot. So each mammals they were but all my mouth eelwolf-of on ginger locks to-of-close and to-of-clamp the neck and dry to-of-drink and with blood jackaloid-of

- hub · [[o aufÝfua]]
- before · [[thick headtop of ginger]]
- after · [[its eelwolf-uterus to-fill]]
- category · [[Bulls]]
