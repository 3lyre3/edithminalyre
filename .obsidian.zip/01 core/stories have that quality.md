---
ring: core
register: "F"
register_name: "Faerieland"
position: 90
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

this matter, chairing interviews everywhere. I didn’t care enough. So the best explanation for Night’s suddenness with all that is what Red said a week later. But Red’s stories have that quality. (Night and Red never stopped talking. (That’s meant to be a secret.) So Night

- hub · [[o aufÝfua]]
- before · [[Night was not reachable]]
- after · [[I roleplayed as Red]]
- category · [[The Pure Light of Love]]
