---
ring: core
register: "F"
register_name: "Faerieland"
position: 87
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Faerieland
---

surprised at my bird. “You love bugs,” she said. “I don’t think I’ve once spoken the word ‘bug’ in your presence,” I said. “I’ve mixed people. I’ve mixed two people. No.” Lyre · Síonæiya … 15 … ✶ ✶ ✶ My bird dug for Night’s bug

- hub · [[o aufÝfua]]
- before · [[its beak was more perfectly diamond]]
- after · [[the long, fugueless trudge]]
- category · [[The Blesses-Devils-Magics Registry]]
