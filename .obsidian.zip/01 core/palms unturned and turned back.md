---
ring: core
register: "F"
register_name: "Faerieland"
position: 98
category: "Mother Aloysius’s Top 6 Movies"
key: "Sister Aloysius must go to the movies"
arc: "Mattering"
old_number: 3
tags:
  - Faerieland
---

can and that’s why. Why I’m sorry. But – like – we’ve each got things we need people to not talk about. Which is why we can be friendly. Can. Are being friendly.” Her palms unturned and turned back and floated into each other, leaves stuck

- hub · [[o aufÝfua]]
- before · [[a fan before we met]]
- after · [[funeral might have started without me]]
- category · [[Mother Aloysius’s Top 6 Movies]]
