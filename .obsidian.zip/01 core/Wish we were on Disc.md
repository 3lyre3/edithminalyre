---
ring: core
register: "F"
register_name: "Faerieland"
position: 20
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Faerieland
---

“Wish we were on Disc” vs. “let me come to you”. (We referred to the mini-clade’s cod et al. channel as ‘Disc,’ never by name.) Offered travelling but I don’t have a station like she does, not portable, and couldn’t join at hers. So we met

- hub · [[o aufÝfua]]
- before · [[nightly wilting and daily rebursting]]
- after · [[the rear- and front-enterable townhouse]]
- category · [[A Woman Regains Form]]
