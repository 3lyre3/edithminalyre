---
ring: core
register: "F"
register_name: "Faerieland"
position: 56
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Faerieland
---

Ana’s chin was undershone by the greyblue dying cornflower light of the phone she’d paused the movie with’s lockscreen, contouring and exaggerating, making it massive. My focus, a little pink-tinged and fraught, filled with Ana’s chin. “I meant to say,” the chin said, “sometime to you

- hub · [[o aufÝfua]]
- before · [[Iron frames groaned]]
- after · [[the fifth of six alarms]]
- category · [[A Woman Regains Form]]
