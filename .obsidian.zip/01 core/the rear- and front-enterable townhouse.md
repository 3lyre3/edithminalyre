---
ring: core
register: "F"
register_name: "Faerieland"
position: 21
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Faerieland
---

at the front lower gate of the rear- and front-enterable townhouse I live in, walked to hers, collected the portable station, walked back to mine. We re-entered my place by the back upper window door, kissed, and did later, much later on, get on Disc. Everything

- hub · [[o aufÝfua]]
- before · [[Wish we were on Disc]]
- after · [[insistence simultaneous with reluctance]]
- category · [[A Woman Regains Form]]
