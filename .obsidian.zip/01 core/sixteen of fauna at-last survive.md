---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 180
category: "Red Light Necropolis"
key: "All the body needs is a taste"
arc: "Nature, Yet"
old_number: 18
tags:
  - Reconciliation
---

is and –if feasible– their creations the pair to breed attempt must. If the mating creations-of an offspring produces then that offspring to-the election entered and tested and contested may be until (less eight of million creatures of failure) sixteen of fauna at-last survive • o

- hub · [[o aufÝfua]]
- before · [[Wave people-with Wave people'ya]]
- after · [[naturally we – underperform]]
- category · [[Red Light Necropolis]]
