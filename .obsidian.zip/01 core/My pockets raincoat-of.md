---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 140
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Reconciliation
---

but at her looked. I “Sorry” said. • “Awful” Night said. • “Query: whom with awful it was was? I you and obviously set Laea-of loved.” But at me she looked. My boots. My pockets raincoat-of with changes of clothing to-of bulging and six of prescription

- hub · [[o aufÝfua]]
- before · [[the sun up-of Blurring]]
- after · [[a onehundreda’head’ndtwenty audience]]
- category · [[Good Things Happen]]
