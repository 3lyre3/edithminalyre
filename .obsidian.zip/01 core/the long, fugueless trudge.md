---
ring: core
register: "F"
register_name: "Faerieland"
position: 88
category: "Breathe & Dive"
key: "To live for the future is to live in glimmered moments"
arc: "Nature, Yet"
old_number: 9
tags:
  - Faerieland
---

and yanked, licked its pentagonal frame into its diamond beak, crushed it back to symmetry. — At one leg of the long, fugueless trudge from the Shimmerlands after the moot’s closing festival, I checked my devices and saw Night blocked me on everything. In the dark

- hub · [[o aufÝfua]]
- before · [[My bird dug for Night’s bug]]
- after · [[Night was not reachable]]
- category · [[Breathe & Dive]]
