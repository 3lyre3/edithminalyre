---
ring: core
register: "F"
register_name: "Faerieland"
position: 94
category: "Easy Money on Polymarket"
key: "Provable but unspeakable truths are the seed and mechanism of prophecy"
arc: "Left Hand Realism"
old_number: 10
tags:
  - Faerieland
---

— ✶ ✶ ✶ “You’re the type who’ll bluff and bluff pretty hard and look me in the eyes and say you’re calling it,” Red said. “But not the type who’ll play the hand. Not when it comes to it. I could say I’m bluffing and

- hub · [[o aufÝfua]]
- before · [[artificial productions of realness]]
- after · [[every threat, every size is empty]]
- category · [[Easy Money on Polymarket]]
