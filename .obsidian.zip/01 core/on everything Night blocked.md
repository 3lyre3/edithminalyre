---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 201
category: "Red Light Necropolis"
key: "All the body needs is a taste"
arc: "Nature, Yet"
old_number: 18
tags:
  - Reconciliation
---

festival-of of the moot at one stretch of the long fugueless trudge the Shimmerlands from I my devices checked and me on everything Night blocked saw. I in the dark of our home so-then Speedy Ana told and she said “Maybe what<Red mentioned> it is” then/when

- hub · [[o aufÝfua]]
- before · [[made thinkn't]]
- after · [[I not-enough-cared]]
- category · [[Red Light Necropolis]]
