---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 207
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Reconciliation
---

and of a-faraway housefire l ash-stink ours-of we gave was>. And eyen we gave. Red eyen. Mine the-take inwarding. Palms turned she said: "I am. I you<to-still (my words through) raped> sorry am. I especially sorry with consideration of (me you sync-to) Haecceities Quivering-of am. I

- hub · [[o aufÝfua]]
- before · [[the ba'garden'ck of this barcafé]]
- after · [[Why I sorry am is]]
- category · [[Doctor-Prescribed Service Husband]]
