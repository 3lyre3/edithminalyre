---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 159
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

Night to-told also I of the course nobody tell said and I the fight she lost not want and plus someone<I about-care> Red is. Of what I Speedy Ana told the strokes<that broad were> the same were. But somebody× Night to-fucking-of (me-of to-fucking) ×who/same-again-who<dear friends Night

- hub · [[o aufÝfua]]
- before · [[complaintless swallows]]
- after · [[the pariah and the figurehead]]
- category · [[Why Survive]]
