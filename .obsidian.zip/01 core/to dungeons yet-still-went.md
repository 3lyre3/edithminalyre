---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 205
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

and Red-to/with Speedy Ana sent> showed. So Red claims. (I the images to-see asked and she said: "Why together not back get —'you know…" …so toward thinking about the fingernail-sized Beag sí scarification-tattooist that<I in the days I to dungeons yet-still-went saw but never to-spoke> and

- hub · [[o aufÝfua]]
- before · [[factily not evidence]]
- after · [[the ba'garden'ck of this barcafé]]
- category · [[Why Survive]]
