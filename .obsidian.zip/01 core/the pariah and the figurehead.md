---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 160
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

accusee/er-of-with as far as all knew was> was. And our/the partner that Speedy Ana-to-with we/it gave (id est I) across-over the battlements of this mutual accusation and public discourse toward-with the pariah and the figurehead of either faction at-to-fuck and/or dear friends with was. (Dear friends

- hub · [[o aufÝfua]]
- before · [[of the course nobody tell]]
- after · [[Ax ios Umerycu]]
- category · [[Why Survive]]
