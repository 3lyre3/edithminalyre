---
ring: core
register: "F"
register_name: "Faerieland"
position: 68
category: "Breathe & Dive"
key: "To live for the future is to live in glimmered moments"
arc: "Nature, Yet"
old_number: 9
tags:
  - Faerieland
---

each departs the other’s company and from the meatshrubs and featherfens and wooden forests carves a lifeform. Yet unsouled, the form is escorted to its partner, and the pair must attempt – if feasible – to breed their creations. If the creations’ mating produces an offspring

- hub · [[o aufÝfua]]
- before · [[Tann sí with Tann sí]]
- after · [[eight million failed creatures]]
- category · [[Breathe & Dive]]
