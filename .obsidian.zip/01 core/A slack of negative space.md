---
ring: core
register: "F"
register_name: "Faerieland"
position: 11
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Faerieland
---

failed. A slack of negative space filled the jaw region. A minute passed. “Right” sounded faer conclusion. “Right.” Night was Red’s accuser. But Red was Night’s accuser too. On Night’s bare skin were written the words of Red’s defence and counteraccusation. But for the dick, breasts,

- hub · [[o aufÝfua]]
- before · [[fae accusing fae]]
- after · [[new and worse, but necessary sun]]
- category · [[Doctor-Prescribed Service Husband]]
