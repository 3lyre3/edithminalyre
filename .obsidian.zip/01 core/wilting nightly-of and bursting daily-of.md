---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 126
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Reconciliation
---

in-a way as to-her new and like it only that day been-discovered was so. Every day like that she still-is: To-at forgeting wakes and at each day Power-that-one againily discovers. The-effect (I as think so) but-for our wilting nightly-of and bursting daily-of gives it shortfire will-been/would.

- hub · [[o aufÝfua]]
- before · [[the ex-oathed Aura-of]]
- after · [[onto passageway-mine she came]]
- category · [[Bulls]]
