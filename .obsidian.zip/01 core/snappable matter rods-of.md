---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 149
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Reconciliation
---

we gave [meaning: it was] so-then.” • “So-then. Three of ours we gave. Two of ours we gaven’t. So-then.” • Up past the-jacket to-glance: my sinews and neck and snappable matter rods-of at. “Giving…” The gaze to-the tracing-of: across own collarbone fingernail and to chin and

- hub · [[o aufÝfua]]
- before · [[plausible victim-being]]
- after · [[catscale-hers]]
- category · [[Why Survive]]
