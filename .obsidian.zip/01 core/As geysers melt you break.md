---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 112
category: "Undo undo Undo undo un…"
key: "Obsessive recitation of the real cannot change it"
arc: "Nature, Yet"
old_number: 6
tags:
  - Reconciliation
---

we break. Yourself the-breaking is. Alive you are Lyre · Síonæiya … 5 … and being-alive the breaking is. Note!: "As-said" as through centuries crystals scour and scuff and grind-up so you break. As mountains die so— so break. As geysers melt you break. Note!: A

- hub · [[o aufÝfua]]
- before · [[o your charge the word is]]
- after · [[proteinaceous- praxis—'ya]]
- category · [[Undo undo Undo undo un…]]
