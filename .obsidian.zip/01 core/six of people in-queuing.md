---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 186
category: "Red Light Necropolis"
key: "All the body needs is a taste"
arc: "Nature, Yet"
old_number: 18
tags:
  - Reconciliation
---

Ana not only fast she was is but the-customers too she up-sped. So quick she once six of people in-queuing got and as a-single new friend group ordering to-a-single table them glom together made and a bottle † of vodka and † one of champagne within

- hub · [[o aufÝfua]]
- before · [[Small small small odds]]
- after · [[As over it turns]]
- category · [[Red Light Necropolis]]
