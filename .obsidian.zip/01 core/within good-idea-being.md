---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 151
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Reconciliation
---

and to hers Night sailed. It while I dressed Eight [Ghás] to-come was and that my big bulky pockets by- means-of clothes changes-of and medicine days-of filled within good-idea-being was Night agreed. (Of a “helpless this-to iterate we are’ish way type-of terrifying the sex was.) —

- hub · [[o aufÝfua]]
- before · [[catscale-hers]]
- after · [[correct-to and agree]]
- category · [[Oath Day Blood Offering]]
