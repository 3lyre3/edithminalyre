---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 122
category: "Oath Day Blood Offering"
key: "In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’"
arc: "My Body’s Another"
old_number: 8
tags:
  - Reconciliation
---

new and violenter our/the innocence we/it gave — and per a weakness that as softness neither-nor even weaponisability it so given't was pled. "Sure," the installation that voice Red-of said: "I'm guilty if that what your sinews shiny gets is." Singular but multilocal at-of one-specific turn

- hub · [[o aufÝfua]]
- before · [[Innocence the function seeped]]
- after · [[the-monster seve'limbed'rally]]
- category · [[Oath Day Blood Offering]]
