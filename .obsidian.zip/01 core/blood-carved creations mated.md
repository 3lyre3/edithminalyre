---
ring: core
register: "F"
register_name: "Faerieland"
position: 70
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Faerieland
---

the aufGaolaí – naturally we – underperform. Three was too many. It generated some social and policy backlash. But who cares. Ana’s and Red’s blood-carved creations mated and almost bred. Together, they very nearly got a result. “A sort of thing did emerge.” Speedy Ana’s voice

- hub · [[o aufÝfua]]
- before · [[eight million failed creatures]]
- after · [[half-watching- half-not-watching]]
- category · [[New Francisco Beat]]
