---
ring: core
register: "F"
register_name: "Faerieland"
position: 63
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Faerieland
---

stared and stared and said nothing. A crust of iron- coloured leystick, dew-tipped, thawing, hung from her lower lid. She’d not blinked all fugue march. “Yeah,” Red said. “Fine.” Then Ana took her arm and, in bond, the two vanished around a cluff of mintflowers. —

- hub · [[o aufÝfua]]
- before · [[my honest-to-God best]]
- after · [[sepia-undertoned black]]
- category · [[Better Lie]]
