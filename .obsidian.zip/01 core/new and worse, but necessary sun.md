---
ring: core
register: "F"
register_name: "Faerieland"
position: 12
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

pubic triangle, and face, the quote enclothed this, Night’s body, up in its nest seizing, jittering, wrenched back like a solar bridge to welcome the grey, gold, grey strobe of the factory’s ceiling as our new and worse, but necessary sun. Out of love for Red

- hub · [[o aufÝfua]]
- before · [[A slack of negative space]]
- after · [[The catch in her throat]]
- category · [[The Pure Light of Love]]
