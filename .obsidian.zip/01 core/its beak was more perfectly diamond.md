---
ring: core
register: "F"
register_name: "Faerieland"
position: 86
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Faerieland
---

is you. Maybe that makes it worse.” — I carved a small bird like any other. But its beak was more perfectly diamond and its feathers more perfectly the blue of a midday sky. Night’s was a deep earth insect with a pentagonal frame. She was

- hub · [[o aufÝfua]]
- before · [[neither heard the eelwolf choking]]
- after · [[My bird dug for Night’s bug]]
- category · [[Better Lie]]
