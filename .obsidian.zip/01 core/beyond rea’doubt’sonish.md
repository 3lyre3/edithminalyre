---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 135
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Reconciliation
---

my eyeforth[firsthand] visions body-mine-of at fun-taking under Red-hers-of aligns and beyond rea’doubt’sonish a not sour-unreality[lie] is. Say-can-of[sayable] that [is]. Say-can-of it [is]. Night sour- unreality not made. But no not nor-neither say-can-of sour-unreality Red made. *Quivering Haecceities* fa’technichified’ct-lack-with/of and altogetherly. I only ways negatively[lit. negative- creatively/femininely]

- hub · [[o aufÝfua]]
- before · [[the Braindisease there]]
- after · [[finger-nailparts-of]]
- category · [[Doctor-Prescribed Service Husband]]
