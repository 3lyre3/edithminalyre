---
ring: core
register: "F"
register_name: "Faerieland"
position: 29
category: "God’s Police"
key: "In stillness, all is clean"
arc: "Mattering"
old_number: 17
tags:
  - Faerieland
---

the dick upright, jolted the performance to a more-than-overdue conclusion. Seizure done, neck rolling, she tried her best to yell but scarcely audibly said, “We are the dead and dreaming is dying. But dream. Dream.” The gold, grey, gold sun blinkered out and in the dark

- hub · [[o aufÝfua]]
- before · [[these raw nodes of current]]
- after · [[the factory’s darkness cheered her name]]
- category · [[God’s Police]]
