---
ring: core
register: "F"
register_name: "Faerieland"
position: 41
category: "Bulls"
key: "There can be a tiger. You won’t let there be"
arc: "My Body’s Another"
old_number: 19
tags:
  - Faerieland
---

Shuddered. She vomited. Kissed again. She had her own catscale. I texted Speedy Ana I was leaving and Night sailed to hers. It was coming eight p.m. as I dressed and Night agreed my big bulky pockets full of changes of clothing and days of medicine

- hub · [[o aufÝfua]]
- before · [[tapping, tapping the cheekbone]]
- after · [[harder to sell than reality]]
- category · [[Bulls]]
