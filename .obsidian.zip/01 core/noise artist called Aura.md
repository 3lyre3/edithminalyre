---
ring: core
register: "F"
register_name: "Faerieland"
position: 17
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Faerieland
---

in Red’s accent to declarative sentences. ✶ ✶ ✶ I took her with me that night to a winter thing run by the then-oathed of my then-ex, a flutist and noise artist called Aura. (Now Ana a.k.a. Speedy Ana, Aura’s ex-oathed, and I are together again.)

- hub · [[o aufÝfua]]
- before · [[a severally limbed monster]]
- after · [[wakes up forgetting]]
- category · [[A Woman Regains Form]]
