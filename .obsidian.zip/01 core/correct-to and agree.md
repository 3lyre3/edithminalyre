---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 152
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Reconciliation
---

Harder than reality to-sell nothing[of-the-eternal-feminine] Red says is. Internally I “the Real” correct-to and agree. The reality to-myself that<me and Night she raped and I on oneself-other with Night fixated and into roleplay-reenacting got and fun it gave> is. The Real to myself the series of

- hub · [[o aufÝfua]]
- before · [[within good-idea-being]]
- after · [[the-mechanism-exchange-of]]
- category · [[A Woman Regains Form]]
