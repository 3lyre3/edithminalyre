---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 206
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Reconciliation
---

I on my body where the passage from Quivering Haecceities about artificial productions of realness faer to scar ask would I homeward walked.) — Our nothing in the ba'garden'ck of this barcafé that<overstaffed and underclienteled was> except-a<miniature gumtree that<in a strange amount of plastic wrapped was>

- hub · [[o aufÝfua]]
- before · [[to dungeons yet-still-went]]
- after · [[Mine the-take inwarding]]
- category · [[Better Lie]]
