---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 148
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Reconciliation
---

really not.” • Lyre · Síonæiya … 11 … “The-word I toward-using-of not am «rape» is,” I said. • “Which I to-use we/it never-gave.” • “Query: I that yours penetration not was been-mistake r.r.am am?” • With detached the-task-at-handness plausible victim-being gives: “If with you so

- hub · [[o aufÝfua]]
- before · [[Hardly toward traction]]
- after · [[snappable matter rods-of]]
- category · [[Most Secret Muscle]]
