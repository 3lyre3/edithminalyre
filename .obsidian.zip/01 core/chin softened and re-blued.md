---
ring: core
register: "F"
register_name: "Faerieland"
position: 83
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

and out of each other and she went, ‘You are too.’” I said, “How does being Red’s type make you feel?” “Then so. So.” In a sweep of traffic light through the curtain’s cracks, Speedy Ana’s chin softened and re-blued and the cold curve of her

- hub · [[o aufÝfua]]
- before · [[until the bunny kicked limp]]
- after · [[Well, informed consent]]
- category · [[The Pure Light of Love]]
