---
ring: core
register: "F"
register_name: "Faerieland"
position: 102
category: "A Doll’s Universe"
key: "Once there were no masters. And yet the house was built"
arc: "My Body’s Another"
old_number: 12
tags:
  - Faerieland
---

and the backseat was full of shopping bags. “She’s mine as well,” I said.

- hub · [[o aufÝfua]]
- before · [[A solitary, unchained car-remote]]
- category · [[A Doll’s Universe]]
