---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 132
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Reconciliation
---

what I said said so query<the is why it-still>. This why. To-the locking eyes- ey’ey’eyes’es’es-eyes. When she/the-anticreative-force [undefined]-up-inside-of is and a few extra repetitions notestop to-the trying-of are and “Note: “«As-is-said» at-toward me you look.” ↓ (re: you-idiot) myself ↑ you rape she know mustn’t. If

- hub · [[o aufÝfua]]
- before · [[Note-you-stop- indeed]]
- after · [[the fucked-through-Hell happening]]
- category · [[Most Secret Muscle]]
