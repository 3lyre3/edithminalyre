---
ring: core
register: "F"
register_name: "Faerieland"
position: 47
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Faerieland
---

say I knew it would hurt. I did it anyway. But everything hurts someone. I cannot for example will myself to put non-aluminium “recyclables” in the recycling box because the route map of the disposal trucks is publicly available and I know what pickups go to

- hub · [[o aufÝfua]]
- before · [[the extent of those lines]]
- after · [[gullet tastes my own helplessness]]
- category · [[New Francisco Beat]]
