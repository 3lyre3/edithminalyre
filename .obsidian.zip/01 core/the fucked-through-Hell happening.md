---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 133
category: "A Woman Regains Form"
key: "Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how"
arc: "Left Hand Realism"
old_number: 11
tags:
  - Reconciliation
---

she knows when. Query:<what is why the fucked-through-Hell happening>: Ey’ey’eyes’es’es-ey’ey’eyes’es’es- ey’ey’eyes’es’es. Such-subsequent- from (and your-head nods) I it from came. So and as of Nature so our/the-ever to-a minimum of about-six of weeks <that sequence of events name-of obvious-of to-assign> we/it-ever give — I out-of love

- hub · [[o aufÝfua]]
- before · [[ey’ey’eyes’es’es-eyes]]
- after · [[the Braindisease there]]
- category · [[A Woman Regains Form]]
