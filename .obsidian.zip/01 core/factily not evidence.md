---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 204
category: "Good Things Happen"
key: "It’s a problem that I matter"
arc: "Mattering"
old_number: 7
tags:
  - Reconciliation
---

shared> Red- to/with Night gave and to that effect as evidence screenshots of a chat at-which I as Red roleplayed showed. When/then as<the story goes> Night-to/with Red pics toward the terms of-the roleplay describing-of and factily not evidence so screenshots Night-of proving-of that<I Speedy Ana-to/with sent

- hub · [[o aufÝfua]]
- before · [[a secret to-be-meant is]]
- after · [[to dungeons yet-still-went]]
- category · [[Good Things Happen]]
