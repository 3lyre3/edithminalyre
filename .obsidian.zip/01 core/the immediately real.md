---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 156
category: "New Francisco Beat"
key: "That’s all the bars are, Mr Losse. They’re honesty"
arc: "My Body’s Another"
old_number: 15
tags:
  - Reconciliation
---

idiot. Second and third and subsequent effects more than the immediately real my attention occupy. But I it<toward truth-being not-is to-pretend> necessary been-found because our ve’much’ry necessary harm at the-extent of those lines we give and if one that<it hurt would knew says> then one nobody

- hub · [[o aufÝfua]]
- before · [[As just our writing]]
- after · [[someone everything hurts]]
- category · [[New Francisco Beat]]
