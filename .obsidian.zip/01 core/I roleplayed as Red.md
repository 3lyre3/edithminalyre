---
ring: core
register: "F"
register_name: "Faerieland"
position: 91
category: "Mother Aloysius’s Top 6 Movies"
key: "Sister Aloysius must go to the movies"
arc: "Mattering"
old_number: 3
tags:
  - Faerieland
---

gave Red an account of her and my short fling that shared some narrative kinship with accusations made about Red and, as evidence to that effect, showed Red screenshots of a chat where I roleplayed as Red. Then Red, the story goes, showed Night pics I’d

- hub · [[o aufÝfua]]
- before · [[stories have that quality]]
- after · [[Let’s get back together]]
- category · [[Mother Aloysius’s Top 6 Movies]]
