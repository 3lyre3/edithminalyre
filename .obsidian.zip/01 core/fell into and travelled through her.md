---
ring: core
register: "F"
register_name: "Faerieland"
position: 76
category: "Better Lie"
key: "Should I lie and write so-called realism or tell the truth and write so-called speculative fiction"
arc: "Left Hand Realism"
old_number: 1
tags:
  - Faerieland
---

came from 92 to 135 seconds. Such was Speedy Ana’s power it accelerated even Red’s near-immortally sluggish temporal blast zone. Red fell into and travelled through her, outmatched and fearing. They kept contact, Ana’s responses to Red’s replies instant and preternaturally thorough, and I suspect the

- hub · [[o aufÝfua]]
- before · [[upsold them a bottle of vodka]]
- after · [[Though I was not uranium]]
- category · [[Better Lie]]
