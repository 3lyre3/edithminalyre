---
ring: core
register: "F"
register_name: "Faerieland"
position: 38
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Faerieland
---

Look. If it’s the second I’m really genuinely sorry but you saw how my time around it turned out. Red wasn’t hardly getting traction before you hove in. You turned it out the way it turned out. Which I’m not grateful, okay, or comfortable really about.”

- hub · [[o aufÝfua]]
- before · [[don’t have it to give]]
- after · [[the detached task-at-handness]]
- category · [[Why Survive]]
