---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 153
category: "Most Secret Muscle"
key: "Every muscle that counts for anything keeps itself a secret"
arc: "Left Hand Realism"
old_number: 2
tags:
  - Reconciliation
---

actions and of events an obvious (the-mechanism-exchange-of reality and the Real to-the bonding-of species-being-of ‘obviousness’ given is) name to-been-given is. “Masters of realness” Red writes: “…offenders are. A recall× offender-of of side-and of back and of night-day-to-serve lit and shot is and the-rim ×that<same-again-of is> akin-to

- hub · [[o aufÝfua]]
- before · [[correct-to and agree]]
- after · [[How downwardly the ruin rose]]
- category · [[Most Secret Muscle]]
