---
ring: core
register: "F"
register_name: "Faerieland"
position: 84
category: "The Pure Light of Love"
key: "All was brightness and knowing"
arc: "My Body’s Another"
old_number: 13
tags:
  - Faerieland
---

forehead pressed my shoulder, eyes seeking. We smiled at each other and she said, “The obvious way. But so then... “I asked if we should go now, the mating failed in any case. ‘Well, informed consent,’ Red said. She started laughing and so did I. Took

- hub · [[o aufÝfua]]
- before · [[chin softened and re-blued]]
- after · [[neither heard the eelwolf choking]]
- category · [[The Pure Light of Love]]
