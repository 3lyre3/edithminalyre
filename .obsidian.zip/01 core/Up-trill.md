---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 178
category: "Red Light Necropolis"
key: "All the body needs is a taste"
arc: "Nature, Yet"
old_number: 18
tags:
  - Reconciliation
---

A new record and a landmark for aufGaolaí representation-of. Up-trill. A record that unlikely to surpassed been-will [is]. As such the election of creatures works: With-another of faer-own clade (always faer-own minus five or so of exceptions errors-of rounding-of less eightish of million) every Faerielander paired

- hub · [[o aufÝfua]]
- before · [[aufGaolaíách inventions]]
- after · [[Wave people-with Wave people'ya]]
- category · [[Red Light Necropolis]]
