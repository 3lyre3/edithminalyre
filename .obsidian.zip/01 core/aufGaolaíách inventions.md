---
ring: core
register: "R"
register_name: "And Reconciliation"
position: 177
category: "The Blesses-Devils-Magics Registry"
key: "Gill-Peterson underestimates the arcane potential of stamps on paper"
arc: "Nature, Yet"
old_number: 14
tags:
  - Reconciliation
---

creature we chose. A result very nearly got.” Of the sixteen of creatures —four of rivers and four of sky and four of land and four of deep places— newly of this moot three —one of deeps and two of rivers— of aufGaolaíách inventions created were.

- hub · [[o aufÝfua]]
- before · [[sepially undertonal black]]
- after · [[Up-trill]]
- category · [[The Blesses-Devils-Magics Registry]]
