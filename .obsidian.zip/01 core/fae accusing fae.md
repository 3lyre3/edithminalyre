---
ring: core
register: "F"
register_name: "Faerieland"
position: 10
category: "Why Survive"
key: "Survival is no excuse for atrocity"
arc: "Mattering"
old_number: 4
tags:
  - Faerieland
---

great principle.” The therapist nodded. “For the Uplands, it’s great. With them, the sort of division up there, it’s tidy.” The therapist nodded again. “Here it’s fae accusing fae. Or in aufGaolaí communities, often enough still, it’s women accusing women.” Whatever muscle supported the constant smile

- hub · [[o aufÝfua]]
- before · [[Four therapists ago]]
- after · [[A slack of negative space]]
- category · [[Why Survive]]
