---
ring: core
register: "F"
register_name: "Faerieland"
position: 25
category: "Doctor-Prescribed Service Husband"
key: "To get horror, combine spectacle and illegibility"
arc: "Mattering"
old_number: 16
tags:
  - Faerieland
---

Eyes-eyes-eyes-eyes. After, you know, I came from it. So naturally they say it takes minimum sixish weeks to assign the obvious name to that species of series of events which out of love for Red I still don’t. There’s a neuropathy there, in me (not a

- hub · [[o aufÝfua]]
- before · [[What is why the fuck]]
- after · [[what if not a prion]]
- category · [[Doctor-Prescribed Service Husband]]
