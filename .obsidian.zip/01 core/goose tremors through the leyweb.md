---
ring: core
register: "F"
register_name: "Faerieland"
position: 59
category: "Breathe & Dive"
key: "To live for the future is to live in glimmered moments"
arc: "Nature, Yet"
old_number: 9
tags:
  - Faerieland
---

caught it in their hairs, goose tremors through the leyweb, and we in our feet. Hear; hear Lyre · Síonæiya … 11 … ✶ ✶ ✶ and be summoned. Heed the knell of the Un-Raped Mother. Faer Avatar’s eye beckons you, little ray. Be its light.

- hub · [[o aufÝfua]]
- before · [[Blatance the Un-Raped]]
- after · [[under lilac canyons over emerald seas]]
- category · [[Breathe & Dive]]
