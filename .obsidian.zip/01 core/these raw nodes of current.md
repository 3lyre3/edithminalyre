---
ring: core
register: "F"
register_name: "Faerieland"
position: 28
category: "Undo undo Undo undo un…"
key: "Obsessive recitation of the real cannot change it"
arc: "Nature, Yet"
old_number: 6
tags:
  - Faerieland
---

Night’s fingertips arched, out of the nest, to grace and, stretching harder, grasp a dark red electrical device crowned by these raw nodes of current that, now, shook through and shook the woman’s body, thrashed the grace out of it. Miraculous contortions spread every length, bolted

- hub · [[o aufÝfua]]
- before · [[all technics minus fact]]
- after · [[dreaming is dying]]
- category · [[Undo undo Undo undo un…]]
