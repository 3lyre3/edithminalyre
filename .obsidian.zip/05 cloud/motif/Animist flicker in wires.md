---
type: "motif"
voice: "Lyre"
source: thesis
section: "Left Hand Realism"
position: 0.72
stations: [1]
locus: "T0086 · Left Hand Realism"
count: 4
pattern: "wires in the walls|animist"
kin:
  - "machines alive"
readers: [GB01]
---

‘Some flicker of animist essence with the cheap, thrumming wires in the walls’ — the trans subject’s felt kinship with machinery.

> we share some flicker of animist essence with the cheap, thrumming wires in the walls

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Magic is nature from the future]]
- see · [[Technophilia cliché]]
- see · [[The robot server]]
