---
type: "motif"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 67.99
stations: [14, 19]
locus: "T1075 · Stamina"
count: 5
pattern: "boymode|girlmode|mascara"
kin:
  - "transfemininity"
  - "presentation"
readers: [GB12]
---

‘Would it be alright to come in boymode?’ — identical to girlmode bar the brown mascara, worn on the misogynistic assumption that one should be modest to be authentic.

> the misogynistic assumption so many trans women made that one should be modest in order to be authentic

- key · [[All was brightness and knowing]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[He says he’s my girlfriend]]
- see · [[Dear Amaldéu (presentation)]]
- see · [[Nineteen things]]
- see · [[Exit — why Bunnings]]
