---
type: "motif"
voice: "Ten Years On narrator"
source: thesis
section: "Ten Years On"
position: 26.39
stations: [6]
locus: "T0531 · Ten Years On"
count: 3
pattern: "blood debt|police-recruit|renounce"
kin:
  - "oaths and stamps"
  - "police"
readers: [GB05]
---

Police recruits made to swear the archaic renouncement of blood debts — the oath, footnoted in full — and attend cultural tuitions not asked of Aos sí; overturned in 2986.

> an archaic renouncement of so-called “blood debts”

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Chief Superintendent efNaofis]]
- see · [[Cops’ cleanness]]
