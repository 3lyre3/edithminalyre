---
type: "motif"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 66.65
stations: [8, 14, 15]
locus: "T1071 · Stamina"
count: 7
pattern: "superstition|falline|laxity"
kin:
  - "names"
  - "deadnames"
readers: [GB12]
---

To name a thing steals the named property — wrong to call a child Alexander; the deadname Suicide guarantees dying some other way; parents Laxity and Hunger.

> The Falline thought it unusual – wrong, even – to call a child Alexander, as to do so ensured the child would never be great.

- key · [[All was brightness and knowing]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[Cisatlantic holidays]]
- see · [[Rache]]
