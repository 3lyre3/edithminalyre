---
type: "motif"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 13.03
stations: [3]
locus: "T0341 · Quivering Haecceities"
count: 2
pattern: "crumbs|open hands"
kin:
  - "queer theory s limit"
  - "normativity"
readers: [GB03]
---

Nothing but crumbs beneath Faer Radiance’s table; nothing but dirt on queer theory’s open hands — ‘And how, to whom, could a girl ever voice a thing like that?’

> there’s nothing but crumbs beneath Faer Radiance’s table, there’s nothing but dirt on queer theory’s open hands

- key · [[Sister Aloysius must go to the movies]]
- key · [[Optimism need not be teleological]]
- see · [[Red tooth and claw filtration]]
- see · [[Andrea Long Chu]]
- see · [[Reality scripted by its epoch]]
