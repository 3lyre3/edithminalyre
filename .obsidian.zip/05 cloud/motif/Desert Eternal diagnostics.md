---
type: "motif"
voice: "Lyre"
source: thesis
section: "1.236"
position: 34.26
stations: [7]
locus: "T0660 · 1.236"
count: 3
pattern: "diagnostic system|gender identity disorder|endocrinolog"
kin:
  - "diagnosis"
  - "autobiography"
  - "medicine"
readers: [GB07]
---

The system scrapped late 20,071: a letter of dysphoria history, psychiatric assessments for Gender Identity Disorder, sexual history, blood tests, an endocrinologist — the author among its last.

> I was one of the last trans people expected to go through The Desert Eternal’s diagnostic system

- key · [[It’s a problem that I matter]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Survival is no excuse for atrocity]]
- see · [[The old psychiatrist]]
- see · [[Clean, reversible, makeup-removable]]
- see · [[Easy to think around]]
- see · [[Psychosomatic certainty]]
- see · [[Open wounds]]
- see · [[Sex produced where gender denied]]
