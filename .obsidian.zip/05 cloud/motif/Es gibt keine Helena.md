---
type: "motif"
voice: "E"
source: thesis
section: "took the Alexander from Paris and I the Paris from Alexander, what remained of what went of me in the Scamander to buoy again a barbarian enough mannerly for the Priamidi’s fosterage? Who was he?"
position: 61.28
stations: [12, 20]
locus: "T1023 · took the Alexander from Paris and I the Paris from Alexander, what remained of what went of me in the Scamander to buoy again a barbarian enough mannerly for the Priamidi’s fosterage? Who was he?"
count: 7
pattern: "es gibt|keine helena|no mothers|oxless"
kin:
  - "troy"
  - "mothers"
  - "christa wolf"
readers: [GB11]
---

‘Es gibt keine Helena, Christa? Fuck me, nein. Es gibt kein Alexander.’ — ‘There is no Mothers’; the oxless tangle’s trap won’t open without a mother’s presence.

> There is no Mothers.

- key · [[Once there were no masters. And yet the house was built]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[Browning’s grandmothers]]
- see · [[Powers that exist in absence]]
- see · [[Lisa]]
- see · [[Ida]]
