---
type: "motif"
voice: "Lyre"
source: thesis
section: "Cisness (2)"
position: 73.06
stations: [15]
locus: "T1122 · Cisness (2)"
count: 4
pattern: "female-to-female|male-to-male"
kin:
  - "transition"
  - "cisness"
readers: [GB13]
---

Peters’s joke — you can be a female-to-female or male-to-male transsexual; being cis does not preclude transition, Woodstock’s worry and Peters’s point alike.

> You can be a female-to-female transsexual.

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Cisatlantic holidays]]
- see · [[Transness as geist]]
