---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 76.82
stations: [16, 17]
locus: "T1192 · Winter"
count: 4
pattern: "have the right|their right|do i have to lower"
kin:
  - "rights"
  - "killing"
readers: [GB13]
---

Pin’s question, taken for a joke — ‘Ten fingers, all with bones in them’; ‘Sorry not to answer your question’; the shot; ‘Pin did fine. It’s their right.’

> “The right, Pin? It’s not about rights. There aren’t—.”

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Boneless and odd-numbered]]
- see · [[Kill the buddha]]
- see · [[Land own NAND vote]]
