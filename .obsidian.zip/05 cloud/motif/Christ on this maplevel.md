---
type: "motif"
voice: "mixed"
source: thesis
section: "Minoa Below"
position: 22.45
stations: [5, 19]
locus: "T0446 · Minoa Below"
count: 5
pattern: "\\bchrist\\b"
kin:
  - "christ"
  - "cults"
  - "worlds"
readers: [GB05]
---

‘It’s Christ or never’; ‘This maplevel had Christ – does that mean they had Rome?’; the over-cult with its Christ tyrant — Christianity as a maplevel’s oddity.

> Here where Greeks speak E’lish and there’s this over-cult with its Christ tyrant?

- key · [[Magic is nature from the future]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Iapeta’s husband]]
- see · [[Elysicester]]
