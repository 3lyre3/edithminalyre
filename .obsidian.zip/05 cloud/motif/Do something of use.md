---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 76.43
stations: [16, 17]
locus: "T1181 · Winter"
count: 7
pattern: "something of use|bring the city down|take some out"
kin:
  - "use"
  - "suicide"
  - "allies"
readers: [GB13]
---

Pin’s mockery — ‘If this woman were an ally, there’d be no replacement. She’d bring the city down. At least take some out.’; the lover coughing as she laughs.

> Do something of use.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Survival is no excuse for atrocity]]
- key · [[It’s a problem that I matter]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Horror without transmission]]
- see · [[Trans deaths as resource]]
- see · [[Expecting me not suicidal]]
