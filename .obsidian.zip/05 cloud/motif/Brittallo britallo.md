---
type: "motif"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [3]
locus: "P0253 · Dear Amaldéu (presentation, pp. 8–48)"
count: 8
pattern: "britallo|tale o bryto"
kin:
  - "chant"
  - "bryth"
readers: [GB18]
---

‘Brittallo britallo Britallo britallo britallo britallo Britallo britallo—’ — the chant introducing Britt’s chunk under Eighteen; ‘Tale o Bryto—’ under Seventeen.

> Brittallo britallo Britallo britallo britallo britallo Britallo britallo—

- key · [[Sister Aloysius must go to the movies]]
- key · [[Magic is nature from the future]]
