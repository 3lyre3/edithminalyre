---
type: "motif"
voice: "E"
source: thesis
section: "1"
position: 42.94
stations: [3, 7, 8]
locus: "T0793 · 1"
count: 8
pattern: "epsilon|omega|sigma|\\bmu\\b"
kin:
  - "letters and glyphs"
  - "e s archive"
readers: [GB08]
---

E’s glyph-play: an E too fast falls and dies; an epsilon too slow is an ω; a little omega can be me again; a sigma winds up a mu.

> But back on its feet a little omega can be me again.

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[All was brightness and knowing]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[It’s a problem that I matter]]
- see · [[E who thinks she’s me]]
