---
type: "motif"
voice: "E"
source: thesis
section: "1.236"
position: 34.26
stations: [2, 7, 19]
locus: "T0660 · 1.236"
count: 6
pattern: "it[’']s not you|someone else"
kin:
  - "e s archive"
  - "authorship"
readers: [GB07]
---

Bracketed interjections: ‘Why do I think the magical and the observable are dichotomic? I don’t. Am I pretending to think it? E, it’s not you. She’s someone else.’

> E, it’s not you. She’s someone else. Is obviously why.

- key · [[It’s a problem that I matter]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[All was brightness and knowing]]
- key · [[All the body needs is a taste]]
- see · [[Cassandra’s world untouched]]
- see · [[Daedalus titling in E’s voice]]
