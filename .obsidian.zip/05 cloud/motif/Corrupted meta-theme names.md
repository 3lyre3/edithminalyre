---
type: "motif"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 77.97
stations: [16]
locus: "T1217 · No, no Tiger"
count: 6
pattern: "oatmeal|oystershell|vantablanc|reread the wheel|elbow-journey|egregores"
kin:
  - "overwriting"
  - "translation conceit"
readers: [GB14]
---

The meta-theme’s names corrupted — ‘1. Oatmeal. 2. Milk. 3. Crushed oystershell.’; ‘Reread The Wheel…’; ‘M. Vantablanc is free but not to see you’; ‘not your wrist’.

> the meta-theme and narrative trend in trans writing I call 1. Oatmeal. 2. Milk. 3. Crushed oystershell.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Seeking presence]]
- see · [[This one I remember]]
- see · [[Reseasoned for anglophone appetite]]
