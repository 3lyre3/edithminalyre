---
type: "motif"
voice: "Pasiphaë"
source: thesis
section: "1.236"
position: 34.93
stations: [7]
locus: "T0671 · 1.236"
count: 3
pattern: "70 long pages|two-hundred little|spared you"
kin:
  - "e s archive"
  - "daedalus"
readers: [GB07]
---

Pasiphaë’s note: Daedalus (assuming it’s him) fills seventy pages describing every sheaf and slip picked from the archive floor — two hundred little descriptions; ‘I’ve spared you – you’re welcome.’

> fills 70 long pages with descriptions of every sheaf of embroidery, slip of paper, or spilled cluster of tea leaves

- key · [[It’s a problem that I matter]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[The archive grows]]
- see · [[Daedalus titling in E’s voice]]
- see · [[Epsilon recognised as M]]
- see · [[Icarus was too careful]]
