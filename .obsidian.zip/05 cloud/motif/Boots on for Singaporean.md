---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 85.16
stations: [2, 7, 17]
locus: "T1372 · the Adversary"
count: 8
pattern: "singaporean|noodle garden|\\bboots\\b"
kin:
  - "the adversary"
  - "shoes"
readers: [GB15]
---

Ra’s wood-soled heels clacking through the house — ‘I’m getting Singaporean, Lorelei. That’s why my boots are on.’; ‘Fuck you.’ ‘Don’t swear at me.’

> “The boots was funny, Ra. You never need to hide from me.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[Squow, squing, squoof]]
- see · [[Fern]]
