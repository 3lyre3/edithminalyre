---
type: "motif"
voice: "Lyre"
source: thesis
section: "Minoa Below"
position: 22.45
stations: [5, 6]
locus: "T0446 · Minoa Below"
count: 7
pattern: "lipless|unlatched her jaw|the face was to detach|cyborg"
kin:
  - "cyborg bodies"
  - "horror"
readers: [GB05]
---

E resolves her face detach, eyes let fall, a lipless jaw asking ‘Do I seem drunk to you?’; later she unlatches her jaw to inhale a cup whole.

> a lipless jaw and skull-less lips would ask, “Do I seem drunk to you? Which of us do you mean?”

- key · [[Magic is nature from the future]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Iapeta’s husband]]
- see · [[The avo-shake straw]]
- see · [[Rapid-aging]]
- see · [[The Shopkeeper]]
- see · [[Nymph of iron]]
- see · [[Lovecraft’s Yith]]
