---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 46.64
stations: [7, 9, 16]
locus: "T0844 · the Dark Materials"
count: 6
pattern: "cataract|soot-spot|lacrimal"
kin:
  - "eyes"
  - "overwriting"
  - "mothers"
readers: [GB09]
---

The thinning, greying crust under everyone’s eyes; constellating soot-spot-holes burned in every light; the infected lacrimal-sacs of mother and mother and her her the her.

> the constellating soot-spot-holes burned in every light concern inverted expeditions

- key · [[To live for the future is to live in glimmered moments]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[All was brightness and knowing]]
- see · [[Works within the ash]]
- see · [[Corrupted meta-theme names]]
- see · [[Es gibt keine Helena]]
- see · [[Taking the eye]]
- see · [[This one I remember]]
- see · [[Io]]
- see · [[Lisa]]
- see · [[Ida]]
