---
type: "motif"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 14.01
stations: [3]
locus: "T0355 · Quivering Haecceities"
count: 6
pattern: "tumour|meta-hospital"
kin:
  - "dysphoria"
  - "disability"
  - "medicine"
readers: [GB03]
---

Some tumours grow out benign, some are called beauty spots; any argument that malignant patients under-emphasise their specificity is insane — the meta-hospital of civilisation.

> In the meta-hospital of civilisation, ours is the only ward told to justify its lack of non-patient beds.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Trans–disabled solidarities]]
- see · [[Mental ailment no one sees]]
- see · [[Desert Eternal diagnostics]]
- see · [[Ankylosing spondylitis]]
- see · [[Engagement]]
- see · [[Transness as Debility (Baril)]]
