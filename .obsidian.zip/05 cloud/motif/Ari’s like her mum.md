---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 89.72
stations: [18]
locus: "T1441 · the Adversary Part Two"
count: 4
pattern: "like her mum|you[’']re like ari|via was too|little story ari"
kin:
  - "likeness"
  - "the adversary"
readers: [GB16]
---

‘Ari’s like her mum. You’re like Ari. Via was too. Thank God I didn’t go to the Mod.’ — ‘Send me what’s left of this little story Ari’s written.’

> Ari’s like her mum. You’re like Ari. Via was too.

- key · [[In stillness, all is clean]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Jupiter in the Daytime]]
