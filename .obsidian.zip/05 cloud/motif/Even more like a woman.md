---
type: "motif"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 69.46
stations: [14]
locus: "T1078 · Stamina"
count: 3
pattern: "more like a woman than i do|outright lie|fouled his tongue"
kin:
  - "lying"
  - "dysphoria"
readers: [GB12]
---

‘These days you look even more like a woman than I do’ — the one outright lie that fouled his tongue; dysphoria as psychological, not real, object.

> it was an outright lie, he always knew as he said it, and it fouled his tongue and guttered his appetite

- key · [[All was brightness and knowing]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[All the body needs is a taste]]
- see · [[Russian roulette lie]]
