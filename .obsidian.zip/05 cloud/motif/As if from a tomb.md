---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 47.45
stations: [9]
locus: "T0847 · the Dark Materials"
count: 3
pattern: "from a tomb|different language|communicative impasse"
kin:
  - "language"
  - "transition"
readers: [GB09]
---

Emmanuel’s narrator no longer accesses the thoughts that propelled her — ‘strange impulses emerging from a past self as if from a tomb’ — the communicative impasse of transition.

> It was like I had been speaking a different language, strange impulses emerging from a past self as if from a tomb.

- key · [[To live for the future is to live in glimmered moments]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Glimmers of comprehension]]
- see · [[Anton]]
- see · [[Norms do not exist]]
