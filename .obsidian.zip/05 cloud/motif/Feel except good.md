---
type: "motif"
voice: "Lyre"
source: thesis
section: "Riding Jupiter"
position: 98.86
stations: [20]
locus: "T1698 · Riding Jupiter"
count: 3
pattern: "feel except good|unlikely fortune"
kin:
  - "endings"
  - "fortune"
readers: [GB17]
---

‘I don’t know how to feel except good.’ → ‘What rare and unlikely fortune I should, at least now, know how to feel except good.’ — the thesis’s last line.

> What rare and unlikely fortune I should, at least now, know how to feel except good.

- key · [[There can be a tiger. You won’t let there be]]
- key · [[Optimism need not be teleological]]
