---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 74.45
stations: [3, 16]
locus: "T1140 · Winter"
count: 5
pattern: "werelight|holy bolt|eyebeam"
kin:
  - "light"
  - "weapons"
readers: [GB13]
---

The eyebeam-fire chewing through the supply-pack — ‘a brilliant, arcane werelight. Every rock is known’; a holy bolt across the chasmic tundra.

> The campfire’s aura is greater than ever, shining, a brilliant, arcane werelight. Every rock is known

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[All was brightness and knowing]]
- see · [[Supplies, not a flare]]
- see · [[Unfolding of the light]]
- see · [[The burned moth]]
