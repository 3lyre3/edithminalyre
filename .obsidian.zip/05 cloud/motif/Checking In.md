---
type: "motif"
voice: "unattributed"
source: thesis
section: "Cisness (2)"
position: 73.21
stations: [15]
locus: "T1124 · Cisness (2)"
count: 2
pattern: "checking in|a short history"
kin:
  - "editorial intrusion"
  - "thesis structure"
readers: [GB13]
---

‘{##: Checking In: follow up in A Short History}’ — an editorial marker left standing in the text, a promise to return.

> {##: Checking In: follow up in A Short History}

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Transgender should not exist]]
- see · [[L. Ipsum]]
- see · [[asdsad]]
- see · [[No, no Tiger (essay)]]
