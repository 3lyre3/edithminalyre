---
type: "motif"
voice: "Lyre"
source: thesis
section: "Cisness (2)"
position: 73.21
stations: [15, 17, 20]
locus: "T1124 · Cisness (2)"
count: 8
pattern: "bataille|baudrillard"
kin:
  - "citation"
  - "misattribution"
readers: [GB13]
---

‘It was at this historical juncture, roughly, that Georges Bataille wrote “We Are All Transsexuals Now”’ — the essay later credited, correctly, to Baudrillard; slip or mischief.

> It was at this historical juncture, roughly, that Georges Bataille wrote, “We Are All Transsexuals Now.”

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Transgender should not exist]]
- see · [[Baudrillard’s transsexuals]]
