---
type: "motif"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [12]
locus: "P0269 · Dear Amaldéu (presentation, pp. 8–48)"
kin:
  - "exits"
  - "presentation"
readers: [GB18]
---

‘[Exit— why Bunnings. Why Faerieland.]’ — the presentation’s closing stage direction.

> [Exit— why Bunnings. Why Faerieland.]

- key · [[Once there were no masters. And yet the house was built]]
- key · [[To live for the future is to live in glimmered moments]]
