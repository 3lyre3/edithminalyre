---
type: "motif"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.84
stations: [1]
locus: "T0126 · Coda"
kin:
  - "territory"
  - "arrival"
  - "borders"
readers: [GB01]
---

Metafiction as the mechanism by which False Cows fills out its customs-record and proves onward travel — territories, exclaves, arrivals, gates of comprehensibility.

> metafiction is the mechanism by which False Cows fills out its customs-record and proves its onward travel

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Passport need not be shown]]
