---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 10.23
stations: [3]
locus: "T0287 · Faerieland"
count: 5
pattern: "diamond beak|pentagonal|\\bbug\\b"
kin:
  - "carving creatures"
readers: [GB02]
---

Britt’s small bird with a diamond beak and midday-sky feathers; Night’s deep earth insect with a pentagonal frame; the bird crushes the bug back to symmetry.

> My bird dug for Night’s bug and yanked, licked its pentagonal frame into its diamond beak, crushed it back to symmetry.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Magic is nature from the future]]
- see · [[Red tooth and claw filtration]]
