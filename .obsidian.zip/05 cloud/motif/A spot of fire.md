---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 83.56
stations: [17]
locus: "T1332 · the Adversary"
count: 4
pattern: "secret stairs|spot of fire|one expression|garden there no one sees"
kin:
  - "cigarettes"
  - "secrets"
readers: [GB15]
---

‘Maybe you’ll find another pack abandoned by the secret stairs.’ ‘A spot of fire.’ ‘His one expression.’ — the cigarette packs binned, one kept, in the garden no one sees.

> there’s a garden there no one sees except me and whoever keeps getting these packs of cigarettes

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- see · [[What can anger witness]]
- see · [[Happy not to say]]
