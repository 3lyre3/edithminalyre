---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Jupiter in the Daytime"
position: 95.02
stations: [1, 19]
locus: "T1622 · the Adversary Jupiter in the Daytime"
count: 4
pattern: "\\bdoll\\b"
kin:
  - "address"
  - "the adversary"
readers: [GB17]
---

Lisa’s and Lorelei’s address — ‘Lisa. Doll. Do you mind watching my things?’; ‘Doll. These are analogies.’; ‘Get us coffee.’

> “Lisa. Doll. Do you mind watching my things?”

- key · [[All the body needs is a taste]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[These are analogies]]
- see · [[Nobody says a word]]
