---
type: "motif"
voice: "E"
source: thesis
section: "Minoa Below"
position: 24.6
stations: [5]
locus: "T0496 · Minoa Below"
count: 4
pattern: "fur-suit|cow-skin|rear flap"
kin:
  - "false cows"
  - "constructed bodies"
readers: [GB05]
---

Quadrupedal, maple-backed, bolted tight with uncured cow-skin, a rear flap for sexual entrance — the myth’s false cow, boarded before the labyrinth was built.

> Daedalus blueprinted and boarded a fur-suit for the queen, quadrupedal and maple-backed

- key · [[Magic is nature from the future]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Dante’s falsa vacca]]
- see · [[Bodies reshaped to plug in]]
