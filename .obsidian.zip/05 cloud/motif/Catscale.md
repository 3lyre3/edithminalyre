---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 7.95
stations: [2]
locus: "T0250 · Faerieland"
kin:
  - "bodies"
  - "tolerance"
readers: [GB02]
---

‘She had her own catscale’ — kissed, shuddered, vomited, kissed again; a private measure of tolerance.

> Then we kissed. Shuddered. She vomited. Kissed again. She had her own catscale.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[All the body needs is a taste]]
- see · [[Not uranium]]
- see · [[Scarification tattooist]]
- see · [[Ways I differ from you]]
