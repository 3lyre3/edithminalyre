---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 10.33
stations: [3, 10]
locus: "T0294 · Faerieland"
count: 2
pattern: "blocked"
kin:
  - "night"
  - "aftermath"
readers: [GB02]
---

Night blocked Britt on everything, discovered on the fugueless trudge from the Shimmerlands; Britt didn’t care enough to chase Night’s friends.

> I checked my devices and saw Night blocked me on everything.

- key · [[Sister Aloysius must go to the movies]]
- key · [[It’s a problem that I matter]]
- see · [[Screenshots as evidence]]
