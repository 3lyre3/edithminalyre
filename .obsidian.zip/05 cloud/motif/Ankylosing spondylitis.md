---
type: "motif"
voice: "Lyre"
source: thesis
section: "The Still Truth or I Don't See You at All"
position: 40.71
stations: [8]
locus: "T0741 · The Still Truth or I Don't See You at All"
count: 7
pattern: "spondylitis|ankylosing|cancer people|bend their spines"
kin:
  - "disability"
  - "autobiography"
  - "medical groups"
readers: [GB08]
---

‘When I was twelve, I developed ankylosing spondylitis’; online groups for people who went through similar things; grateful no one calls them a religious community who refuse to bend.

> a religious community for people who refuse to bend their spines

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[It’s a problem that I matter]]
- see · [[Special agonies without language]]
- see · [[Black spots on the gums]]
- see · [[You know what colour]]
- see · [[Transness as Debility (Baril)]]
- see · [[Watch E go]]
- see · [[The doctor checked]]
