---
type: "motif"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 56.01
stations: [11]
locus: "T0964 · Sun Pink"
count: 5
pattern: "other christmas|anaemic|walloon|balenciaga"
kin:
  - "sun pink"
  - "parallel worlds"
readers: [GB10]
---

Ellis a stone, bearer of impossible news from invisible other Christmas parties — too virginal, skies too anaemic — where reactions are envy and desire, not fear.

> the bearer of impossible news from invisible, other Christmas parties, but those parties existed. Only, he didn’t like them.

- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Christmas Eve’s dreadful quiet]]
- see · [[Picture a happy future]]
- see · [[Alive in Melbourne]]
- see · [[The face in the mud]]
