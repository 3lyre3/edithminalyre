---
type: "motif"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 17.83
stations: [4, 8, 9, 17, 19]
locus: "T0384 · Correction 25"
count: 10
pattern: "embarrass"
kin:
  - "pleasure"
  - "suffering"
readers: [GB04]
---

‘Embarrassment, even in a vacuum, contains its pleasures’ — he will never again experience anything so pleasurable; the interview’s small, exact cruelty.

> as my condition assigns, I will never experience anything so pleasurable as embarrassment, never again

- key · [[Survival is no excuse for atrocity]]
- key · [[It’s a problem that I matter]]
- see · [[The pain condition]]
- see · [[Toying at one’s focus]]
- see · [[Agency separating from consciousness]]
- see · [[Suffering doesn’t keep]]
