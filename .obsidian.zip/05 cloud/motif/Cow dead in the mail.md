---
type: "motif"
voice: "Lyre"
source: thesis
section: "Riding Jupiter"
position: 97.83
stations: [20]
locus: "T1694 · Riding Jupiter"
count: 4
pattern: "dead in the mail|the bull is jupiter|rides it in|morning radio"
kin:
  - "cows"
  - "counterpublics"
readers: [GB17]
---

‘The bull is Jupiter. The cow comes dead in the mail.’ — the counterpublic riding it in to manifest as public-proper on morning radio news.

> The cow comes dead in the mail.

- key · [[There can be a tiger. You won’t let there be]]
- key · [[It’s a problem that I matter]]
