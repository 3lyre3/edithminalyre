---
type: "motif"
voice: "E"
source: thesis
section: "1.9"
position: 30.53
stations: [5, 6]
locus: "T0591 · 1.9"
count: 4
pattern: "i didn[’']t write this|why would i\\?"
kin:
  - "e s archive"
  - "authorship"
readers: [GB06]
---

‘Again, I didn’t write this. Why would I?’ — E disowning the Fitzroy anecdote, the archive’s authorship contested line by line.

> Again, I didn’t write this. Why would I?

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[E, it’s not you]]
- see · [[Sorry for moving it]]
