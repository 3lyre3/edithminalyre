---
type: "motif"
voice: "Pasiphaë"
source: thesis
section: "Further…"
position: 86.9
stations: [18]
locus: "T1410 · Further…"
count: 2
pattern: "told i[’']m wrong|making assertions"
kin:
  - "method"
  - "pasipha"
readers: [GB15]
---

Pasiphaë’s analytic method — ‘making assertions then waiting to be told I’m wrong’ — accesses alien to genius.

> my analytic method is making assertions then waiting to be told I’m wrong

- key · [[In stillness, all is clean]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
