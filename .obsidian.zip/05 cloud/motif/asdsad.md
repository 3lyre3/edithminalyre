---
type: "motif"
voice: "unattributed"
source: draft
section: "Dear Ama (draft — unique paragraphs)"
locus: "D0045 · Dear Ama (draft — unique paragraphs)"
kin:
  - "drafts"
  - "noise"
readers: [GB18]
---

The draft’s stray keystroke paragraph — ‘asdsad’ — a hand resting on the keys.

> asdsad

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
