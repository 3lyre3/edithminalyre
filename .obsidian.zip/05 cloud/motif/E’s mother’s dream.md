---
type: "motif"
voice: "E"
source: thesis
section: "Minoa Below"
position: 22.88
stations: [4, 5, 9, 10, 16, 17]
locus: "T0450 · Minoa Below"
count: 10
pattern: "my mother, she was|nursery chamber|schizophrenic"
kin:
  - "mothers"
  - "infancy"
  - "dreams"
  - "divine rape"
readers: [GB05]
---

E’s schizophrenic mother dreams a nursery walled from screams and invaders, and must suffocate the infant lest bellowing guide them in — so the newborn is discarded without trail.

> not to be raped she was compelled to suffocate me, lest my bellowing guide the invaders in

- key · [[Magic is nature from the future]]
- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Box on the Scamander]]
- see · [[Jupiter, god of rape]]
- see · [[Lysandria]]
- see · [[The oneiropomp]]
- see · [[Cataracts and soot-spot-holes]]
- see · [[Es gibt keine Helena]]
- see · [[Lisa]]
- see · [[Ida]]
