---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 48.77
stations: [9]
locus: "T0860 · the Dark Materials"
count: 3
pattern: "conversion therapy|hangs herself|pederast"
kin:
  - "houses"
  - "suicide"
readers: [GB09]
---

The haunting begins in a wife’s despair at her husband’s outing as pederast and homosexual; the incomplete frame’s voice promises the secrets of conversion therapy and she hangs herself.

> A voice (the house’s voice) promises to teach her the secrets of conversion therapy and, at the revelation of those unknown secrets, she hangs herself.

- key · [[To live for the future is to live in glimmered moments]]
- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[The fascist House]]
- see · [[The Atmospherean academic]]
