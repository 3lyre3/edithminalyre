---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 74.45
stations: [1, 3, 6, 7, 8, 9, 10, 12, 15, 16]
locus: "T1140 · Winter"
count: 25
pattern: "roach"
kin:
  - "winter"
  - "slurs"
readers: [GB13]
---

‘Say roach’ — Josef loathing ‘Atmospherean’, that considerate speech denying the hatred needed to survive; the roaches disciplined, well-mannered; ‘Told you so, in Cloudroach.’

> How Josef loathed that. ‘Atmospherean.’ This considerate, unprovocative speech. Say roach.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Survival is no excuse for atrocity]]
- see · [[They’re people]]
- see · [[Supplies, not a flare]]
