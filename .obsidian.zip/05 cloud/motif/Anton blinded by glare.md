---
type: "motif"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 55.18
stations: [11]
locus: "T0946 · Sun Pink"
count: 4
pattern: "scintilla|silverpink|no lights|eyeball burst"
kin:
  - "light"
  - "blindness"
readers: [GB10]
---

Half the world scintilla and char, sight dripping like a burst eyeball, the open plan lit silverpink; a countertop that is Aeon’s spaulders; something soft breaking under a heel.

> “It’s the lights. I need a place that’s totally no lights.”

- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[All was brightness and knowing]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Aeon]]
- see · [[Fred’s dragons]]
- see · [[Arcane werelight]]
- see · [[The burned moth]]
- see · [[His radiant sightlessness]]
- see · [[Subtlety’s glasshouse light]]
- see · [[Unfolding of the light]]
