---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 92.34
stations: [16, 17, 18]
locus: "T1504 · the Adversary Part Two"
count: 4
pattern: "stomach england|can[’']t stomach|stomach[’']s"
kin:
  - "england"
  - "stomachs"
readers: [GB16]
---

‘“flat.” I can’t stomach England.’ ‘no one can.’ — stomachs throughout: Lo’s sick one, Paxie’s, everyone’s not-thinking.

> “flat.” I can’t stomach England.

- key · [[In stillness, all is clean]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[All the body needs is a taste]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
