---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 75.68
stations: [2, 5, 10, 16]
locus: "T1173 · Winter"
count: 8
pattern: "bars are|ceasefire|squinted"
kin:
  - "honesty"
  - "prisons"
readers: [GB13]
---

The academic: ‘Look, jail was the goal. It’s ceasefire but it’s war… That’s all the bars are, Mr Losse. They’re honesty.’ — squinting at ‘you’, smiling at ‘we’.

> Say our honesty is excessive. Be honest yourself.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[All was brightness and knowing]]
- see · [[The Atmospherean academic]]
- see · [[Cops’ cleanness]]
- see · [[V-coding]]
- see · [[Prisons on prisons]]
