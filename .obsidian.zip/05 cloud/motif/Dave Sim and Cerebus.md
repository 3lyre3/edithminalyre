---
type: "motif"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 67.62
stations: [14]
locus: "T1073 · Stamina"
count: 6
pattern: "dave sim|cerebus|aardvark"
kin:
  - "conventions"
  - "comics"
readers: [GB12]
---

The convention fan asking whether Sam knew Dave Sim, read Cerebus — he never had, laughed at, unconvinced; Cerebus the Aardvark questions unheard while he rehearsed the breakup.

> He never heard of Dave Sim nor Cerebus and told the fan as much. They laughed, unconvinced.

- key · [[All was brightness and knowing]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[A tier of allyship]]
