---
type: "motif"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 80.55
stations: [17]
locus: "T1250 · No, no Tiger"
count: 3
pattern: "christmas eve|by invitation|meaning quiet"
kin:
  - "christmas"
  - "exclusion"
readers: [GB14]
---

Vicky at fourteen admitting, on the far side of ‘the dreadful meaning quiet of Christmas Eve’, there would be no tiger; not part of the world, not by invitation.

> The world around her would not be hers and she would not be part of it, at least – the Queens at Heart-interviewer reminds her – not by invitation.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[In stillness, all is clean]]
- see · [[No Lo]]
