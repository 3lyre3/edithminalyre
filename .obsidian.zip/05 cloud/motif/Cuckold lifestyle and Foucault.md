---
type: "motif"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 78.97
stations: [3, 17]
locus: "T1220 · No, no Tiger"
count: 6
pattern: "cuckold|foucault|too old"
kin:
  - "repression"
  - "denial"
readers: [GB14]
---

Darryl’s objections — too old to be trans; trans women aren’t happy; critics fail the cuckold-lifestyle; enthusiasm for his boyfriend a byproduct of penis-centred heterosexuality, citing Foucault.

> The enthusiasm he feels for his boyfriend is a simple byproduct of his heterosexuality, a paradigm that necessarily centres the penis. He cites Foucault.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[All the body needs is a taste]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[Not in a trans way]]
- see · [[Repressor in a car]]
- see · [[Psychosomatic certainty]]
- see · [[You gave a suicide-device]]
