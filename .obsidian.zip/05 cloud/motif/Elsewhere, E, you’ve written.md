---
type: "motif"
voice: "Pasiphaë"
source: thesis
section: "Further…"
position: 86.13
stations: [17]
locus: "T1404 · Further…"
count: 2
pattern: "elsewhere, e,|you[’']ve written"
kin:
  - "attribution"
  - "letters"
readers: [GB15]
---

Pasiphaë quoting E’s own words from the cisness essay — ‘if the force of cisness deems you a fitting host…’ — the essay thereby attributed to E.

> Elsewhere, E, you’ve written: “if the force of cisness deems you a fitting host…

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[In stillness, all is clean]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Transness as geist]]
- see · [[Delva, Iata Quay]]
