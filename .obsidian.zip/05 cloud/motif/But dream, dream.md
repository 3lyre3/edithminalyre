---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 7.33
stations: [1, 2, 4, 5, 6, 8, 9, 11, 18, 19, 20]
locus: "T0238 · Faerieland"
count: 21
pattern: "\\bdream"
kin:
  - "dreams"
readers: [GB02]
---

‘We are the dead and dreaming is dying. But dream. Dream.’ — Night’s scarcely audible yell at the performance’s end, the factory’s darkness cheering her name.

> We are the dead and dreaming is dying. But dream. Dream.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Optimism need not be teleological]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Magic is nature from the future]]
- see · [[E’s mother’s dream]]
- see · [[Lysandria]]
- see · [[The oneiropomp]]
