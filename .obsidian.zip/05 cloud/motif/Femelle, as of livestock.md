---
type: "motif"
voice: "Lyre"
source: thesis
section: "I’ve met him, Paxie."
position: 64.25
stations: [13, 20]
locus: "T1052 · I’ve met him, Paxie."
count: 8
pattern: "femelle|saint-point|livestock"
kin:
  - "cows"
  - "femaleness"
readers: [GB12]
---

Valentine de Saint-Point: a woman without masculine virtues is ‘a female’ — femelle, as said of livestock, not people; femaleness as anti-futurist force.

> The word here in French is femelle, as said of livestock, not people.

- key · [[Optimism need not be teleological]]
- key · [[All the body needs is a taste]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[There can be a tiger. You won’t let there be]]
- see · [[Females (Chu)]]
- see · [[Euthanised by eight]]
- see · [[Sex produced where gender denied]]
- see · [[Not enough woman]]
- see · [[Cow dead in the mail]]
