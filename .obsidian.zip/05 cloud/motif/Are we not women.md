---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 90.79
stations: [18]
locus: "T1464 · the Adversary Part Two"
count: 3
pattern: "are we not women|greenblue|quilts and throws"
kin:
  - "women"
  - "rooms"
readers: [GB16]
---

Gathering across couches, room by room — ‘why not; there is nowhere else; are we not women?’ — spread across her quilts, throws, greenblue cushions.

> why not; there is nowhere else; are we not women?

- key · [[In stillness, all is clean]]
- key · [[All the body needs is a taste]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[Blackholes and emptiness]]
