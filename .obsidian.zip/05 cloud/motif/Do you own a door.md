---
type: "motif"
voice: "unattributed"
source: thesis
section: "a"
position: 59.11
stations: [12]
locus: "T0999 · a"
kin:
  - "houses"
  - "title chains"
readers: [GB11]
---

‘a / house / a / door — do you own a door?’ — the title-fragments assembling a house toward ‘And yet the house was built’.

> —do you own a door?

- key · [[Once there were no masters. And yet the house was built]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[The transsexual house]]
- see · [[Through the library, a city]]
- see · [[Why we built the normative]]
