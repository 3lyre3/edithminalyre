---
type: "motif"
voice: "E"
source: thesis
section: "Minoa Below"
position: 23.84
stations: [5]
locus: "T0474 · Minoa Below"
count: 2
pattern: "both guards|nice paradox"
kin:
  - "trust"
  - "paradox"
  - "mazes"
readers: [GB05]
---

‘If the mazemaker’s trustworthy, why aren’t I? Both guards can be trusted and each says: don’t trust the other. Nice paradox. You fucked up.’

> Both guards can be trusted and each says: don’t trust the other.

- key · [[Magic is nature from the future]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Ten-thousand circles of repression]]
- see · [[Epsilon recognised as M]]
- see · [[Women who were men]]
