---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Jupiter in the Daytime"
position: 96.99
stations: [20]
locus: "T1688 · the Adversary Jupiter in the Daytime"
count: 6
pattern: "euthanised|cupboard place|mooing|livestock is destroyed"
kin:
  - "cows"
  - "radio"
readers: [GB17]
---

The radio: Wolfroyals near Cupboard Place woken by a mooing cow; a vehicle struck the lady visitor — ‘You never say euthanised for livestock?… people won’t mind.’

> If we say euthanised, people won’t mind.

- key · [[There can be a tiger. You won’t let there be]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Cow dead in the mail]]
