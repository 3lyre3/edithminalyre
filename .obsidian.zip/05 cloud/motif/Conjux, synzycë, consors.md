---
type: "motif"
voice: "Lyre"
source: thesis
section: "[Series of letters]"
position: 57.3
stations: [11]
locus: "T0986 · [Series of letters]"
count: 6
pattern: "conjux|synzyc|consors"
kin:
  - "marriage"
  - "gender vocabulary"
readers: [GB11]
---

Armeria’s words for partner-in-marriage — conjux, synzycë, consors; a same-sex marriage, both feminine in attire; a citizenry assigned female at birth; nonbinary meaning ‘not binary’.

> the alternate, apparently less common equivalents for partner-in-marriage (other than “conjux”) which are “synzycë” and “consors”

- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Armeria]]
- see · [[Melanie Taylor’s ungenerous reading]]
