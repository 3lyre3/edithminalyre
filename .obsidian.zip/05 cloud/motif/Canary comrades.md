---
type: "motif"
voice: "E"
source: thesis
section: "“We are all Transsexuals Now”"
position: 82.2
stations: [4, 17]
locus: "T1308 · “We are all Transsexuals Now”"
count: 8
pattern: "canar|comrade|cave-in"
kin:
  - "sacrifice"
  - "revolution"
readers: [GB14]
---

The Twitter user thanking his ‘trans comrades’ — sacrificed as a canary whose cries lay bare the ruling class’s intent. ‘A canary won’t stop a cave-in.’

> He saw and acknowledged us.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Optimism need not be teleological]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Andor’s prison break]]
- see · [[Impurity of heart]]
- see · [[Farce, the fate of revolution]]
- see · [[Not the rapture]]
- see · [[Twitter bloat analysis]]
- see · [[God’s blood]]
