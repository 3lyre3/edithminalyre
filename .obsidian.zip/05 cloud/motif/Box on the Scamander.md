---
type: "motif"
voice: "E"
source: thesis
section: "Minoa Below"
position: 22.88
stations: [5, 12]
locus: "T0450 · Minoa Below"
count: 7
pattern: "scamander|oceanus|in a box"
kin:
  - "infancy"
  - "rivers"
  - "troy"
readers: [GB05]
---

Dad sat E in a box on the Scamander, on to Oceanus, past the gates into Cimmerian waters — Troy’s currency, bearing his face, stuffed into the newborn’s coffin.

> Sneaking cash into the coffin of the newborn you’re – for all you know – about to drown

- key · [[Magic is nature from the future]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[E’s mother’s dream]]
- see · [[E was Paris]]
- see · [[The ferrycreature’s Styx]]
- see · [[Christa Wolf]]
- see · [[The Scamander]]
- see · [[Es gibt keine Helena]]
