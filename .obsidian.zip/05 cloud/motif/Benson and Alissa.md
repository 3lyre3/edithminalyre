---
type: "motif"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 53.96
stations: [10, 11]
locus: "T0929 · Sun Pink"
count: 19
pattern: "benson|backpacker|\\balim\\b|nevena"
kin:
  - "accusation"
  - "sun pink"
readers: [GB10]
---

Benson’s claim that Alissa stole backpackers’ IDs and demanded sex; a year before anyone asked the backpackers; Benson trying to defame himself; his surgery, his leaving the city.

> Benson was trying to defame himself, to create proof of his own dishonesty.

- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- see · [[Alissa]]
- see · [[What’s true doesn’t matter]]
- see · [[Peter’s forgotten balcony]]
