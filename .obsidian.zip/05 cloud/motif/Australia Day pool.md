---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 88.99
stations: [18]
locus: "T1430 · the Adversary Part Two"
count: 4
pattern: "australia day|rashie|suicide ratios|card details"
kin:
  - "australia"
  - "adolescence"
readers: [GB16]
---

Fern’s past — the unwitting mother typing card details, the special-access account, tears on a rashie as a teenager screams male-to-female suicide ratios, nation after nation.

> a teenager screams the suicide ratios of males to females, nation after nation, a thousand outrages upon the callousness of women

- key · [[In stillness, all is clean]]
- key · [[Survival is no excuse for atrocity]]
- key · [[It’s a problem that I matter]]
