---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 9.13
stations: [2, 3, 8, 16, 18]
locus: "T0270 · Faerieland"
count: 15
pattern: "\\bcarv"
kin:
  - "carving creatures"
readers: [GB02]
---

Carvings: an eelwolf with a lupine jaw, a jackalope with ginger human hair, a diamond-beaked bird, a pentagonal earth insect — made to mate, fretting and humping at nothing.

> The rodent tried to mate, too, the way carvings will.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Magic is nature from the future]]
- key · [[All the body needs is a taste]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[The election of creatures]]
- see · [[The eelwolf]]
- see · [[The jackaloid]]
- see · [[Bird and bug]]
