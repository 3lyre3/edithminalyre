---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 76.83
stations: [16]
locus: "T1195 · Winter"
count: 3
pattern: "boneless|odd-numbered|ten fingers"
kin:
  - "bodies"
  - "radiation"
readers: [GB13]
---

Marigail’s jibe: the youngest New Franciscans spawn boneless and odd-numbered; her grin growing as the leaden chunk carves a gutter through her crown.

> “Ten fingers, all with bones in them,” Marigail said.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[There can be a tiger. You won’t let there be]]
- see · [[Dismemberment cis people can’t see]]
