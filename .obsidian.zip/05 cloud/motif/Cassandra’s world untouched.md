---
type: "motif"
voice: "E"
source: thesis
section: "1.236"
position: 34.44
stations: [7]
locus: "T0661 · 1.236"
count: 2
pattern: "cassandra[’']s world|bothering earth"
kin:
  - "e s archive"
  - "earth"
  - "cassandra"
readers: [GB07]
---

Bracketed E: ‘We swore never to unbalance anything on Cassandra’s world and never, ever to go there. Why is this person bothering Earth?’

> Why is this person bothering Earth?

- key · [[It’s a problem that I matter]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[The archive grows]]
- see · [[The air is draining]]
