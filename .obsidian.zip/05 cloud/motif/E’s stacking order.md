---
type: "motif"
voice: "E"
source: thesis
section: "Key Terms"
position: 22.4
stations: [5]
locus: "T0442 · Key Terms"
count: 4
pattern: "three es|stacked all this|order i read|time travelled only"
kin:
  - "e s archive"
  - "thesis structure"
readers: [GB04]
---

E’s editorial interjections marking the archive’s sequence: ‘I’ve stacked all this in the order I read it… The next has three Es. There aren’t any with two.’

> We time travelled only a little, me only a little, Cassandra more.

- key · [[Magic is nature from the future]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[EEE]]
- see · [[Sorry for moving it]]
- see · [[E was Paris]]
- see · [[Works within the ash]]
