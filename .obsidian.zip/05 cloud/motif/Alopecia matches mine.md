---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 7.54
stations: [2]
locus: "T0241 · Faerieland"
kin:
  - "bodies"
  - "resemblance"
readers: [GB02]
---

‘The pattern of her alopecia matches mine before the tilt’ — bodies aligned by hair loss, rethought while the terminal’s rivets course her.

> the pattern of her alopecia matches mine before the tilt and she raped you one time. One.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[All the body needs is a taste]]
- see · [[Catscale]]
