---
type: "motif"
voice: "Pasiphaë"
source: thesis
section: "city. Through the library, there’s a city."
position: 71.65
stations: [15]
locus: "T1102 · city. Through the library, there’s a city."
count: 2
pattern: "where[’']ve you gone|thoughts are missed"
kin:
  - "letters"
  - "absence"
readers: [GB12]
---

‘E, where’ve you gone? Your thoughts are missed.’ — Pasiphaë’s sign-off; the correspondence lapsing as E travels.

> E, where’ve you gone? Your thoughts are missed.

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Minoa Below]]
- see · [[Absence embodied as tiger]]
- see · [[Blackholes and emptiness]]
- see · [[Technically missing]]
- see · [[At last, kill it]]
- see · [[Powers that exist in absence]]
