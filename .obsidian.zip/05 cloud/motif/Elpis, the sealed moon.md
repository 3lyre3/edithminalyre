---
type: "motif"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 53.69
stations: [10]
locus: "T0927 · Sun Pink"
count: 9
pattern: "elpis|pandora"
kin:
  - "prophecy"
  - "myth"
  - "moons"
readers: [GB10]
---

Pandora’s jar ends with the flight of Elpis, not Hope — a second moon the sky never got, embodiment of Prophecy, stopped up by Zeus; our forgotten, earthbound moon.

> No one bar Pandora and Zeus glimpsed Elpis – our now forgotten, earthbound moon

- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Optimism need not be teleological]]
- see · [[Secret hope]]
- see · [[Irene Clyde’s prophecy]]
