---
type: "motif"
voice: "Pasiphaë"
source: thesis
section: "1.236"
position: 35.04
stations: [7]
locus: "T0673 · 1.236"
count: 3
pattern: "möbius|mobius|for an m\\b|one-sided"
kin:
  - "e s archive"
  - "letters and glyphs"
  - "mazes"
readers: [GB07]
---

An epsilon-marked, one-sided scroll Pasiphaë recognises for an M; ‘I know what a Möbius strip is’; Daedalus builds mazes in higher dimensions, lying to no standard but his own.

> Pasiphaë at last recognised it for an M.

- key · [[It’s a problem that I matter]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[All was brightness and knowing]]
- see · [[Es, epsilons, omegas, mus]]
- see · [[Contradiction-tolerant universe]]
- see · [[Daedalus titling in E’s voice]]
