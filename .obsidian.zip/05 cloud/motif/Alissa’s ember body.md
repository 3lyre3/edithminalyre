---
type: "motif"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 54.31
stations: [4, 6, 10, 11, 12, 19, 20]
locus: "T0935 · Sun Pink"
count: 16
pattern: "reed-leaves|embers|eyeless face|smoulder"
kin:
  - "embers"
  - "bodies"
  - "sun pink"
readers: [GB10]
---

Since the surgery a limbless cloud of ever-smouldering reed-leaves, warming the atrium with each breath, eyeless; the wordless message ‘Bitch, you struggle with what’s real. Clean up the bit.’

> Bitch, you struggle with what’s real. Pay attention to the mess you’re making in this real, actual room.

- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[All the body needs is a taste]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Survival is no excuse for atrocity]]
- see · [[The rotating heater]]
- see · [[Irigaray’s lips]]
