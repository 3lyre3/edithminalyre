---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 92.1
stations: [18]
locus: "T1496 · the Adversary Part Two"
count: 4
pattern: "did see a girl|jule-type|heart broke|lonely hunt"
kin:
  - "heartbreak"
  - "secrets"
readers: [GB16]
---

The jule-type Fern saw but didn’t tell Ari — ‘it’s my fault. fern’s big on getting her heart broke’; ‘would the heart but meet its lonely hunt’.

> would the heart but meet its lonely hunt

- key · [[In stillness, all is clean]]
- key · [[All the body needs is a taste]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Miseratio maledictus]]
