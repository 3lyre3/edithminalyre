---
type: "motif"
voice: "Lyre"
source: thesis
section: "Cisness (2)"
position: 71.84
stations: [15]
locus: "T1109 · Cisness (2)"
count: 2
pattern: "bumpers|switching lanes"
kin:
  - "argument"
  - "cisness"
readers: [GB13]
---

Arguing ‘cis’s’ usefulness for trans community is bowling with the bumpers up — so switching lanes to the word’s merits for cis people.

> To argue ‘cis’s’ usefulness for trans community is to bowl with the bumpers up

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Torrey Peters]]
