---
type: "motif"
voice: "Lyre"
source: thesis
section: "Winter"
position: 75.5
stations: [16, 17]
locus: "T1172 · Winter"
count: 14
pattern: "blood rain|the genius"
kin:
  - "atrocity"
  - "illegibility"
readers: [GB13]
---

Guts washed from gloves, dripping down the clouds onto the bereaved; no describing, no explaining — always the genius of it; his son’s blood in his mouth.

> there is no describing, no explaining, a Blood Rain: always the genius of it

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Survival is no excuse for atrocity]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[Illegibility and spectacle]]
- see · [[Horror without transmission]]
- see · [[Horror and genius are one]]
- see · [[The siloed soul’s groundhog-day]]
- see · [[Suffering doesn’t keep]]
- see · [[Tyra Hunter]]
- see · [[V-coding]]
- see · [[The laser-green highlighter]]
