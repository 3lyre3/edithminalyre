---
type: "motif"
voice: "Lyre"
source: thesis
section: "Minoa Below"
position: 25.8
stations: [5, 6]
locus: "T0511 · Minoa Below"
count: 4
pattern: "\\beee\\b|three es"
kin:
  - "e s archive"
readers: [GB05]
---

‘E flew from Pasiphaë’s hand. In its place landed EEE.’ — the archive’s volumes as E’s name multiplied; ‘The next has three Es. There aren’t any with two.’

> Then she sat beside EEE and reburied herself in E’s meditations.

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[All was brightness and knowing]]
- see · [[Es, epsilons, omegas, mus]]
- see · [[Again, I didn’t write this]]
