---
type: "motif"
voice: "unattributed"
source: thesis
section: "Ra & Ra"
position: 92.9
stations: [5, 6, 18]
locus: "T1521 · Ra & Ra"
count: 6
pattern: "black spots|\\bgums\\b|contort upon|reaves"
kin:
  - "illness"
  - "the sublime"
readers: [GB16]
---

‘when black spots foul the red of your gums, bones contort upon themselves, migraines sing so bright there is no darkness… except death’ — a walk among the reaves.

> what better prescription than a walk among the reaves and the full, fresh air of God’s universe?

- key · [[In stillness, all is clean]]
- key · [[All the body needs is a taste]]
- see · [[Hegel on magic]]
- see · [[His radiant sightlessness]]
