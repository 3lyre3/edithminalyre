---
type: "motif"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 77.31
stations: [7, 16]
locus: "T1213 · No, no Tiger"
count: 6
pattern: "adhesiveness|rubbing up|getting stuck"
kin:
  - "dissociation"
  - "muchi"
readers: [GB14]
---

Muchi wondering at others’ frictions — ever rubbing up on stuff, getting stuck on things, the adhesiveness of their social being — and why she was not like them.

> the adhesiveness of their social being – wondered why she was not like these others

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[In stillness, all is clean]]
- key · [[It’s a problem that I matter]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Unshareably great destiny]]
- see · [[Seeking presence]]
- see · [[Hands in the ice bowl]]
- see · [[Easy to think around]]
- see · [[I Saw the TV Glow]]
