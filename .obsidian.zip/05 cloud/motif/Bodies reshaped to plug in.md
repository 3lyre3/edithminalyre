---
type: "motif"
voice: "Lyre"
source: thesis
section: "1.9"
position: 29.14
stations: [6]
locus: "T0570 · 1.9"
count: 5
pattern: "\\bikea\\b|spikes|poodle"
kin:
  - "cosmic horror"
  - "constructed bodies"
readers: [GB06]
---

Elbow rods, spikes through shoulders and knees, mesh over mouths — bodies redesigned to fit slots like Ikea diagrams; the old lady with the poodle first through the hole.

> Just like those horrible Ikea diagrams Damini showed us.

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Dismemberment cis people can’t see]]
- see · [[Make the shapes]]
