---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.02
stations: [2, 6]
locus: "T0225 · Faerieland"
count: 2
pattern: "watching light"
kin:
  - "oaths and stamps"
  - "light"
readers: [GB02]
---

The oath’s witnesses — the Darkness and the Watching Light, the Un-Raped Mother and Faer Avatar in the Wealds, Faer Imperial Radiance, and God.

> before the Darkness and the Watching Light, before the Un-Raped Mother and Faer Avatar in the Wealds

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[All was brightness and knowing]]
- see · [[Blatance, Faer Radiance]]
- see · [[Grey, gold, grey strobe]]
- see · [[Aura]]
- see · [[Aufgaolaí police oath]]
