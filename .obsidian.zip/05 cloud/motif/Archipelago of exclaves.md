---
type: "motif"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.06
stations: [1, 2, 3, 9, 10, 11, 12, 17]
locus: "T0119 · Coda"
count: 20
pattern: "archipelago|exclave|enclave"
kin:
  - "territory"
  - "community"
readers: [GB01]
---

Trans community as an archipelago of ex/enclaves, enclosed by a thousand alien systems, its en- and exclaves stitching and pulling together.

> restrict our community to an archipelago of ex/enclaves

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Survival is no excuse for atrocity]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Semantic striations]]
- see · [[Customs-record and onward travel]]
- see · [[Lugones’s ontological pluralism]]
- see · [[Voice of trans community]]
