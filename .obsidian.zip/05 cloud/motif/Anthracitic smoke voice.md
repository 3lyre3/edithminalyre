---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 84.79
stations: [17]
locus: "T1356 · the Adversary"
count: 3
pattern: "anthractic|kitchen sink-tv|melody to noise"
kin:
  - "voices"
  - "noise"
readers: [GB15]
---

Fernanda’s voice — half-damp bursts splattering the walls, draping every note, birdsong to traffic, music to kitchen sink-TV, melody to noise.

> voice an anthractic smoke, a clutter of half-damp bursts that splattered the walls

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[In stillness, all is clean]]
- see · [[asdsad]]
