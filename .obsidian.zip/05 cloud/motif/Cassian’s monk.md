---
type: "motif"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 14.86
stations: [3]
locus: "T0362 · Quivering Haecceities"
count: 5
pattern: "cassian|stole bread|the monk"
kin:
  - "confession"
readers: [GB03]
---

John Cassian’s monk who stole bread and at first could not tell: evil is hidden and unstated; only when he confesses verbally does the devil go out of him.

> Only when he confesses verbally does the devil go out of him.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Confession as truth’s mark]]
- see · [[Nothing left to witness]]
- see · [[The worst poem]]
