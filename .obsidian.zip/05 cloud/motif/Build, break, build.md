---
type: "motif"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.14
stations: [2, 3, 7, 9, 12]
locus: "T0231 · Faerieland"
count: 34
pattern: "\\bbuild\\b|the breaking is"
kin:
  - "building"
  - "prions"
  - "speech"
readers: [GB02]
---

The silver-lettered text on Red’s accuser’s back: build, let the building break you, tear your tongue lengthwise and learn to speak again — ‘proteinaceous infectious praxis’.

> Build. Build again. Build a next thing. A next. Build. Let the building break you.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[Prions]]
- see · [[Red’s famous article]]
- see · [[Hot Allostatic Load]]
- see · [[Build with the body]]
- see · [[The pit]]
- see · [[Truth created by speech]]
