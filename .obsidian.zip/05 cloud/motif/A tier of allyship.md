---
type: "motif"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 67.72
stations: [3, 14]
locus: "T1074 · Stamina"
count: 5
pattern: "allyship|road to damascus|curtsey|clawed hand"
kin:
  - "conventions"
  - "misreading"
readers: [GB12]
---

The fan’s praise — the fall of Fall as Road to Damascus for a trans masc narrative; ‘your girlfriend – she’s trans, right?’; her clawed hand’s feathery gesture.

> a tier (that was her word, “tier”) of allyship nobody aspired to or dared hope for

- key · [[All was brightness and knowing]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Signs and Symbols (Nabokov)]]
