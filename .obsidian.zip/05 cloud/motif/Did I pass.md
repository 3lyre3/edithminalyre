---
type: "motif"
voice: "unattributed"
source: thesis
section: "[Series of letters]"
position: 59.1
stations: [12]
locus: "T0994 · [Series of letters]"
count: 3
pattern: "did i pass|is it over|miss you"
kin:
  - "letters"
  - "passing"
readers: [GB11]
---

‘Cassandra, / Did I pass? / Is it over? / Miss you.’ — a four-line letter; passing as examination and as gender; the prophetess addressed.

> Did I pass?

- key · [[Once there were no masters. And yet the house was built]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[E, where’ve you gone]]
- see · [[Talk slow, E]]
