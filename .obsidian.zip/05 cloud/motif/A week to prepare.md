---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 89.77
stations: [18]
locus: "T1448 · the Adversary Part Two"
count: 4
pattern: "week – by her estimate|nothing else is possible|does nothing else|method that leaves"
kin:
  - "suicide"
  - "waiting"
readers: [GB16]
---

Ari closes on a method leaving about a week to prepare; time to wait; coffee, then bed. ‘Nothing else is possible. She does nothing else.’

> Nothing else is possible. She does nothing else.

- key · [[In stillness, all is clean]]
- key · [[It’s a problem that I matter]]
- see · [[Fern’s raid]]
- see · [[Alternative to killing myself]]
