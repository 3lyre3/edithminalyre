---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Jupiter in the Daytime"
position: 95.81
stations: [19]
locus: "T1648 · the Adversary Jupiter in the Daytime"
count: 3
pattern: "spoon|both were tops|workmanlike"
kin:
  - "sex"
  - "sleep"
readers: [GB17]
---

Lisa asking to spoon; ten minutes unsleeping; ‘each started the exhausted work of making the other finish. Both were tops, predominantly. Workmanlike.’; waking inside the same two minutes.

> Both were tops, predominantly. Workmanlike.

- key · [[All the body needs is a taste]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- see · [[Immaculate timeline]]
