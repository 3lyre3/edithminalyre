---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 90.56
stations: [18]
locus: "T1462 · the Adversary Part Two"
count: 4
pattern: "syphilitic|keep ari from the floor|what keeps her aright|spidered legs"
kin:
  - "bodies"
  - "witness"
readers: [GB16]
---

Fern’s sight of Ari — yellows and greens, wrenched shoulders, bloodless lilac lips; ‘i want to catch ari, keep ari from the floor’; what keeps her aright she cannot teach.

> Dying, syphilitic animal: hectic, falling.

- key · [[In stillness, all is clean]]
- key · [[All the body needs is a taste]]
- see · [[Blackholes and emptiness]]
