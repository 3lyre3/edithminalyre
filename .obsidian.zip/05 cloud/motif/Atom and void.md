---
type: "motif"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 52.41
stations: [10]
locus: "T0915 · Sun Pink"
count: 3
pattern: "atom and void|empty and empty|nonworld"
kin:
  - "truth"
  - "nothingness"
readers: [GB10]
---

Democritus’s ‘atom and void’ — the Hereafter of Reality, ‘empty and empty’, a nonworld containing no truth nor the source of any; reality as the depths of the well.

> ‘Atom,’ intones Democritus, ‘and void’ make up the Hereafter of Reality, a world he calls ‘empty and empty,’ i.e. a nonworld

- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[In stillness, all is clean]]
- see · [[Truth from the well]]
- see · [[Merciless calms]]
- see · [[Higher attunement contracted]]
