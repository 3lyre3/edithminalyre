---
type: "motif"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [15]
locus: "P0091 · Dear Amaldéu (presentation, pp. 8–48)"
count: 2
pattern: "note-you|eyen|transliteration"
kin:
  - "translation conceit"
  - "danaeam"
readers: [GB18]
---

The glossed Danaeam chunks — ‘Note-you-build’, ‘Red-of accuser’ya’, ‘Ey’ey’eyes’es’es’, the Eyen-dreamer as deconstructed ‘avatar’ — the translations E annotates in green.

> And Britt? Look at your transliterations:

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[The laser-green highlighter]]
- see · [[Brittallo britallo]]
- see · [[E’s marginal comments]]
