---
type: "motif"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 88.45
stations: [5, 18]
locus: "T1423 · the Adversary Part Two"
count: 4
pattern: "bathwater|burned so cold|rub some dust"
kin:
  - "dust"
  - "baths"
readers: [GB16]
---

Ida rubbing dust off in the bath — always so much, too much; ‘the bathwater turned to dust, like that. everything burned so cold.’

> the bathwater turned to dust, like that. everything burned so cold.

- key · [[In stillness, all is clean]]
- key · [[All the body needs is a taste]]
- see · [[Picture a happy child]]
