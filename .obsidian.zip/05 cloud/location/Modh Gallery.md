---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.58
stations: [2]
locus: "T0235 · Faerieland"
kin:
  - "galleries"
  - "performance"
readers: [GB02]
---

Where Red’s cutups are pasted to the walls with boxy speakers beneath, repeating a scratch in her natural affect as the scratch of the audio.

> cutups pasted to Modh Gallery’s walls and small boxy speakers pasted underneath

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Quivering Haecceities]]
- see · [[Innocence that rings]]
- see · [[Watch E go]]
