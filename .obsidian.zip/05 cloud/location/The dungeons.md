---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 10.45
stations: [1, 3, 10]
locus: "T0295 · Faerieland"
count: 3
pattern: "dungeon"
kin:
  - "scenes"
readers: [GB02]
---

‘The days I still went to dungeons’ — the scene Britt has left, where the tattooist was seen and never spoken to.

> in the days I still went to dungeons

- key · [[Sister Aloysius must go to the movies]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Scarification tattooist]]
