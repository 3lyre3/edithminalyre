---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.12
stations: [2]
locus: "T0226 · Faerieland"
count: 2
pattern: "sgiesaetthum"
kin:
  - "state"
  - "execution"
readers: [GB02]
---

The Faerish polity whose longest era without execution of incarcerated aufGaolaí runs from 2983 to the story’s present, 2997.

> 2983 to today marks the Sgiesaetthum’s longest era without execution, formal or otherwise, of incarcerated aufGaolaí.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
