---
type: "location"
voice: "Lyre"
source: thesis
section: "1.236"
position: 34.44
stations: [7, 19]
locus: "T0661 · 1.236"
count: 4
pattern: "melbourne"
kin:
  - "melbourne"
  - "autobiography"
readers: [GB07]
---

Where the author’s tenure through the portentous years 2023–2026 takes place — guaranteeing pieces that emerge as performative responses to live events.

> that my tenure through the portentous years of 2023-2026 shall take place in Old Melbourne guarantees as much

- key · [[It’s a problem that I matter]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Composition as struggle]]
- see · [[Ankylosing spondylitis]]
