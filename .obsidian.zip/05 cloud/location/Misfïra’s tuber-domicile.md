---
type: "location"
voice: "Lyre"
source: thesis
section: "Intersection"
position: 31.8
stations: [6, 7]
locus: "T0606 · Intersection"
count: 4
pattern: "tuber-domicile|amber-bright grove|\\bhovel\\b|autumn-themed dwelling"
kin:
  - "intersection"
  - "houses"
readers: [GB06]
---

The giant-tuber-domicile, dug-in and vast, mammalian vines draping the windows — later ‘gorgeous, autumn-themed’; the amber-bright grove and its strangled stage nearby.

> entered to Misfïra’s giant-tuber-domicile, spread their reedy, Accendish bodies throughout the vast, dug-in living space

- key · [[It’s a problem that I matter]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[Four is quorum]]
- see · [[The strangest wounds]]
- see · [[Tell Me I’m Worthless]]
