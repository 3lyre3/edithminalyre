---
type: "location"
voice: "Lyre"
source: thesis
section: "Faerieland"
position: 11.03
stations: [3, 16]
locus: "T0313 · Faerieland"
count: 5
pattern: "forsaken archive|werelight"
kin:
  - "e s archive"
  - "libraries"
readers: [GB02]
---

Bound records and doors deep in the red-rocked cavern inside the cow: books flapping their bindings, werelights reddening, a thin bold volume marked E.

> So Pasiphaë’s feet carried her to the Forsaken Archive, our records there bound, our doors thereabout.

- key · [[Sister Aloysius must go to the movies]]
- key · [[All was brightness and knowing]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[The epsilon]]
- see · [[Winged books]]
- see · [[The archive grows]]
- see · [[Through the library, a city]]
