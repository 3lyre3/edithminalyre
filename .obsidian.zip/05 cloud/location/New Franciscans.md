---
type: "location"
voice: "Lyre"
source: thesis
section: "Winter"
position: 74.21
stations: [1, 16, 17]
locus: "T1139 · Winter"
count: 17
pattern: "new francisc"
kin:
  - "winter"
  - "the surface"
readers: [GB13]
---

The surface people of the lowermost rocks — dullness, soft flat teeth, ‘They eat you kind. Eat you slow.’; anarchist communes without rules; the Tins as life itself.

> Their teeth grow soft and flat. They eat you kind. Eat you slow.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Atmosphere, above the clouds]]
- see · [[There aren’t rules]]
- see · [[The Tins]]
- see · [[Cloudroach]]
