---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.23
stations: [2]
locus: "T0258 · Faerieland"
count: 2
pattern: "melamix|sol[eé]ice"
kin:
  - "waste"
readers: [GB02]
---

Where non-aluminium ‘recyclables’ actually go, paired with Soléice Loch Recovery Centre in Britt’s knowledge of the pickups.

> what pickups go to MelaMix Regional Landfill and which to Soléice Loch Recovery Centre

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[It’s a problem that I matter]]
- see · [[Recycling route map]]
