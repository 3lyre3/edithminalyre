---
type: "location"
voice: "E"
source: thesis
section: "My stomach’s sick."
position: 74.18
stations: [5, 6, 16]
locus: "T1135 · My stomach’s sick."
count: 6
pattern: "minoa below|cyclolite|my stomach[’']s sick"
kin:
  - "letters"
  - "crete"
  - "flight"
readers: [GB13]
---

‘Paxie, my stomach’s sick. Get a cyclolite or a Heltix… everywhere in Novel Elysia. Fly one to Minoa Below. Let’s meet.’

> Fly one to Minoa Below. Let’s meet.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Iapeta Café, Monemvasia]]
- see · [[Can’t stomach England]]
