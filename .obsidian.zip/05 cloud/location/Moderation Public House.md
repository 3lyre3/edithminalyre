---
type: "location"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 84.33
stations: [17, 18, 19]
locus: "T1341 · the Adversary"
count: 6
pattern: "moderation public|the mod\\b|the mod[’']s"
kin:
  - "pubs"
  - "the adversary"
readers: [GB15]
---

The Mod — booths, slatted windows, the tree line marching one inch a century, vines picking at Anna’s skin; the doors falling in for Variance.

> The tree line outside Moderation Public House marched slow, one inch one century, another the next.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Optimism need not be teleological]]
- see · [[Anna, Ria, Eden]]
- see · [[Io]]
- see · [[Ari’s like her mum]]
