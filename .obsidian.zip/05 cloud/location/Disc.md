---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.8
stations: [2]
locus: "T0237 · Faerieland"
count: 3
pattern: "\\bdisc\\b"
kin:
  - "channels"
  - "distance"
readers: [GB02]
---

The mini-clade’s cod-et-al. channel, never called by name: ‘Wish we were on Disc’ versus ‘let me come to you’; where they get, much later, on.

> (We referred to the mini-clade’s cod et al. channel as ‘Disc,’ never by name.)

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[The portable station]]
