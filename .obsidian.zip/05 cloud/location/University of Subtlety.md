---
type: "location"
voice: "Lyre"
source: thesis
section: "the Adversary Jupiter in the Daytime"
position: 93.85
stations: [19]
locus: "T1602 · the Adversary Jupiter in the Daytime"
count: 5
pattern: "university of subtlety|nobel|fields medallist|teal vest"
kin:
  - "universities"
  - "subtlety"
readers: [GB17]
---

Three resident Nobel laureates and a Fields medallist — a favourite among second favourites; students expecting proximity to irradiate their careers; bright teal vests; Eden’s downtime.

> in the Asian and West Pacific region, Subtlety is a favourite among second favourites

- key · [[All the body needs is a taste]]
- key · [[All was brightness and knowing]]
- see · [[No pronoun for Eden]]
- see · [[Subtlety’s glasshouse light]]
