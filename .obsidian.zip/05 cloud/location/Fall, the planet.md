---
type: "location"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 66.65
stations: [14, 15, 18]
locus: "T1071 · Stamina"
count: 8
pattern: "planet fall|of fall\\b|fall endures|fall[’']s destruction|fall had returned|fall of fall"
kin:
  - "stamina"
  - "alternate worlds"
readers: [GB12]
---

Success’s home planet, destroyed, surface antigenerated — the planet that never would; endures in all but one universe in a billion; ‘Always and forever Fall endures.’

> Always and forever Fall endures, ma’am, in this and every timeline!

- key · [[All was brightness and knowing]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[The Transitory Opera]]
- see · [[Isabel Fall]]
- see · [[Goodnight, Nuke York]]
- see · [[Asymptotic fact]]
- see · [[Stitched into his universe]]
