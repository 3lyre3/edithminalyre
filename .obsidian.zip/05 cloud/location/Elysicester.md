---
type: "location"
voice: "E"
source: thesis
section: "Minoa Below"
position: 23.05
stations: [5, 6, 15]
locus: "T0452 · Minoa Below"
count: 7
pattern: "elysicester|elysium|elysian|cimmerian"
kin:
  - "mazes"
  - "worlds"
  - "cities"
readers: [GB05]
---

Capital of Elysium, or really of the Intermaze — the tissue- and nerve-network bonding every maplevel — with gates at twenty-K intervals and an inland port like a Central Station.

> Elysicester, the capital of Elysium, or the Intermaze really, the tissue- and nerve-network bonding every maplevel

- key · [[Magic is nature from the future]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Optimism need not be teleological]]
- see · [[Lysandria]]
- see · [[Both guards can be trusted]]
- see · [[Ten-thousand circles of repression]]
- see · [[Epsilon recognised as M]]
