---
type: "location"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 83.89
stations: [17, 18, 19, 20]
locus: "T1338 · the Adversary"
count: 12
pattern: "subtlety|charing abutment|salt faces"
kin:
  - "cities"
  - "light"
readers: [GB15]
---

The city — the bus descent through ray-sheets off the plateaus’ salt faces; Subtlety Street Station’s too-hot latte; the Charing Abutment subway to Wolfroy.

> She would never imagine the latte was burned.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[All was brightness and knowing]]
- see · [[Saulia]]
- see · [[Inter-Metropolitan Transport Vehicle]]
- see · [[Wolfroy]]
- see · [[University of Subtlety]]
- see · [[Subtlety’s glasshouse light]]
- see · [[His radiant sightlessness]]
- see · [[The city in its copse]]
