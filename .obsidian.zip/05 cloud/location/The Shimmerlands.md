---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.68
stations: [2, 3]
locus: "T0261 · Faerieland"
count: 3
pattern: "shimmerland"
kin:
  - "festival"
  - "light"
readers: [GB02]
---

The realm of festival raised for the moot, under lilac canyons over emerald seas, summerlight crackling and oozing with leystick; not a toe outside for the duration.

> under lilac canyons over emerald seas, to the Shimmerlands and the realm of festival there raised

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Leystick and the leyweb]]
- see · [[The moot]]
- see · [[Speedy Ana’s chin]]
