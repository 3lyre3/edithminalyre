---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.8
stations: [2]
locus: "T0237 · Faerieland"
count: 3
pattern: "townhouse|window door|front lower gate"
kin:
  - "houses"
readers: [GB02]
---

Britt’s rear- and front-enterable townhouse with its front lower gate and back upper window door — the rooms where the first event happens.

> the rear- and front-enterable townhouse I live in

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[The portable station]]
- see · [[Misfïra’s tuber-domicile]]
