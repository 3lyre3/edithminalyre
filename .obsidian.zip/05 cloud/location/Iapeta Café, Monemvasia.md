---
type: "location"
voice: "E"
source: thesis
section: "“We are all Transsexuals Now”"
position: 83.14
stations: [5, 17, 18]
locus: "T1312 · “We are all Transsexuals Now”"
count: 13
pattern: "iapeta|monemvasia|2656|fully agree"
kin:
  - "letters"
  - "greece"
readers: [GB14]
---

E’s sign-off — 3 June 2656 b.c., Iapeta Café & Cocktail Bar, Portside Esp., Monemvasia; Pasiphaë’s reply: ‘I don’t fully agree.’

> I don’t fully agree.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Magic is nature from the future]]
- see · [[Delva, Iata Quay]]
- see · [[Sy-duîm tes Stár]]
- see · [[Further (Pasiphaë’s letter)]]
