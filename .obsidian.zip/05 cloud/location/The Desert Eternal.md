---
type: "location"
voice: "E"
source: thesis
section: "Minoa Below"
position: 23.2
stations: [5, 7]
locus: "T0456 · Minoa Below"
count: 3
pattern: "desert eternal|the desert\\b"
kin:
  - "deserts"
  - "machines alive"
readers: [GB05]
---

A planet crusted with holographic ruins and roaming, taskless androids — where E slept a thousand years and was rapid-aged to survive by her own power.

> a planet crusted with holographic ruins and roaming, taskless androids

- key · [[Magic is nature from the future]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[The Shopkeeper]]
- see · [[Desert Eternal diagnostics]]
