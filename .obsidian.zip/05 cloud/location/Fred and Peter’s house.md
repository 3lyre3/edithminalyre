---
type: "location"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 51.71
stations: [2, 3, 7, 8, 10, 11]
locus: "T0895 · Sun Pink"
count: 12
pattern: "succulent-bed|open plan|atrium|patio"
kin:
  - "houses"
  - "sun pink"
readers: [GB10]
---

The Christmas venue — yard and succulent-bed, patio steps, middle atrium, the too-bright open plan, Peter’s personal room in darkness, the forgotten upstairs balcony.

> atop the night-dampened pebbles of the fence-side succulent-bed

- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[All was brightness and knowing]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Peter’s forgotten balcony]]
- see · [[Velle]]
- see · [[Do you own a door]]
