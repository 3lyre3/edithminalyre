---
type: "location"
voice: "Lyre"
source: thesis
section: "[Series of letters]"
position: 57.3
stations: [11]
locus: "T0986 · [Series of letters]"
count: 8
pattern: "armeria"
kin:
  - "alterity"
  - "utopia refused"
readers: [GB11]
---

Clyde’s country ruled by a queen — trading with ‘barbarians’ for their softer offspring, slave-owning, its slaves’ quarters like a prison — not a utopia but an alterity.

> Evidently, the work does not present a utopia, but an alterity.

- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Optimism need not be teleological]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Slavery as satirical parallel]]
- see · [[Gesture beyond reality]]
