---
type: "location"
voice: "Ten Years On narrator"
source: thesis
section: "Ten Years On"
position: 26.29
stations: [6]
locus: "T0530 · Ten Years On"
count: 7
pattern: "br[óo]dlainn"
kin:
  - "cities"
  - "faerieland politics"
readers: [GB05]
---

The Faerish city of the 2983 riots — CBD, Inner Bródlainnis, Greater Bródlainn across the bog Cen Eitil; Bryth’s birthplace; now infantry on the ground, Beag sí aloft.

> infantry on the ground, recruits from the Beag sí aflutter across the sky

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Survival is no excuse for atrocity]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[The Bródlainn Riots]]
- see · [[Kelly v. Fiade]]
- see · [[Towns that build walls]]
