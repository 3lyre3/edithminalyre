---
type: "location"
voice: "mixed"
source: thesis
section: "Faerieland"
position: 8.68
stations: [2]
locus: "T0261 · Faerieland"
count: 5
pattern: "mionchain"
kin:
  - "cities"
  - "faerieland"
readers: [GB02, GB17]
---

Britt’s adopted city — faer fraught tenure there for a soft-attentioned Waver’s benefit; the moot call sounding for every localisable region of sentience in Mionchain.

> every citizen, person, localisable region of sentience in Mionchain

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[The moot]]
- see · [[Bródlainn]]
- see · [[The moot and the Carving]]
- see · [[Region 86.16.5]]
- see · [[Letter from Ama]]
