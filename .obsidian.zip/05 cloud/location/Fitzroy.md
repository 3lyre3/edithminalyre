---
type: "location"
voice: "Lyre"
source: thesis
section: "1.9"
position: 30.25
stations: [6]
locus: "T0582 · 1.9"
kin:
  - "melbourne"
  - "music"
readers: [GB06]
---

The Melbourne suburb of the gig — a real place in the thesis’s one ‘quick funny story’.

> My partner and I, both trans, were at a gig in Fitzroy.

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[The Fitzroy gig]]
- see · [[Old Melbourne]]
- see · [[Satisfying dissatisfaction]]
- see · [[SOPHIE’s Immaterial]]
