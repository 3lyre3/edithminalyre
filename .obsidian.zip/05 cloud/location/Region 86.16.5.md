---
type: "location"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 15.15
stations: [3, 4]
locus: "T0367 · Correction 25"
count: 3
pattern: "86\\.16\\.5"
kin:
  - "correction 25"
  - "cities"
readers: [GB04]
---

The maplevel of the centreless city: a valley of molten radiance up a cornvine-ridden trail, a debris trash-ring at the city’s edge, geosmotic foglands beyond.

> proceeded by the gateline to region 86.16.5

- key · [[Sister Aloysius must go to the movies]]
- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Maplevels]]
- see · [[The city with no centre]]
- see · [[Chalhotra, Chestwick, Hammings]]
