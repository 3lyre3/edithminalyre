---
type: "location"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [15]
locus: "P0090 · Dear Amaldéu (presentation, pp. 8–48)"
count: 3
pattern: "forsaken archives|future-selves|future or alternate self"
kin:
  - "archives"
  - "future selves"
readers: [GB18]
---

Where E’s future- or alternate-selves wrote what she reads lately — the thrashing argument against Gill-Peterson: ‘underestimates the arcane potential of stamps on paper.’

> A lot of my future-selves wrote a lot of what I’m reading lately in the Forsaken Archives.

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[E’s marginal comments]]
