---
type: "location"
voice: "mixed"
source: thesis
section: "Minoa Below"
position: 25.36
stations: [6, 15, 16]
locus: "T0502 · Minoa Below"
count: 7
pattern: "lysandria|\\blysia\\b"
kin:
  - "cities"
  - "dreams"
  - "elysium"
  - "letters"
  - "mirrors"
readers: [GB05, GB12]
---

Capital of Lysia in the Novel Elysian state: drear, damp, nothing grows; ostriches ferry travellers, books roam the air, mirrorways line the arcades — ‘Air now. You are drowning.’

> Visitors to Lysandria recall beds, dreams, surfaces… brittle concrete pillows calling to sleep.

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[The Mirrors]]
- see · [[Through the library, a city]]
- see · [[Sísia, cisness]]
- see · [[Minoa Below]]
- see · [[Iapeta Café, Monemvasia]]
- see · [[Bródlainn]]
- see · [[The oneiropomp]]
- see · [[The face in the mud]]
- see · [[Did I pass]]
