---
type: "location"
voice: "Ten Years On narrator"
source: thesis
section: "Ten Years On"
position: 26.62
stations: [6]
locus: "T0533 · Ten Years On"
count: 4
pattern: "f[ée]thweald|the wets\\b"
kin:
  - "faerieland geography"
readers: [GB05]
---

Faerieland’s far regions — ‘across the wets and out in the Féthwealds’ — where the riots’ ley-disturbance was felt by no more than forty people.

> across the wets and out in the Féthwealds, it was (reportedly) felt by no more than forty people

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Riots felt in the ley-web]]
