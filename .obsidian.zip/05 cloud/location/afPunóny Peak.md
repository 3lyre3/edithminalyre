---
type: "location"
voice: "Ama"
source: ama
section: "Letter from Ama"
locus: "A0004 · Letter from Ama"
count: 4
pattern: "punóny|hungary|trenchlands"
kin:
  - "faerieland"
  - "mountains"
readers: [GB17]
---

The uplands’ greatest mass, afPunóny-cum-Hungary, from beneath which Faerie rose; the valleylands, lowlands and trenchlands falling to the waves.

> Of the uplands no mass greater than afPunóny’s-cum-Hungary’s there lay.

- key · [[Once there were no masters. And yet the house was built]]
- key · [[Magic is nature from the future]]
- see · [[Clades of waves and mounds]]
