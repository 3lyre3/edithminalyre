---
type: "location"
voice: "Lyre"
source: thesis
section: "False Cows (2)"
position: 4.76
stations: [2]
locus: "T0154 · False Cows (2)"
kin:
  - "cliffs"
  - "false cows"
readers: [GB01]
---

Where the white bull paces all day and glances at the drop — Minoa’s coastal edge in the Daedalus story.

> All day long he paces by the Salt Cliff

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[There can be a tiger. You won’t let there be]]
- see · [[Asterion]]
