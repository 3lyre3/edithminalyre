---
type: "location"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 87.33
stations: [18]
locus: "T1419 · the Adversary Part Two"
count: 6
pattern: "\\bsilos?\\b|silos[’']"
kin:
  - "the adversary"
  - "industry"
readers: [GB16]
---

A domain of dried cement and silver dust where factory-smoke writhes as dragons; the holy shadow of three silos spilling concrete and weaponry east and west.

> over every rocky, dead-grass home looms the holy shadow of the three silos

- key · [[In stillness, all is clean]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Ari]]
- see · [[The dust]]
