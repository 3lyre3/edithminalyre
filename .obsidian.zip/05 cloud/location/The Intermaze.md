---
type: "location"
voice: "mixed"
source: thesis
section: "Key Terms"
position: 21.08
stations: [2, 5, 16]
locus: "T0433 · Key Terms"
count: 6
pattern: "intermaze|heltix"
kin:
  - "mazes"
  - "cassandra"
  - "bars"
readers: [GB04]
---

Through which the Heltix bore E and Cassandra in a barred chamber, Cassandra’s remains rotted and dried until a crackle came back to her eyes (Lyre 2021).

> rotted and dried in the barred chamber of the Heltix that bore us through the Intermaze

- key · [[Magic is nature from the future]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Optimism need not be teleological]]
- see · [[Lyre 2021 (Cassandra)]]
- see · [[Elysicester]]
- see · [[The city in its copse]]
- see · [[Iapeta’s husband]]
- see · [[Gracious Monemvasia]]
- see · [[Both guards can be trusted]]
- see · [[Ten-thousand circles of repression]]
- see · [[Epsilon recognised as M]]
