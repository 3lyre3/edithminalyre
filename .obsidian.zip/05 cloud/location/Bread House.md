---
type: "location"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 68.72
stations: [14]
locus: "T1076 · Stamina"
count: 5
pattern: "bread house"
kin:
  - "parties"
  - "sex"
readers: [GB12]
---

The grimy, too-yellow bedroom where Sam and Josephine first fucked, every guest overhearing his furious, almost mournful screams; the ex calling five times; the town crier.

> Next Friday, in a grimy, too-yellow, Bread House bedroom, Sam and Josephine fucked

- key · [[All was brightness and knowing]]
- key · [[All the body needs is a taste]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- see · [[Loud during sex]]
- see · [[Both were tops]]
