---
type: "location"
voice: "Pasiphaë"
source: thesis
section: "Further…"
position: 87.32
stations: [18]
locus: "T1415 · Further…"
count: 2
pattern: "delva|iata quay"
kin:
  - "letters"
  - "places"
readers: [GB15]
---

Pasiphaë’s sign-off — 18 June 2656 b.c., Delva, Iata Quay.

> 18 June 2656 b.c. Delva, Iata Quay

- key · [[In stillness, all is clean]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Ra & Ra (section)]]
