---
type: "location"
voice: "Lyre"
source: thesis
section: "False Cows"
position: 0.01
stations: [1]
locus: "T0015 · False Cows"
count: 3
pattern: "neo-memphis|pyramyd"
kin:
  - "cities"
  - "job interviews"
readers: [GB01]
---

The Pyramyd of Neo-Memphis in the lathermost ancienes of the Ages of Neon — site of the opening interview; a future-ancient Egypt.

> te ancien Pyramyd of Neo-Memphis is a trancen Fenene seacher asclymb

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Ages of Neon opening]]
- see · [[Beth]]
- see · [[Mionchain]]
