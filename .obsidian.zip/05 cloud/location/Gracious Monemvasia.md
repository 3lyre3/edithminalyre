---
type: "location"
voice: "Lyre"
source: thesis
section: "Minoa Below"
position: 22.45
stations: [5, 17, 18]
locus: "T0446 · Minoa Below"
count: 4
pattern: "monemvasia"
kin:
  - "cities"
  - "bars"
  - "minoa"
readers: [GB05]
---

The far-up rocky esplanade with Iapeta’s husband’s cocktail bar and café, the chiselled shopping-tunnel beneath — E’s sick-of-it Minoan drinking place, revisited later.

> the far-up, rocky esplanade of Gracious Monemvasia

- key · [[Magic is nature from the future]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Iapeta’s husband]]
- see · [[The avo-shake straw]]
- see · [[Elysicester]]
