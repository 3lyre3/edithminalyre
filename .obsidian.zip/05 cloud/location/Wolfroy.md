---
type: "location"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 83.89
stations: [17, 19, 20]
locus: "T1338 · the Adversary"
count: 11
pattern: "wolfroy"
kin:
  - "the adversary"
  - "suburbs"
readers: [GB15]
---

The suburb where Lo was born — Subtlety its city, capital of Saulia; arcades and avenues; Wolfroy Noodle Garden; the back-arcades where the white bull steps.

> Wolfroy was the suburb, Subtlety the city. Capital of Saulia.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[In stillness, all is clean]]
- see · [[Saulia]]
- see · [[Subtlety]]
- see · [[Moderation Public House]]
