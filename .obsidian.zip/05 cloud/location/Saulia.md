---
type: "location"
voice: "Lyre"
source: thesis
section: "the Adversary"
position: 83.89
stations: [17, 18, 19, 20]
locus: "T1338 · the Adversary"
count: 24
pattern: "saulia|the sink\\b"
kin:
  - "nations"
  - "underground"
readers: [GB15]
---

A city-state 96% underground — in the plateaus — with the world-famous Sink; Federal Australia gifted the surrounding land in 2005; classificatory ambiguities with their own Wikipedia section.

> Given Saulia’s 96% underground residence (or residence, as Saulians will say, in the plateaus)

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[Subtlety]]
- see · [[Wolfroy]]
- see · [[Triptych (for mental health)]]
- see · [[Subtlety’s glasshouse light]]
- see · [[Made in Abyss]]
- see · [[Rainforest under the Sink]]
- see · [[Wet bulb catastrophe]]
