---
type: "location"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.51
stations: [2, 5, 18]
locus: "T0234 · Faerieland"
count: 4
pattern: "factory"
kin:
  - "venues"
  - "performance"
readers: [GB02]
---

The performance venue: a nest up on stage, a hundred-head audience despite shrouding and shadows, a rooftop above railside cement.

> the factory’s darkness cheered her name

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Rooftop cigarette]]
- see · [[Modh Gallery]]
- see · [[Innocence that rings]]
- see · [[Watch E go]]
