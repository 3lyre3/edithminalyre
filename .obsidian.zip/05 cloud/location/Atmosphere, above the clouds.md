---
type: "location"
voice: "Lyre"
source: thesis
section: "Winter"
position: 74.21
stations: [3, 14, 15, 16, 17, 18, 19]
locus: "T1139 · Winter"
count: 20
pattern: "atmosphere\\b|atmospherean|floating (?:city|metropolis)|under-crust"
kin:
  - "winter"
  - "cities"
readers: [GB13]
---

Marigail’s home — unpoisoned, crystalline cities drifting the sky, under-crusts of bones, a prison-for-a-belly, ad boards and traffic arrows; souls intact at birth.

> the unpoisoned and crystalline cites that drift the sky

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[There can be a tiger. You won’t let there be]]
- see · [[Marigail]]
- see · [[Cloudroach]]
- see · [[The Atmospherean academic]]
- see · [[Souls intact at birth]]
- see · [[I don’t want the universe]]
- see · [[Saulia]]
- see · [[New Franciscans]]
- see · [[Subtlety]]
