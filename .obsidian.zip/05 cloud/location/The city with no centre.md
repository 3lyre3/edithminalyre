---
type: "location"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 15.8
stations: [4]
locus: "T0371 · Correction 25"
count: 5
pattern: "no centre|without a centre|centreless|city with no|lacks a centre"
kin:
  - "cities"
  - "nothingness"
readers: [GB04]
---

A city jutting from the earth without suburbs, roads or stations, its core a positive nothingness; every city has a centre — this one’s is not even ‘not a centre’.

> A city without a centre? All the pages of all of our many kinds of books were the wrong shape for something like that

- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[Positive nothingness]]
- see · [[The pit]]
- see · [[Gracious Monemvasia]]
- see · [[Arrival from Nothing]]
- see · [[Atom and void]]
- see · [[Higher attunement contracted]]
