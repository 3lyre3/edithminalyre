---
type: "location"
voice: "E"
source: thesis
section: "C1DA"
position: 5.89
stations: [2, 5, 16]
locus: "T0218 · C1DA"
count: 3
pattern: "heltix"
kin:
  - "bars"
  - "drinking places"
readers: [GB01]
---

Where the colours play in the messmist — the bar, and bars, at which E tells Cassandra how the documentary began.

> The colours were playing all in the messmist and Heltix’s bars

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Optimism need not be teleological]]
- see · [[The messmist]]
- see · [[The Intermaze]]
- see · [[Minoa Below]]
- see · [[Bars are honesty]]
- see · [[Gracious Monemvasia]]
- see · [[Iapeta’s husband]]
