---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.46
stations: [1, 7, 12, 13, 20]
locus: "T0121 · Coda"
count: 21
pattern: "fictoanaly|numbers by paint"
kin:
  - "haecceity"
  - "method"
readers: [GB01, GB07]
---

The sub-method of fictocriticism from Numbers by Paint: aesthetic receptions adapted into new forms that comment on and enrich their sources — the thesis’s own method.

> a subtype of fictocritical imagined in my Master’s thesis (Numbers by Paint) as ‘fictoanalytic.’

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[All was brightness and knowing]]
- key · [[It’s a problem that I matter]]
- see · [[Fictocriticism (Gibbs)]]
- see · [[Common haecceities]]
- see · [[Expansion and compression]]
- see · [[Moby Dick’s Moby Dickness]]
- see · [[Following the rabbit’s trace]]
- see · [[Common destinations]]
- see · [[Composition as struggle]]
- see · [[Organism Writing]]
- see · [[Anna Gibbs’s fictocriticism]]
- see · [[Numbers by Paint]]
- see · [[Gignobasis]]
