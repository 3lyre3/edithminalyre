---
type: "concept"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 11.4
stations: [1, 3, 5, 6, 7, 17, 18]
locus: "T0320 · Quivering Haecceities"
count: 11
pattern: "trans imaginary"
kin:
  - "epistemology"
  - "the trans imaginary"
readers: [GB03]
---

An epistemological stance: a condition of subalternity plus a unique, self-tolerant relationship of endearment to the oppressing hegemony — the departure-point of left hand realism.

> a relationship such that one works toward endearing oneself to an oppressing hegemony

- key · [[Sister Aloysius must go to the movies]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Magic is nature from the future]]
- see · [[Gignobasis]]
- see · [[Fromness is not home]]
- see · [[Trans versus queer imaginary]]
- see · [[Territory that cannot be mapped]]
- see · [[Smooth and striated spaces]]
- see · [[Wanna be a cowboy]]
- see · [[The many-in-one]]
- see · [[Common haecceities]]
- see · [[Epistemology from the trans body]]
- see · [[The sic sic organism]]
