---
type: "concept"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 67.14
stations: [1, 9, 14]
locus: "T1072 · Stamina"
count: 6
pattern: "dark materials|beauty[’']s"
kin:
  - "youth"
  - "art making"
readers: [GB12]
---

Young artists’ instincts — good art digested before an eye for it, beauty’s dark materials at their fingertips without fear for their delicacy; failed bluffs attaining pathos.

> beauty’s dark materials at their fingertips without fear for the materials’ delicacy

- key · [[All was brightness and knowing]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[See the error, move regardless]]
- see · [[Pin]]
