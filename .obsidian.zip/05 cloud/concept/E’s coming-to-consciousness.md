---
type: "concept"
voice: "Lyre"
source: thesis
section: "C1DA"
position: 5.68
stations: [2]
locus: "T0204 · C1DA"
count: 2
pattern: "coming-to-consciousness|lifeform called e"
kin:
  - "e s archive"
  - "catalogue"
readers: [GB01]
---

The thesis as the becoming of a lifeform called E, recorded and catalogued by Pasiphaë — and as the record of Pasiphaë’s shortcomings in that research.

> as the coming-to-consciousness of a lifeform called E, a becoming recorded and catalogued by Queen Pasiphaë of Minoa

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[All was brightness and knowing]]
- see · [[E]]
- see · [[Future E’s notes]]
