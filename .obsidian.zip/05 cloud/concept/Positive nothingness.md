---
type: "concept"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 16.03
stations: [2, 4]
locus: "T0372 · Correction 25"
count: 16
pattern: "nothingness"
kin:
  - "nothingness"
  - "the real"
  - "unspeakability"
readers: [GB04]
---

The nots that are not not but never were; a centre that is not even ‘not a centre’, with not a thing to speak of — the city’s core.

> At its core, there was a positive nothingness.

- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[The man at the nothingness]]
- see · [[The pit]]
- see · [[Arrival from Nothing]]
- see · [[Atom and void]]
- see · [[Blackholes and emptiness]]
- see · [[Merciless calms]]
- see · [[Higher attunement contracted]]
- see · [[Reality (Key Terms)]]
