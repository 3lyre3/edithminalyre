---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.06
stations: [1, 2, 3, 6]
locus: "T0254 · Faerieland"
count: 5
pattern: "realness"
kin:
  - "realness"
  - "red"
readers: [GB02]
---

Red’s dictum: offenders are masters of realness; their recall side- and back-lit, shot day-for-night; ‘when’s the last time your misery looked the way it should?’

> “Offenders,” Red writes, “are masters of realness.”

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[Margarita glass simile]]
- see · [[Reality versus the Real]]
- see · [[Abusers as movie-effects artists]]
- see · [[Defame-to-suicide murder-instinct]]
