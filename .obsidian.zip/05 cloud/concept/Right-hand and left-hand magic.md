---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Creature’s Tongue"
position: 41.57
stations: [8, 17]
locus: "T0762 · the Creature’s Tongue"
count: 9
pattern: "right hand|left hand path|left handed|right handed"
kin:
  - "genre"
  - "left hand"
readers: [GB08]
---

Magic acquired from cultural and folkloric sources — right handed — versus magic drawn innately from being-itself, left handed; almost all works blend, that erratic variation itself a tendency.

> These magics come in from the left hand path.

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Magic is nature from the future]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Magic that is real]]
- see · [[Ondjaki’s Transparent City]]
- see · [[Mo Yan’s reincarnations]]
- see · [[Ellison’s Invisible Man]]
- see · [[Right-hand turn, left-hand path]]
- see · [[Hegel on magic]]
- see · [[Extrusion from the Real]]
- see · [[Epistemology from the trans body]]
