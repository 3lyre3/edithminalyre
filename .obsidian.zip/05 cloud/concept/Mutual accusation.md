---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.51
stations: [2, 3, 9, 13, 18]
locus: "T0234 · Faerieland"
count: 14
pattern: "accusee|accuser|accusation"
kin:
  - "accusation"
readers: [GB02]
---

Night as Red’s accusee/er and Red as Night’s — across whose battlements Britt fucks and befriends the pariah and figurehead of either faction.

> across the battlements of this mutual accusation and public discourse, the pariah and figurehead of either faction

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
- see · [[The plausible victim]]
