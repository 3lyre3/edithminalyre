---
type: "concept"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 77.97
stations: [12, 16]
locus: "T1217 · No, no Tiger"
count: 7
pattern: "seeking presence|vandalisation|custodians|alien world"
kin:
  - "dissociation"
  - "ontology"
readers: [GB14]
---

Narratives beginning from dissociation, engaging ontology to scaffold an implement for reality’s vandalisation; its custodians appearing as the law enforcement of an alien world.

> narratives of ‘seeking presence.’

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[In stillness, all is clean]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[I Saw the TV Glow]]
- see · [[Dismemberment cis people can’t see]]
