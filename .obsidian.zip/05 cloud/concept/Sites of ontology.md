---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 49.66
stations: [9, 11]
locus: "T0863 · the Dark Materials"
count: 6
pattern: "sites? of ontology|would-be realit"
kin:
  - "ontology"
  - "alterity"
readers: [GB09]
---

Would-be realities outside reality’s bastion, expressing themselves as fancies, fabulations and speculations; Stamina and the House recount sites more hostile than the dominant reality’s.

> Call these would-be realities “sites of ontology.”

- key · [[To live for the future is to live in glimmered moments]]
- key · [[Magic is nature from the future]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Uncountably many cosmoses]]
- see · [[Gesture beyond reality]]
- see · [[The secret inland ocean]]
- see · [[Seeking presence]]
- see · [[Armeria]]
- see · [[Anxiety is consciousness]]
