---
type: "concept"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [2, 3, 4]
locus: "P0079 · Dear Amaldéu (presentation, pp. 8–48)"
count: 13
pattern: "attunement|side-sensitiv|clade-that-is-not-one"
kin:
  - "uplings"
  - "sensitivity"
readers: [GB18]
---

Britt’s Uplings, the clade-that-is-not-one, lacking the Sí’s other-attunements and side-sensitivities — falling short at the moot, carving worse new animals; tooled forth in agony by the millions.

> atrocity’s pretty avoidable so long as one’s side-sensitivities, as Britt says, calibrate high and block the problem

- key · [[Survival is no excuse for atrocity]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Uplings]]
- see · [[The moot and the Carving]]
- see · [[Higher attunement contracted]]
- see · [[The Uplings are trapped]]
