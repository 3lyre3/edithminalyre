---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.36
stations: [2, 3, 6]
locus: "T0233 · Faerieland"
count: 31
pattern: "tann s[íi]|beag s[íi]|aos s[íi]|\\bclade"
kin:
  - "clades"
readers: [GB02]
---

Tann sí, Beag sí, Aos sí — Wave, Small and Mound people — light-treading and other-attuned; at the election every Faerielander is paired within their own clade.

> so Tann sí with Tann sí, Beag sí with Beag sí, Aos sí with Aos sí, aufGaolaí with aufGaolaí

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[The election of creatures]]
- see · [[Kelly v. Fiade]]
- see · [[Riots felt in the ley-web]]
