---
type: "concept"
voice: "Lyre"
source: thesis
section: "The Still Truth or I Don't See You at All"
position: 39.3
stations: [8, 16]
locus: "T0728 · The Still Truth or I Don't See You at All"
count: 11
pattern: "clownworld|\\bclown"
kin:
  - "clownworld"
  - "incomprehensibility"
readers: [GB08, GB14]
---

The clownworld brainrot contagion — the reality in which ‘Genghis Khan’s womanhood’ can be read; Muchi its carrier, cut off from her own embodiment; the clowncierge and the ClownBD.

> What kind of clownworld brainrot contagion has led you, home viewer, to this reality

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Categories that do not touch]]
- see · [[The still truth]]
- see · [[The clowncierge]]
- see · [[I Saw the TV Glow]]
