---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Creature’s Tongue"
position: 41.57
stations: [8, 9]
locus: "T0762 · the Creature’s Tongue"
count: 7
pattern: "oneiropomp"
kin:
  - "genre"
  - "dreams"
readers: [GB08]
---

The author who leads creatures out of the dream; the left hand realist reverses the oneiropompous motion, summoning creatures — herself among them — into the waking world.

> The oneiropomp of the left hand cosmos is not one’s guide to vaster worlds, but a tongue-tied mutterer trying to speak itself into the waking world

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Magic is nature from the future]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Magic that is real]]
- see · [[Ellison’s Invisible Man]]
- see · [[Extrusion from the Real]]
- see · [[The fascist House]]
- see · [[Right-hand and left-hand magic]]
