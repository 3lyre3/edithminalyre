---
type: "concept"
voice: "Pasiphaë"
source: thesis
section: "Further…"
position: 86.13
stations: [17, 18]
locus: "T1404 · Further…"
count: 5
pattern: "striated|smooth space|suprapsychogeographic|de-striating"
kin:
  - "deleuze"
  - "terrain"
readers: [GB15]
---

The terrains of trans being — tactical blindsides, striated spaces navigable as near-smooth by enmitous or uncountable forces; the suprapsychogeographic tunnels of transness.

> the terrains of trans being are neglected as both tactical blindsides and striated spaces

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[In stillness, all is clean]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[Walking through walls]]
- see · [[Wanna be a cowboy]]
- see · [[The Earth hath bubbles]]
- see · [[Immer schon]]
- see · [[Rainforest under the Sink]]
