---
type: "concept"
voice: "Lyre"
source: thesis
section: "1.236"
position: 33.7
stations: [6, 7, 9]
locus: "T0656 · 1.236"
count: 13
pattern: "compress|expansi|burst-point"
kin:
  - "method"
readers: [GB07]
---

Expand short works to burst-point, compress novels to the brink of oblivion — the same line inversed; Heartscape, Gardner, Angus expanded; Anders, Felker-Martin, Kao, Solomon compressed.

> I reserve the expansive approach for works of short fiction and poems, while compressing the artefacts of any novels, novellas, or theses.

- key · [[It’s a problem that I matter]]
- key · [[All was brightness and knowing]]
- see · [[Rivers Solomon]]
- see · [[Callie Gardner]]
- see · [[Callum Angus]]
- see · [[Following the rabbit’s trace]]
