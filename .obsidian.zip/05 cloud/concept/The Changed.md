---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.0
stations: [2, 6]
locus: "T0224 · Faerieland"
count: 5
pattern: "the [’']?changed|changeling|[‘’']changing"
kin:
  - "citizenship"
  - "abduction"
  - "changelings"
readers: [GB02]
---

‘Changing’: the stealing and substitution of upland children, outlawed by the Faerieland Appellate Court in 2667 I.T.; the aufGaolaí are its otherbound descendants.

> the otherbound descendants of these ‘Changed,’ the aufGaolaí

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[The aufGaolaí oath]]
- see · [[aufGaolaí (Uplings)]]
- see · [[Jus soli and sanguinis]]
- see · [[Active ethnography]]
