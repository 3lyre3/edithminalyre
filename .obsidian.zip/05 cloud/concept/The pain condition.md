---
type: "concept"
voice: "mixed"
source: thesis
section: "Correction 25"
position: 17.9
stations: [4]
locus: "T0387 · Correction 25"
count: 6
pattern: "pain condition|vibrational disease"
kin:
  - "atrocity"
  - "contagion"
  - "disease"
  - "suffering"
  - "survival"
readers: [GB04, GB18]
---

Correction 25’s resonances carry ‘the pain condition’ — whoever knows of it risks contracting and spreading it; a weapon a desperate people might unleash; survival and atrocity as one.

> no member of our institute has made contact with a living carrier of the pain condition

- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[The atrocity of 2.33.9]]
- see · [[Toying at one’s focus]]
- see · [[Quarantine and forgetting]]
- see · [[Vibrational output]]
- see · [[Clownworld]]
- see · [[Life matters]]
- see · [[Write atrocity in the report]]
- see · [[Agency separating from consciousness]]
- see · [[Suffering doesn’t keep]]
