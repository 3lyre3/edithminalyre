---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 50.33
stations: [9]
locus: "T0869 · the Dark Materials"
count: 2
pattern: "trans masc hermeneutic|dark magics"
kin:
  - "cis hermeneutics"
  - "transmisogyny"
readers: [GB09]
---

The dark magics of a trans masc hermeneutic scaffolded into cis hermeneutics — evil triumphing by magic in Stamina; in Rumfitt the repressed trans man breaks through instead.

> by the dark magics of a trans masc hermeneutic scaffolded into and given to the reinforcement to cis hermeneutics

- key · [[To live for the future is to live in glimmered moments]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Heroic stupidity]]
