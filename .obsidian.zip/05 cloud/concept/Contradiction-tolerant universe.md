---
type: "concept"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 79.32
stations: [1, 17]
locus: "T1221 · No, no Tiger"
count: 6
pattern: "contradiction-tolerant|fourth.dimensional|third result"
kin:
  - "contradiction"
  - "dimensions"
readers: [GB14]
---

Engagement’s ending — two contradictory, simultaneously necessary outcomes; not ambiguity but a contradiction-tolerant universe; flip an object twice, get a third result: fourth-dimensional space.

> If, after flipping or turning an object twice, you get a third result, then the object exists in fourth dimensional space.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[The ring in the box]]
