---
type: "concept"
voice: "Lyre"
source: thesis
section: "More Terms"
position: 25.95
stations: [6, 9]
locus: "T0520 · More Terms"
count: 10
pattern: "cis hermeneutic|cis-?normative"
kin:
  - "cis hermeneutics"
  - "cisness"
  - "ontology"
readers: [GB05]
---

Cisnormative (mis)interpretations of the Real that inform cisnormative (mis)constructions of Reality — the path by which cis-realism’s Reality is built; capitalist and white hermeneutics likewise.

> Cis hermeneutics, thus, is a path by which the Reality of cis-realism is constructed.

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Trans masc hermeneutic]]
- see · [[Gibbs got lucky]]
- see · [[Sísia, cisness]]
- see · [[Cisness as possessing geist]]
- see · [[Dismemberment cis people can’t see]]
- see · [[Regional ontology]]
