---
type: "concept"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 80.62
stations: [17]
locus: "T1254 · No, no Tiger"
count: 3
pattern: "evasib|tiger-object"
kin:
  - "tigers"
  - "transition"
readers: [GB14]
---

The tiger-object of Darryl and Nevada; Detransition, Baby draws each protagonist to confront the tiger’s nonexistence — whether that difficulty is overcome, the ambiguity.

> The tiger-object of Darryl and Nevada is the evasibility of transition.

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Minotaur’s birth postponed]]
