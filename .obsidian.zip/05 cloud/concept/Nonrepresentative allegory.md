---
type: "concept"
voice: "Lyre"
source: thesis
section: "Something of Use"
position: 81.69
stations: [1, 17, 20]
locus: "T1290 · Something of Use"
count: 6
pattern: "nonrepresentative|necropoli|resource-report"
kin:
  - "allegory"
  - "method"
readers: [GB14]
---

Winter reports necropolitics’ mechanics without feeding its machine — nonrepresentative allegory; overground bunkers, anarchist communes with unspoken systems; a resource-report on death.

> a difficult balance nonetheless struck by means of nonrepresentative allegory

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Right-hand turn, left-hand path]]
- see · [[Horror and genius are one]]
- see · [[Territory that cannot be mapped]]
- see · [[And Reconciliation, explained]]
