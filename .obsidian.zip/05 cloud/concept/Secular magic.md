---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 20.36
stations: [5, 8]
locus: "T0428 · Key Terms"
count: 11
pattern: "secular magic|\\bsecular\\b"
kin:
  - "genre"
  - "magic as nature"
readers: [GB04]
---

The earlier name for left hand realism — not reverential, ecstatic, esoteric or schizophrenic; ‘secular magical realism’ renamed because its framing looked in from without.

> when the term for it was “secular magic” instead of “left hand realism”

- key · [[Magic is nature from the future]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Magic and technology undelineated]]
- see · [[Coding fantasy into realism]]
