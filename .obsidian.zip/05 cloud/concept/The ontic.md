---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 19.57
stations: [3, 4, 5, 6, 12]
locus: "T0413 · Key Terms"
count: 14
pattern: "\\bontic\\b"
kin:
  - "ontology"
  - "the real"
readers: [GB04]
---

The pre-relational Real: occurrences, processes, beingnesses a priori intelligibility — things before they are called things — reclassified as Reality once summoned into relation; the source of the trouble.

> the ontic is exactly the source of the trouble

- key · [[Survival is no excuse for atrocity]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Magic is nature from the future]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[Hermeneutics]]
- see · [[Schiz beyond the epistemological]]
- see · [[Proximity to ontology]]
- see · [[Anxiety is consciousness]]
- see · [[The retrievable real]]
