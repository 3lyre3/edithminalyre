---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 2.94
stations: [1]
locus: "T0118 · Coda"
kin:
  - "nonlinearity"
  - "thesis structure"
readers: [GB01]
---

Frame narratives collapsing yet un-collapsed, each’s gravitation essential to every other’s structural integrity — the form the Pasiphaë retelling takes.

> a whirl of collapsing (albeit un-collapsed) frame narratives

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Optimism need not be teleological]]
- see · [[Pasiphaë and the White Bull]]
- see · [[Nonlinearity not native]]
- see · [[Contested universes layer]]
- see · [[Semantic striations]]
- see · [[Instructions for reading]]
