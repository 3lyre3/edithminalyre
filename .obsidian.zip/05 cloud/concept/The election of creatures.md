---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 9.13
stations: [2, 8]
locus: "T0270 · Faerieland"
count: 5
pattern: "election of creatures|ensoul|eight million|meatshrub"
kin:
  - "the moot"
  - "carving creatures"
readers: [GB02]
---

Every Faerielander paired within clade, carving lifeforms from meatshrubs and featherfens; pairs breed their creations; of eight million failures sixteen survive to be ensouled and released.

> until at last (out of eight million failed creatures) sixteen survive to be ensouled

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
- key · [[Magic is nature from the future]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Carved creatures]]
- see · [[Red tooth and claw filtration]]
- see · [[Aufgaolaí underperform]]
- see · [[The jackaloid]]
- see · [[The eelwolf]]
- see · [[Bird and bug]]
