---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Creature’s Tongue"
position: 41.57
stations: [8]
locus: "T0762 · the Creature’s Tongue"
count: 6
pattern: "magic that is|biological ontology|othered magic"
kin:
  - "magical realism"
  - "genre"
readers: [GB08]
---

Magical realism’s second element — magic not strange to the author’s world-schema — which left hand realism elaborates: magic preceding and greater than Reality, originating in the author’s biological ontology.

> the origin of the text’s magic is the author’s biological ontology. It is not acquired and neither can it be turned down.

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Magic is nature from the future]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Magic as a barrier first]]
- see · [[The oneiropomp]]
- see · [[Right-hand and left-hand magic]]
- see · [[Mo Yan’s reincarnations]]
