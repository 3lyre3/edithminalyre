---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 20.36
stations: [4, 5, 6, 9, 10, 16, 17]
locus: "T0428 · Key Terms"
count: 12
pattern: "schiz"
kin:
  - "ontology"
  - "perception"
readers: [GB04]
---

‘Schiz’ as a popular term for what lies beyond the epistemological — the unknowable but detectable, traceable, receivable ontic.

> “schiz” is now a popular term for what lies beyond the epistemological

- key · [[Magic is nature from the future]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Deleuzean flightlines]]
- see · [[Schiz tooled toward paranoia]]
- see · [[Proximity to ontology]]
- see · [[Riots felt in the ley-web]]
- see · [[Pick which opening paragraph]]
- see · [[The tree in earshot]]
