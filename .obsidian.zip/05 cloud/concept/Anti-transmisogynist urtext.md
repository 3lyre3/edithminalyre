---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.58
stations: [2]
locus: "T0235 · Faerieland"
kin:
  - "transmisogyny"
  - "genre"
readers: [GB02]
---

The genre Red’s Quivering Haecceities founds — literature against the transmisogyny particular to aufGaolaí women.

> now the urtext of what we’ll call anti-transmisoaufgynlaích literature

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Quivering Haecceities]]
- see · [[Gignobasis]]
- see · [[TME and TMA]]
