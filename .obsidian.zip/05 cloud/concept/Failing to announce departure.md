---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 22.02
stations: [5]
locus: "T0438 · Key Terms"
count: 2
pattern: "announce (?:said )?departure|failing to announce|one to another falsity"
kin:
  - "departure"
  - "genre"
readers: [GB04, GB06]
---

A trope of left hand realism: the departure from reality goes unannounced, since the author is but shuffling from one falsity to another; the motion merely secular, or normative anyway.

> the (often misread) authorial motion of failing to announce said departure

- key · [[Magic is nature from the future]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Proximity to ontology]]
- see · [[Anders’s City in the Middle]]
- see · [[Getting too real]]
- see · [[Reality as unusable reference]]
