---
type: "concept"
voice: "mixed"
source: thesis
section: "Correction 25"
position: 15.15
stations: [3, 4]
locus: "T0367 · Correction 25"
count: 15
pattern: "topograph\\w* institute|the institute\\b|\\bt\\.i\\b"
kin:
  - "atrocity"
  - "cataloguing"
  - "institutions"
  - "topographical institute"
readers: [GB04, GB18]
---

The T.I. — motto ‘Dúe Uyrturmýa Rebend æœá Ffócoi-ffócoi gæn’: ‘Survival is no excuse for atrocity’; hires on minimal attunement; catalogues maplevels; E thinks of applying, after every book.

> Survival is no excuse for atrocity: one of our institute’s oldest principles, one we must treasure.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Survival is no excuse for atrocity]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Discrepant Topography]]
- see · [[The pain condition]]
- see · [[Write atrocity in the report]]
- see · [[Dear Amaldéu (presentation)]]
- see · [[Maplevel marked Atrocity]]
- see · [[Nuke it]]
