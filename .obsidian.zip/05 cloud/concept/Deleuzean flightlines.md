---
type: "concept"
voice: "Lyre"
source: thesis
section: "1.9"
position: 29.91
stations: [1, 6, 9]
locus: "T0579 · 1.9"
count: 4
pattern: "flightline|deleuz"
kin:
  - "deleuze"
  - "ontology"
readers: [GB06]
---

Eruptions of imagination as unravellings along Schiz flightlines, in the Deleuzean sense — the old postmodern observation applied to ontic proximity.

> eruptions of imagination, unravellings along Schiz flightlines (in the Deleuzean sense)

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Magic is nature from the future]]
- see · [[Rhizomatic disorder of nature]]
- see · [[Schiz tooled toward paranoia]]
- see · [[Smooth and striated spaces]]
- see · [[Circuitries (Land)]]
- see · [[Reality scripted by its epoch]]
