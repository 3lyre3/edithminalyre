---
type: "concept"
voice: "Lyre"
source: thesis
section: "I’ve met him, Paxie."
position: 66.38
stations: [2, 3, 5, 13, 14, 16, 18, 20]
locus: "T1064 · I’ve met him, Paxie."
count: 13
pattern: "enthusiastic pessimism|nothing else|cyclical failure"
kin:
  - "pessimism"
  - "failure"
readers: [GB12]
---

Queer theory’s task: sustain an aesthetic of enthusiastic pessimism and content itself with achieving nothing else — queer method delivered repeatedly to its limit.

> the task for queer theory is to sustain an aesthetic and practice of enthusiastic pessimism

- key · [[Optimism need not be teleological]]
- key · [[Once there were no masters. And yet the house was built]]
- see · [[Action without impact]]
