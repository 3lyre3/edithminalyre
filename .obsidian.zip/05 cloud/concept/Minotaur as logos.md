---
type: "concept"
voice: "E"
source: thesis
section: "Minoa Below"
position: 24.72
stations: [5, 12]
locus: "T0497 · Minoa Below"
count: 4
pattern: "\\blogos\\b|matriarchal|forced exception"
kin:
  - "asterion"
  - "the feminine"
readers: [GB05]
---

First think the minotaur as matriarchal-primordial; second rethink it as logos, forced exception — what gets buried alongside the bathwaters of bestiality and cannibalism?

> First, think the minotaur as matriarchal-primordial. Second, rethink the minotaur as logos.

- key · [[Magic is nature from the future]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[Ten-thousand circles of repression]]
- see · [[Arrival from Nothing]]
- see · [[Christa Wolf]]
- see · [[Nymph of iron]]
- see · [[The Mothers’ destiny]]
