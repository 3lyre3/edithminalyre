---
type: "concept"
voice: "Lyre"
source: thesis
section: "Organism Writing"
position: 60.95
stations: [3, 12]
locus: "T1017 · Organism Writing"
count: 7
pattern: "transsexual theory|antinormativ|attached to a norm"
kin:
  - "trans theory"
  - "normativity"
readers: [GB11]
---

What comes after trans studies — ‘can I suggest transsexual theory?’ — impossible with antinormativity; transness as attachment to a norm by desire, habit, survival.

> whatever comes after trans studies—can I suggest transsexual theory?—will be impossible with antinormativity

- key · [[Once there were no masters. And yet the house was built]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Queerness oppresses trans people]]
- see · [[Transgender should not exist]]
- see · [[Compulsory transsexuality]]
- see · [[Why we built the normative]]
- see · [[Feminism to queer to transsexuality]]
