---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 19.42
stations: [2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 16, 17]
locus: "T0407 · Key Terms"
count: 34
pattern: "\\bontolog"
kin:
  - "ontology"
readers: [GB04]
---

‘All that is, as opposed to all that is not’; fundamental ontology as the gestalt of the Ontic and Reality — the thesis’s working definition, margins contested.

> if one takes it to mean “all that is, as opposed to all that is not,” one will almost always appreciate the intent

- key · [[Survival is no excuse for atrocity]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Magic is nature from the future]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[Reality (Key Terms)]]
- see · [[Heidegger]]
- see · [[The ontic]]
- see · [[The Real (More Terms)]]
