---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 50.64
stations: [8, 9, 10, 14]
locus: "T0870 · the Dark Materials"
count: 8
pattern: "paranoi|oedipal bastion"
kin:
  - "deleuze"
  - "repression"
readers: [GB09]
---

In Stamina, Schiz — the Deleuzean jargon — is tooled toward the return of the protagonist’s purchase on paranoia, the Oedipal bastion; in Rumfitt, suspension to schizophrenic-paranoiac limbo.

> Schiz (I want to use some Deleuzean jargon) is tooled toward the return and solidification of the protagonist’s purchase on paranoia (i.e. the Oedipal bastion)

- key · [[To live for the future is to live in glimmered moments]]
- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Survival is no excuse for atrocity]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Feinting the crowd]]
- see · [[President Oedipus (Lyre)]]
- see · [[Sam (Stamina)]]
- see · [[Smooth and striated spaces]]
