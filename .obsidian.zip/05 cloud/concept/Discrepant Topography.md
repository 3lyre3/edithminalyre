---
type: "concept"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 15.15
stations: [3, 4]
locus: "T0367 · Correction 25"
count: 6
pattern: "discrepan"
kin:
  - "topographical institute"
  - "mapping"
readers: [GB04]
---

The discipline of disproving or resolving discrepancies between adjacent maplevels; a region can appear more discrepancy than reality; unaccountable hours are forever its rub.

> that is, after all, forever the rub in Discrepant Topography

- key · [[Sister Aloysius must go to the movies]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Survival is no excuse for atrocity]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Maplevels]]
- see · [[The Topographical Institute]]
- see · [[Write atrocity in the report]]
