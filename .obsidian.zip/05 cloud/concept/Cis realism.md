---
type: "concept"
voice: "Lyre"
source: thesis
section: "Cisness"
position: 1.23
stations: [1]
locus: "T0097 · Cisness"
count: 8
pattern: "cis realis|realism is cisness|cisness is realism"
kin:
  - "cisness"
  - "realism"
readers: [GB01]
---

‘Cisness is realism. Realism is cisness’: realism as cissexually constructed; what does not feel speculative is realist, what does not feel trans is cis.

> Here, ‘cis realism’ is redundant: cisness is realism. Realism is cisness.

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Contradiction-tolerant lexicon]]
- see · [[How does cisness feel]]
- see · [[Trans women anchoring realism]]
- see · [[Trans as magical realist presence]]
- see · [[Cis hermeneutics]]
- see · [[Who the speaker is]]
- see · [[Polygon-stack imitation]]
