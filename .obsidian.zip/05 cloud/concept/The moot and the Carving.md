---
type: "concept"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [2, 3, 4]
locus: "P0079 · Dear Amaldéu (presentation, pp. 8–48)"
count: 14
pattern: "\\bmoot\\b|the carving|carve much worse|new animals"
kin:
  - "faerieland"
  - "rites"
readers: [GB18]
---

Every moot new animals carved — Uplings getting it there or fucked into it by whatever monstrosity they’re paired to; entrants ask what can survive alongside the possible.

> Entrants in the Carving – i.e. all citizenry of Faerieland – need ask what can survive alongside what is possible.

- key · [[Survival is no excuse for atrocity]]
- key · [[Sister Aloysius must go to the movies]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Other-attunements and side-sensitivities]]
- see · [[Twin hideousnesses]]
- see · [[Compulsory transsexuality]]
