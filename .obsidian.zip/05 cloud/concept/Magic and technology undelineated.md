---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 21.76
stations: [5, 6]
locus: "T0437 · Key Terms"
count: 5
pattern: "nature from the future|exist as magic|magic and technology"
kin:
  - "magic as nature"
readers: [GB04]
---

In the trans imaginary no important line divides magic from technology, or technology from nature: magic is nothing other than nature from the future — ‘I exist as magic.’

> here magic is nothing other than nature from the future

- key · [[Magic is nature from the future]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[I am not my body]]
- see · [[The Xenofeminist Manifesto]]
