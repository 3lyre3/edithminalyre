---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 21.08
stations: [2, 3, 5, 7]
locus: "T0433 · Key Terms"
count: 15
pattern: "haecceit"
kin:
  - "method"
  - "the trans imaginary"
readers: [GB04]
---

False Cows isolates common haecceities within the trans imaginary and composes texts that respond to their recurrence across subgenres and story structures — creative composition as method.

> an isolation of common haecceities within the trans imaginary and the composure of a suite of creative texts

- key · [[Magic is nature from the future]]
- key · [[All was brightness and knowing]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[It’s a problem that I matter]]
- see · [[Technophilia cliché]]
- see · [[Moby Dick’s Moby Dickness]]
- see · [[Common destinations]]
- see · [[Expansion and compression]]
- see · [[Wanna be a cowboy]]
