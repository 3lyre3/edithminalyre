---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.0
stations: [2, 3, 6]
locus: "T0224 · Faerieland"
count: 29
pattern: "aufgaola|upling"
kin:
  - "clades"
  - "the moot"
  - "citizenship"
readers: [GB02]
---

Faerieland’s human-descended clade-that-is-not-one, lacking the Sí’s other-attunements; three of this moot’s sixteen creatures were theirs — a record, and a backlash.

> Lacking the other-attunements and side-sensitivities of the Sí, naturally the aufGaolaí – naturally we – underperform.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Survival is no excuse for atrocity]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[The Changed]]
- see · [[The Sgiesaetthum]]
- see · [[The Sí clades]]
- see · [[Aufgaolaí underperform]]
- see · [[The aufGaolaí oath]]
- see · [[Blatance, Faer Radiance]]
- see · [[The moot]]
- see · [[The election of creatures]]
- see · [[Red tooth and claw filtration]]
- see · [[Kelly v. Fiade]]
- see · [[Riots felt in the ley-web]]
- see · [[Jus soli and sanguinis]]
