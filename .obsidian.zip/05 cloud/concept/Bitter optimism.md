---
type: "concept"
voice: "Lyre"
source: thesis
section: "I’ve met him, Paxie."
position: 64.84
stations: [3, 13, 14, 18]
locus: "T1058 · I’ve met him, Paxie."
count: 9
pattern: "bitter optimism|bitterness|bitter – rather"
kin:
  - "optimism"
  - "trans theory"
readers: [GB12]
---

Chu’s standpoint — writing without political optimism, without subsuming optimistic attachment under the sign of the political; moving out of the world and into oneself. ‘There. Bitter optimism.’

> There. Bitter optimism.

- key · [[Optimism need not be teleological]]
- key · [[It’s a problem that I matter]]
- see · [[Cruel optimism (Berlant)]]
- see · [[Meanwhile, Elsewhere]]
- see · [[Born from our oppressors’ bodies]]
- see · [[Enthusiastic pessimism]]
- see · [[Hundreds of years of tugs]]
- see · [[Impurity of heart]]
- see · [[Transing equals queering]]
