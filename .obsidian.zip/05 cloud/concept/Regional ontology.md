---
type: "concept"
voice: "Lyre"
source: thesis
section: "More Terms"
position: 25.95
stations: [2, 6]
locus: "T0523 · More Terms"
count: 3
pattern: "regional ontology|regional"
kin:
  - "ontology"
readers: [GB05]
---

Heidegger’s haunting sense of ‘ontology’ — all that is in this regard — barricaded against, so that the unmodified word keeps its vernacular meaning.

> said usage nonetheless haunts us here due to the invocation of Heidegger and, so, must be barricaded against

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Ontology brighter than reality]]
