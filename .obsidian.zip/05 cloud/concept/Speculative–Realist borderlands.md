---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 2.75
stations: [1, 2]
locus: "T0117 · Coda"
count: 4
pattern: "borderlands?"
kin:
  - "genre"
  - "territory"
readers: [GB01]
---

The creative borderlands between the Speculative and the Realist, where trans authors make their mark; literary styles, like realities, have soft edges.

> It is in this creative borderlands that trans authors make our mark.

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Magic is nature from the future]]
- see · [[Archipelago of exclaves]]
- see · [[Customs-record and onward travel]]
- see · [[Anti-transmisogynist urtext]]
