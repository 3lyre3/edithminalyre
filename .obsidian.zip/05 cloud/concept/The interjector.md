---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Adversary Part Two"
position: 88.68
stations: [18]
locus: "T1426 · the Adversary Part Two"
count: 8
pattern: "interjector"
kin:
  - "therapy"
  - "the devil"
readers: [GB16]
---

The part that says no, not good enough — the devil; for Ari it wore the rapist’s skin, used Lisa’s larynx; the dust, the genetic heritage; later, the good interjector.

> it is that part of oneself that says “no,” or says one is not good enough… it is the devil.

- key · [[In stillness, all is clean]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Triptych (for mental health)]]
- see · [[Dragged smiling to the sky]]
