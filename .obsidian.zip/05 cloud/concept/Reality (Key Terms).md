---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 19.48
stations: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20]
locus: "T0410 · Key Terms"
count: 155
pattern: "\\breality\\b"
kin:
  - "ontology"
  - "the real"
readers: [GB04]
---

The fantastical world in which most nonfiction and all non-speculative fiction is set; per Heidegger, ‘Reality (not the Real) is dependent upon care’ — ontology’s non-ontic aspects.

> The fantastical world in which most nonfiction and all non-speculative fiction (of which realist fiction is an example) is set.

- key · [[Survival is no excuse for atrocity]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Heidegger]]
- see · [[The ontic]]
