---
type: "concept"
voice: "E"
source: pres
section: "Dear Amaldéu (presentation, pp. 8–48)"
stations: [15]
locus: "P0089 · Dear Amaldéu (presentation, pp. 8–48)"
count: 7
pattern: "sacred negativ|ova animal|egg-bearing|divine absence"
kin:
  - "pronouns"
  - "faerish"
readers: [GB18]
---

‘She’ — the sacred negative and ova-animal pronoun Faerieland says is not for intelligent beings, which must wear ‘fae’; humans adorning themselves in divine absence with egg-bearing animalism.

> adorn themselves in the paradox of divine absence alongside egg-bearing animalism

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Compulsory transsexuality]]
- see · [[Not lowercase-real]]
