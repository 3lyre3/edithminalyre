---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.06
stations: [1, 18]
locus: "T0119 · Coda"
count: 2
pattern: "striation"
kin:
  - "language"
  - "nonlinearity"
readers: [GB01]
---

The grammatic and lexical channels along which trans personhood must force its expression — a source of the text’s nonlinearity that is not transness’s own.

> the semantic striations (the grammatic and lexical channels) along which trans personhood must force its expression

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Optimism need not be teleological]]
- see · [[Archipelago of exclaves]]
- see · [[Nonlinearity not native]]
- see · [[Contested universes layer]]
- see · [[As if from a tomb]]
