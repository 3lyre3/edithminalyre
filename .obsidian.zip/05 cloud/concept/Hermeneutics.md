---
type: "concept"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 19.58
stations: [4, 6, 9, 12]
locus: "T0414 · Key Terms"
count: 16
pattern: "hermeneutic"
kin:
  - "ontology"
  - "cis hermeneutics"
readers: [GB04]
---

Relationality as innate actuality awaiting observation, or as byproduct of phenomenological interpretation — the process later called hermeneutics; cis hermeneutics to come.

> the output of a system/process later referred to as “hermeneutics.”

- key · [[Survival is no excuse for atrocity]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Cis hermeneutics]]
- see · [[Schiz beyond the epistemological]]
- see · [[Trans masc hermeneutic]]
