---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.06
stations: [2, 4, 5, 6, 7, 8, 9, 10, 12, 16, 17]
locus: "T0254 · Faerieland"
count: 43
pattern: "\\bthe real\\b"
kin:
  - "the real"
  - "realness"
readers: [GB02]
---

Red says nothing’s harder to sell than reality; Britt corrects to the Real — the series of actions and events with an obvious name — obviousness the exchange-mechanism between them.

> Internally I correct to ‘the Real’ and agree.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Masters of realness]]
- see · [[Obviousness as exchange-mechanism]]
- see · [[Reality (Key Terms)]]
- see · [[The Real (More Terms)]]
- see · [[Tav (Truth-Aletheia-Veritas)]]
- see · [[Gesture beyond reality]]
- see · [[Metaphors can be real]]
- see · [[Not lowercase-real]]
- see · [[Does articulation produce reality]]
- see · [[The too-real]]
