---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.8
stations: [2, 9]
locus: "T0237 · Faerieland"
count: 4
pattern: "sayable|say-can-of"
kin:
  - "sayability"
  - "negative thinking"
readers: [GB02]
---

‘That’s sayable. It’s sayable Night was not lying. But no it’s not sayable Red was lying’ — the negative space in which Britt can think.

> That’s sayable. It’s sayable Night was not lying.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Thinking only in the negative]]
