---
type: "concept"
voice: "Lyre"
source: thesis
section: "The Still Truth or I Don't See You at All"
position: 39.64
stations: [8, 16, 17]
locus: "T0735 · The Still Truth or I Don't See You at All"
count: 9
pattern: "still truth|clutter"
kin:
  - "articulation"
  - "stillness"
readers: [GB08, GB14]
---

The still truth of her self-/trans-embodiment — the missing bit that would make Muchi articulable to herself, obscured by an excess of pre-loaded information about her social being.

> she cannot see the still truth of her self-/trans-embodiment, the one piece that would make her articulable to herself

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[In stillness, all is clean]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Muchi’s forgotten passage]]
- see · [[Nothing left to fix]]
- see · [[Peers who cannot see themselves]]
- see · [[Sell it for half]]
- see · [[Speaking from, not about]]
- see · [[Picture a happy child]]
- see · [[Merciless calms]]
