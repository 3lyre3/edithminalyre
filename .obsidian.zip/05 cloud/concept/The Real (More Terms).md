---
type: "concept"
voice: "Lyre"
source: thesis
section: "More Terms"
position: 25.95
stations: [4, 6, 9]
locus: "T0519 · More Terms"
count: 10
pattern: "fundamental ontology|potentialit|is real but is not reality"
kin:
  - "the real"
  - "ontology"
  - "potential"
readers: [GB05]
---

‘The Real’ and ‘fundamental ontology’ interchangeable: all that ever was, is, will be; potentialities at home in the Real but alien to Reality — the future is Real, not Reality.

> if, at any point, I am seen writing something like “the future is Real but is not Reality,” it will be because I mean it

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Magic is nature from the future]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Regional ontology]]
- see · [[Cis hermeneutics]]
- see · [[Extrusion from the Real]]
