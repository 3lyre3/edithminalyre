---
type: "concept"
voice: "Ama"
source: ama
section: "Letter from Ama"
locus: "A0006 · Letter from Ama"
count: 5
pattern: "\\bton\\b|þin|þis|þon|radiant creativity"
kin:
  - "pronouns"
  - "faerish"
readers: [GB17]
---

Faerish pronouns — for people only ‘fae’; ton for Radiant Creativity and semen animals; þin (she) for Sacred Negativity and ova animals; and tons, tones, þis, þon.

> For people our Faerish gives only the ‘fae’

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[She, the sacred negative]]
- see · [[Sgiesaetthum]]
- see · [[The Faerish question]]
- see · [[Spêcidæn, back-spliced]]
