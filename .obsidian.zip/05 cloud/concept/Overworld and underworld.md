---
type: "concept"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 13.42
stations: [3]
locus: "T0344 · Quivering Haecceities"
count: 6
pattern: "overworld|underworld|otherworld"
kin:
  - "worlds"
  - "bettcher"
readers: [GB03]
---

Bettcher’s rhythmic pair — aware of oneself as violated in the overworld and concealed in the underworld — compared with Faerie’s otherworld and overworld: Faerieland and the Uplands.

> her rhythmic use of “overworld” and “underworld” (compare Faerie folklore’s otherworld and overworld/Faerieland and the Uplands)

- key · [[Sister Aloysius must go to the movies]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[All was brightness and knowing]]
- see · [[Lugones’s ontological pluralism]]
- see · [[The dysphoria dispute]]
- see · [[Maplevels]]
- see · [[Christ on this maplevel]]
- see · [[Elysicester]]
