---
type: "concept"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 79.51
stations: [17, 20]
locus: "T1232 · No, no Tiger"
count: 9
pattern: "satisfying dissatisfaction|rook|nomie|royal jelly|know its name"
kin:
  - "music"
  - "dissatisfaction"
readers: [GB14]
---

The recurring note trans musicians strive for — Rook & Nomie’s Superego Royal Jelly: ‘It’s still inside me now, but I know its name… But you’re here with me.’

> the recurring note of “satisfying dissatisfaction” that many trans musicians strive for

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Optimism need not be teleological]]
- key · [[There can be a tiger. You won’t let there be]]
- key · [[Obsessive recitation of the real cannot change it]]
- see · [[The People’s Joker]]
- see · [[SOPHIE’s Immaterial]]
- see · [[Absence embodied as tiger]]
- see · [[More than you need]]
- see · [[Feel except good]]
