---
type: "concept"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 13.03
stations: [3]
locus: "T0341 · Quivering Haecceities"
count: 5
pattern: "infraintima"
kin:
  - "bettcher"
  - "secrets"
  - "worlds"
readers: [GB03]
---

Bettcher’s coinage: freedom from vulnerability through the other’s failure to understand one’s multiworldly gestures — protection by obliviousness; the author doubts it against her evidence.

> Protection through the obliviousness of the other.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[Talia Mae Bettcher]]
- see · [[Overworld and underworld]]
- see · [[Concealment and exposure paradox]]
- see · [[Lugones’s ontological pluralism]]
- see · [[The dysphoria dispute]]
- see · [[Maplevels]]
- see · [[Christ on this maplevel]]
- see · [[Elysicester]]
