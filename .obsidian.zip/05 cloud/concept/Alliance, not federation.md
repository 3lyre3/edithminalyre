---
type: "concept"
voice: "Lyre"
source: thesis
section: "took the Alexander from Paris and I the Paris from Alexander, what remained of what went of me in the Scamander to buoy again a barbarian enough mannerly for the Priamidi’s fosterage? Who was he?"
position: 63.77
stations: [13]
locus: "T1041 · took the Alexander from Paris and I the Paris from Alexander, what remained of what went of me in the Scamander to buoy again a barbarian enough mannerly for the Priamidi’s fosterage? Who was he?"
count: 5
pattern: "alliance|federation"
kin:
  - "method"
  - "trans theory"
readers: [GB11]
---

The methods may operate in alliance, not mistaken for a federation; Chu’s urgency (‘What should the discussion be right now?’) versus thinking the possible.

> so long as the alliance is not mistaken for a federation

- key · [[Optimism need not be teleological]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Dances atop the limit]]
- see · [[Nice Trannies]]
- see · [[Transing equals queering]]
