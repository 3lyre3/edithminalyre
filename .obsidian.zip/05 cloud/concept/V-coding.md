---
type: "concept"
voice: "E"
source: thesis
section: "“We are all Transsexuals Now”"
position: 82.43
stations: [17]
locus: "T1310 · “We are all Transsexuals Now”"
count: 6
pattern: "v-cod|eyehole|sith empire|grim darkness"
kin:
  - "prisons"
  - "dystopia"
  - "atrocity"
readers: [GB14]
---

Sticking a trans woman in a men’s prison with Eyehole-Raper; why no dystopia imagines a reality as terrible as many trans women’s — in grim darkness, things are better.

> Why in all these gritty dystopias is no one V-coded?

- key · [[To get horror, combine spectacle and illegibility]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Territory that cannot be mapped]]
- see · [[Warhammer 40K lore]]
- see · [[The laser-green highlighter]]
- see · [[Prisons on prisons]]
- see · [[Maplevel marked Atrocity]]
