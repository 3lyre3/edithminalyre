---
type: "concept"
voice: "Lyre"
source: thesis
section: "Intersection"
position: 30.69
stations: [6, 7, 20]
locus: "T0603 · Intersection"
count: 19
pattern: "accend"
kin:
  - "intersection"
  - "kindness and honesty"
readers: [GB06]
---

The kindest people, kindness their truth, unbeset by wars amid evergiving forests; near-all tell fables; their Elds and council-meets; the marriage of kindness and honesty their fundament.

> Kindness was the truth of them, and kindness imperilled them not at all.

- key · [[It’s a problem that I matter]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Eld Faenicth]]
- see · [[Kindness and honesty’s marriage]]
- see · [[Agency separating from consciousness]]
