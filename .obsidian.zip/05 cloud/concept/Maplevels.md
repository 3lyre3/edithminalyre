---
type: "concept"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 15.15
stations: [3, 4, 5]
locus: "T0367 · Correction 25"
count: 14
pattern: "maplevel|gateline"
kin:
  - "topographical institute"
  - "worlds"
readers: [GB04]
---

Dimensional maplevels — 86.16.5, 2.33.9, ‘Uæltain’ — reached by the gateline; worlds as adjacent regions of a map that can be wrong.

> Do you know what a dimensional maplevel is and, if so, can you confirm that you are native to this maplevel?

- key · [[Sister Aloysius must go to the movies]]
- key · [[Magic is nature from the future]]
- key · [[To get horror, combine spectacle and illegibility]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Region 86.16.5]]
- see · [[Discrepant Topography]]
- see · [[Christ on this maplevel]]
- see · [[Elysicester]]
- see · [[The Topographical Institute]]
- see · [[Write atrocity in the report]]
