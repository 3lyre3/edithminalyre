---
type: "concept"
voice: "Lyre"
source: thesis
section: "Riding Jupiter"
position: 97.83
stations: [20]
locus: "T1694 · Riding Jupiter"
count: 5
pattern: "stigmerg|synergy|synch-ups"
kin:
  - "coordination"
  - "crowds"
readers: [GB17]
---

Humans’ foremost coordination — speechless collaboration of minds modelling each other; synergy locking through crowds, friend networks, families, on scales of thousands; all of us out to get someone.

> Humans’ foremost, most common mechanism of coordination is not body language but stigmergy

- key · [[There can be a tiger. You won’t let there be]]
- key · [[It’s a problem that I matter]]
- see · [[Feinting the crowd]]
- see · [[Peter Watts’s vampires]]
- see · [[Maturity to regret the tiger]]
