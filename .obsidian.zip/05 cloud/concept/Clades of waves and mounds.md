---
type: "concept"
voice: "Ama"
source: ama
section: "Letter from Ama"
stations: [2]
locus: "A0005 · Letter from Ama"
count: 10
pattern: "clade|police-general|littlenesses"
kin:
  - "faerieland"
  - "kinship"
readers: [GB17]
---

The fey’s clades — waves, littlenesses, mounds — and the police-generals’ argument that Uplings so born are their children; ‘so are the Uplings Faerielanders.’

> so are the Uplings Faerielanders

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Amaldéu]]
- see · [[Uplings]]
