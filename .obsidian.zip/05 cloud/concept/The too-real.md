---
type: "concept"
voice: "Lyre"
source: thesis
section: "1.9"
position: 28.35
stations: [6, 10]
locus: "T0553 · 1.9"
count: 8
pattern: "too[- ]real|too-realness|motion smoothing"
kin:
  - "the too real"
  - "realness"
readers: [GB06]
---

‘It looked too real. TV with the motion smoothing on’ — the real, when recognised, too real to convince; the unspeakably mundane evades account by that very unspeakability.

> The real, when it is recognised, is too real to convince.

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[V’s murder]]
- see · [[TERFs too boring to write]]
- see · [[Abusers as movie-effects artists]]
- see · [[Getting too real]]
