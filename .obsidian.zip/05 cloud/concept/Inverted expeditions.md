---
type: "concept"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 46.64
stations: [9, 10, 11]
locus: "T0844 · the Dark Materials"
count: 9
pattern: "inverted expedition|lesser reality"
kin:
  - "inverted expeditions"
  - "alterity"
readers: [GB09]
---

Conversations with or journeys to an alterity vaster than the reality enclosing it; three arcs — rescue from a lesser reality, confinement to it, tempted free then shut out midway.

> conversations with or journeys to an alternate reality/alterity that is, in some meaningful sense, vaster than the reality that encloses it

- key · [[To live for the future is to live in glimmered moments]]
- key · [[Optimism need not be teleological]]
- see · [[Stamina]]
- see · [[Haunting, not haunted]]
- see · [[Rescue, confinement, limbo]]
- see · [[We have always been here]]
- see · [[The unknown-script category]]
- see · [[Seeking presence]]
- see · [[Speculating Queerer Worlds (Lothian)]]
- see · [[Wild Geese (Emmanuel)]]
- see · [[Sites of ontology]]
- see · [[Armeria]]
- see · [[Gesture beyond reality]]
