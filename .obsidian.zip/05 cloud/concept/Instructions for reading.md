---
type: "concept"
voice: "Lyre"
source: thesis
section: "C1DA"
position: 5.59
stations: [2]
locus: "T0198 · C1DA"
kin:
  - "reader address"
  - "thesis structure"
readers: [GB01]
---

C1DA’s list a)–m): read in order; as friend or welcome guest; as E’s coming-to-consciousness catalogued by Pasiphaë; as the archive itself; ‘if you disappoint this thesis, it will tell you’.

> l) if you disappoint this thesis, it will tell you · m) now press my eyes.

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- see · [[Passport need not be shown]]
- see · [[E’s coming-to-consciousness]]
- see · [[The reconcilable Real]]
- see · [[E’s stacking order]]
- see · [[Pick which opening paragraph]]
