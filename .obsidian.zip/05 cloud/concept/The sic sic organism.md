---
type: "concept"
voice: "Lyre"
source: thesis
section: "Organism Writing"
position: 60.26
stations: [12, 13]
locus: "T1013 · Organism Writing"
count: 11
pattern: "\\[sic \\[sic\\]\\]|the organism|organism qua"
kin:
  - "bodies"
  - "epistemology"
  - "home"
readers: [GB11]
---

Gibbs’s ‘the [sic [sic]] organism’ — the trans home world; the cis narrational privilege to travel there and return, the trans tragedy to be forever bound.

> The site Anna Gibbs names, “the [sic [sic]] organism,” is indeed the trans home world.

- key · [[Once there were no masters. And yet the house was built]]
- key · [[All was brightness and knowing]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[Optimism need not be teleological]]
- see · [[Anxiety is consciousness]]
- see · [[Queer art as limiting organism]]
- see · [[The Organism riddled with limits]]
- see · [[Hundreds of years of tugs]]
- see · [[Born from our oppressors’ bodies]]
