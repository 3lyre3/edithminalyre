---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 2.29
stations: [1]
locus: "T0113 · Coda"
count: 3
pattern: "secret title|secret name|in blue"
kin:
  - "thesis structure"
  - "secrets"
readers: [GB01]
---

Colour-coded index titles that were ‘fronts’ for secret titles printed in blue: ‘the Creature’s Tongue’ fronting ‘My Body’s Another’, ‘[Series of letters]’ fronting ‘Nature, Yet’.

> indicated whether a title was or was not a ‘front’ for another, secret title

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[The four secret arguments]]
- see · [[Already Yet]]
- see · [[Muscles keep secrets]]
