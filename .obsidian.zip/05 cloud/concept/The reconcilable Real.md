---
type: "concept"
voice: "Lyre"
source: thesis
section: "C1DA"
position: 5.74
stations: [2, 11]
locus: "T0209 · C1DA"
count: 4
pattern: "reconcilable real|ontological real|common heritage"
kin:
  - "the real"
  - "belonging"
readers: [GB01]
---

Evidences of an ontological Real into which stranded trans realities may be reconciled — ours, unique to us, a common heritage for those who seek belonging.

> Evidences of a reconcilable Real (i.e. an ontological Real into which our stranded realities may be reconciled)

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[Once there were no masters. And yet the house was built]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Obviousness as exchange-mechanism]]
- see · [[Shared touchstones]]
