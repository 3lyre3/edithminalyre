---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 2.29
stations: [1, 2]
locus: "T0113 · Coda"
count: 2
pattern: "secret argument|four (?:critical )?arguments|arguments?, in secret"
kin:
  - "thesis structure"
readers: [GB01]
---

False Cows’s four critical arcs called arguments, secret and in order: Left Hand Realism, Nature Yet, My Body’s Another, Mattering — the fourth cast as litter among the rest.

> So, the four arguments, in secret and in order, are “Left Hand Realism”, “Nature, Yet,” “My Body’s Another,” and “Mattering.”

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[Front titles, secret titles]]
- see · [[Exegesis as vivisection]]
- see · [[Mattering (fourth argument)]]
- see · [[Stories out of order]]
- see · [[Voice of trans community]]
