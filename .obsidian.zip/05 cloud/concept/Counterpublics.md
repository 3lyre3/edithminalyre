---
type: "concept"
voice: "Lyre"
source: thesis
section: "1.9"
position: 29.51
stations: [6, 20]
locus: "T0577 · 1.9"
count: 5
pattern: "counterpublic|zone of alterity"
kin:
  - "queer temporality"
  - "community"
readers: [GB06]
---

Zones of queer spacetime — motes of captured time bubbling from collisions of marginal stressors — reappropriated for the noise-set forcefield that summoned every trans person to the floor.

> summoned a zone of alterity, a counterpublic at the front of the dancefloor

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[To live for the future is to live in glimmered moments]]
- key · [[It’s a problem that I matter]]
- key · [[There can be a tiger. You won’t let there be]]
- see · [[Queer Time and Place]]
- see · [[The Fitzroy gig]]
- see · [[The many-in-one]]
- see · [[The community’s instrument]]
- see · [[Cow dead in the mail]]
- see · [[Stigmergy]]
- see · [[Speculating Queerer Worlds (Lothian)]]
