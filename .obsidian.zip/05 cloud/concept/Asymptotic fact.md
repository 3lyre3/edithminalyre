---
type: "concept"
voice: "Lyre"
source: thesis
section: "Stamina"
position: 70.57
stations: [15]
locus: "T1084 · Stamina"
count: 2
pattern: "asymptot"
kin:
  - "truth"
  - "alternate worlds"
readers: [GB12]
---

True for all but one scenario — ‘An asymptotic fact, ma’am!’ ‘And what’s another kind of fact?’ ‘Ma’am, there is none!’; asymptotes nothing but math and language.

> “An asymptotic fact, ma’am!”

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[Online doesn’t mean awake]]
- see · [[Alive in Melbourne]]
