---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.68
stations: [2, 3]
locus: "T0261 · Faerieland"
count: 9
pattern: "\\bmoot"
kin:
  - "the moot"
  - "ritual"
readers: [GB02]
---

The moot called by Blatance’s knell: four months at the Shimmerlands, paired for the Sun Rite, carving creatures to be bred and elected; nothing else matters.

> Red shrugged. “It’s the moot.”

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[The Shimmerlands]]
- see · [[Carved creatures]]
- see · [[The election of creatures]]
- see · [[Red tooth and claw filtration]]
- see · [[Aufgaolaí underperform]]
