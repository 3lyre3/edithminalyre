---
type: "concept"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.06
stations: [2]
locus: "T0254 · Faerieland"
count: 3
pattern: "obviousness|obvious name"
kin:
  - "the real"
  - "naming"
readers: [GB02]
---

‘Obviousness’ bonds reality and the Real — the mechanism by which events acquire their obvious name, and the name Britt withholds.

> (‘obviousness’ being the exchange-mechanism bonding reality and the Real)

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[Reality versus the Real]]
- see · [[E was Paris]]
