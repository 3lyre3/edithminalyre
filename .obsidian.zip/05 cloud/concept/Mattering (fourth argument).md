---
type: "concept"
voice: "Lyre"
source: thesis
section: "Coda"
position: 2.51
stations: [1]
locus: "T0115 · Coda"
count: 4
pattern: "meaning-formation|community-formation|\\bmattering\\b"
kin:
  - "community"
  - "meaning"
readers: [GB01]
---

The fourth argument: a fictional-nonfictional meditation on meaning-formation and community-formation as simultaneous, mutually dependent projects — the voice of community.

> the complexities of meaning-formation and community-formation as simultaneous, mutually dependent projects

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[It’s a problem that I matter]]
- see · [[Protagonists steal analyses]]
- see · [[Voice of trans community]]
- see · [[Glimmering of trans community]]
- see · [[A problem that I matter]]
- see · [[SOPHIE’s Immaterial]]
- see · [[Trans deaths as resource]]
- see · [[Variance like the Eldar]]
