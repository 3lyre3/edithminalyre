---
type: "concept"
voice: "Correction 25 narrator"
source: thesis
section: "Correction 25"
position: 15.15
stations: [2, 3, 4]
locus: "T0367 · Correction 25"
count: 10
pattern: "attunement|attuned"
kin:
  - "attunement"
  - "perception"
readers: [GB04]
---

The topographers’ variable of perception: too severe an attunement misses the discrepancy; a team must be low enough to see the city and high enough that he go undetected.

> a degree of attunement frankly too severe for retainment in field

- key · [[Sister Aloysius must go to the movies]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Survival is no excuse for atrocity]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[The Topographical Institute]]
- see · [[Schiz beyond the epistemological]]
- see · [[Riots felt in the ley-web]]
- see · [[Pick which opening paragraph]]
- see · [[The tree in earshot]]
- see · [[Higher attunement contracted]]
