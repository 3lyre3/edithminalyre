---
type: "concept"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 11.45
stations: [3, 17, 20]
locus: "T0322 · Quivering Haecceities"
count: 12
pattern: "gignoba"
kin:
  - "genre"
  - "gignobasis"
  - "journeys"
  - "method"
  - "ontology"
readers: [GB03, GB17]
---

A gignobasis told from the dreaming eye’s standpoint within an alternate universe, dragging a more darkly lost dream — of ancient myth — into the synthetic tissue of its reality.

> ‘a journey from unreality to reality, non-existence to existence, or the ontic to the ontological.’

- key · [[Sister Aloysius must go to the movies]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Magic is nature from the future]]
- key · [[There can be a tiger. You won’t let there be]]
- see · [[Braidotti and Bettcher’s negations]]
- see · [[The ontic]]
- see · [[The oneiropomp]]
- see · [[Nonrepresentative allegory]]
- see · [[Right-hand turn, left-hand path]]
- see · [[Cow dead in the mail]]
- see · [[Ontology (Key Terms)]]
- see · [[Maggie Ann Bowers]]
- see · [[Lyre 2021 (Cassandra)]]
