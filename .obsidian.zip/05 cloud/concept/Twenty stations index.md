---
type: "concept"
voice: "E"
source: thesis
section: "Left Hand Realism"
position: 0.45
stations: [1, 19]
locus: "T0043 · Left Hand Realism"
count: 21
pattern: "(?:five|ten|fifteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|one-hundred)(?:-five)? percent"
kin:
  - "thesis structure"
  - "maps"
readers: [GB01]
---

The index of twenty invented titles marking five-percent stations of the running text — Better Lie to Bulls — the reading order E ‘believed made sense’.

> Better Lie · Five Percent · Most Secret Muscle · Ten Percent

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[To live for the future is to live in glimmered moments]]
- see · [[The four secret arguments]]
- see · [[Maplevel marked Atrocity]]
