---
type: "concept"
voice: "Lyre"
source: thesis
section: "Cisness"
position: 1.23
stations: [1, 17]
locus: "T0097 · Cisness"
count: 4
pattern: "contradiction-tolerant|ontically"
kin:
  - "ontology"
  - "cisness"
readers: [GB01]
---

Ontically trans and speculative, logically cis and realist: reality and its alternatives survive across a lexicon that tolerates contradiction.

> reality and its alternatives survive across a contradiction-tolerant lexicon

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Cis realism]]
- see · [[Truth across universes]]
- see · [[Contradiction-tolerant universe]]
- see · [[Gignobasis]]
