---
type: "concept"
voice: "Lyre"
source: thesis
section: "Sun Pink"
position: 52.65
stations: [10]
locus: "T0917 · Sun Pink"
count: 6
pattern: "\\btav\\b|aletheia|veritas|forget revelation"
kin:
  - "truth"
  - "the real"
readers: [GB10]
---

Truth as an agentic force with a name — Tav — curled at the base of the well; emerging into lowercase reality she cannot endure. ‘Forget revelation.’

> the paradox of Gérôme’s revelations is, symbolically, Truth’s departing the Real

- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Velle’s newspaper-clipping moment]]
- see · [[Gesture beyond reality]]
