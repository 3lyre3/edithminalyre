---
type: "concept"
voice: "Lyre"
source: thesis
section: "Left Hand Realism"
position: 0.13
stations: [1, 3, 4, 5, 6, 7, 8, 9, 12]
locus: "T0021 · Left Hand Realism"
count: 46
pattern: "left[- ]hand realis"
kin:
  - "magical realism"
  - "genre"
  - "left hand"
readers: [GB01]
---

Elm’s proposed subgenre of magical realism: Magic the point of departure, the authorial motion toward Realism — the standpoint from which a trans author writes realism as alien laws.

> a subgenre within magical realism characterised by a reversal of the Realism-Magic dialectic

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Gandalf’s left-hand way]]
- see · [[The fork in the road]]
- see · [[The four secret arguments]]
- see · [[Speculative–Realist borderlands]]
- see · [[The trans imaginary]]
- see · [[Gignobasis]]
- see · [[Secular magic]]
- see · [[Author as the mystery]]
- see · [[Coding fantasy into realism]]
- see · [[Epistemology from the trans body]]
- see · [[Why we built the normative]]
- see · [[Not even at the table]]
- see · [[Polygon-stack imitation]]
- see · [[Magic(al) Realism (Bowers)]]
