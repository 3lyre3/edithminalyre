---
type: "concept"
voice: "Lyre"
source: thesis
section: "took the Alexander from Paris and I the Paris from Alexander, what remained of what went of me in the Scamander to buoy again a barbarian enough mannerly for the Priamidi’s fosterage? Who was he?"
position: 61.72
stations: [12]
locus: "T1029 · took the Alexander from Paris and I the Paris from Alexander, what remained of what went of me in the Scamander to buoy again a barbarian enough mannerly for the Priamidi’s fosterage? Who was he?"
count: 3
pattern: "anxiety is consciousness|dasein|anxious emergence"
kin:
  - "ontology"
  - "consciousness"
readers: [GB11]
---

To author is an anxious emergence from the Organism qua Organism — the ontic; anxiety, the power to categorise, authors itself as consciousness; anxiety and authorship are Dasein.

> Anxiety is consciousness and authorship the process by which consciousness identifies itself.

- key · [[Once there were no masters. And yet the house was built]]
- key · [[All was brightness and knowing]]
- see · [[Seeking presence]]
