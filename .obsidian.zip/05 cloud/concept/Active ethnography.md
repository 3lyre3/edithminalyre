---
type: "concept"
voice: "Lyre"
source: thesis
section: "The Still Truth or I Don't See You at All"
position: 39.88
stations: [8]
locus: "T0736 · The Still Truth or I Don't See You at All"
count: 6
pattern: "ethnograph|upright citizen|good standing"
kin:
  - "ethnography"
  - "citizenship"
readers: [GB08]
---

The ethnographer’s local integrations as becoming an upright citizen in good standing with the community under study — ‘Hands up who’s been raped by an upright citizen in good standing.’

> The local integrations undertaken by ethnographers are, give or take, processes by which one becomes an upright citizen in good standing with the community

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- see · [[Watch E go]]
- see · [[Invisible in their own storytelling]]
- see · [[Nanda’s hijra ethnography]]
