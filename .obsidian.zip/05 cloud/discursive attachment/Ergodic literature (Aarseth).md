---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.25
stations: [1]
locus: "T0120 · Coda"
count: 14
pattern: "ergodic|cybertext|aarseth"
weight: major
stance: attaches
kin:
  - "precedents"
  - "labyrinths"
readers: [GB01]
---

Espen Aarseth’s cybertext and ergodic literature — ‘textual machines with unlimited possibility for variation’, the I Ching, the multi-user dungeon — the first cited precedent for the thesis’s complexity.

> If a work is both labyrinthine and adaptable to re-versioning/further creativity, it is ergodic.

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Optimism need not be teleological]]
- see · [[Fictocriticism (Gibbs)]]
- see · [[Metafiction (Gass)]]
- see · [[Borges]]
- see · [[Nabokov’s flying machines]]
- see · [[The archive grows]]
