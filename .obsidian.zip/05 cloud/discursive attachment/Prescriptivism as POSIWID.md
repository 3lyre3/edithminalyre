---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Cisness (2)"
position: 71.84
stations: [3, 7, 11, 15]
locus: "T1109 · Cisness (2)"
count: 9
pattern: "prescriptiv|posiwid|usefulness"
weight: minor
stance: conflicts
kin:
  - "language"
  - "linguistics"
readers: [GB13]
---

The purpose of prescriptivism is what it does — the hindrance of marginalised voices; a word’s currency owes to its usefulness; archives of grammars granted.

> the use of prescriptivism (in a POSIWID/“the purpose of a system is what it does”-sense) is the hindrance of marginalised voices

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Sanitising versus pathologising terms]]
- see · [[Special agonies without language]]
