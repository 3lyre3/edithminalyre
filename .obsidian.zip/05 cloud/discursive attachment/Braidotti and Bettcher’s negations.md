---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 11.57
stations: [3]
locus: "T0327 · Quivering Haecceities"
count: 3
pattern: "braidotti|zoe-|morally saturated"
weight: minor
stance: attaches
kin:
  - "self"
  - "trans theory"
readers: [GB03]
---

‘Self, self, self’: the complaint answered by swapping in Braidotti’s zoe-negation or Bettcher’s ‘morally saturated appearance for others’ — alternatives to the self in gignobasis.

> I could as easily swap in zoe- or “morally saturated appearance for others”-negating.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Talia Mae Bettcher]]
