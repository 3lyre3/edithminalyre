---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.69
stations: [1, 12]
locus: "T0124 · Coda"
count: 13
pattern: "metafiction|\\bgass\\b"
weight: major
stance: attaches
kin:
  - "precedents"
readers: [GB01]
---

William Gass’s coinage — ‘lingos to converse about lingos’; forms of fiction as material for further forms; Borges, Barth, O’Brien, Nabokov — the second precedent.

> the forms of fiction serve as the material upon which further forms can be imposed

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how]]
- see · [[Borges]]
- see · [[Nabokov’s flying machines]]
