---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 12.3
stations: [3, 6, 10, 12, 13]
locus: "T0332 · Quivering Haecceities"
count: 11
pattern: "post-pessimist|jouissant|pessimis"
weight: major
stance: conflicts
kin:
  - "queer theory s limit"
  - "bitter optimism"
readers: [GB03]
---

Queer theory shorn of its pessimist foundations ‘could never’; its pessimisme jouissant set against trans theory’s bitter optimism — the allied relation taken up in Organism Writing.

> Shorn of its pessimist foundations, post-pessimist queer theory could never. Queer literature could never.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Optimism need not be teleological]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Survival-in-power]]
- see · [[Crumbs versus dirt]]
- see · [[Andrea Long Chu]]
