---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 13.8
stations: [3, 7, 8, 9, 14, 17, 18]
locus: "T0347 · Quivering Haecceities"
count: 26
pattern: "dysphoria|gender phoria"
weight: major
stance: conflicts
kin:
  - "dysphoria"
  - "bettcher"
  - "disability"
  - "articulation"
readers: [GB03]
---

Bettcher’s scepticism toward ‘dysphoria’ as a diagnostic term against the thesis’s defence of a bitter-won vocabulary for excruciation — the ‘if some A are not B’ error.

> There is a basic ‘if some A are not B, then no B are A’-logic error in Bettcher’s reasoning.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Survival is no excuse for atrocity]]
- key · [[It’s a problem that I matter]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Benign and malignant tumours]]
- see · [[Trans–disabled solidarities]]
- see · [[Desert Eternal diagnostics]]
- see · [[Even more like a woman]]
- see · [[Psychosomatic certainty]]
- see · [[Imaginary sickness]]
- see · [[Mental ailment no one sees]]
- see · [[Ankylosing spondylitis]]
- see · [[Transness as Debility (Baril)]]
