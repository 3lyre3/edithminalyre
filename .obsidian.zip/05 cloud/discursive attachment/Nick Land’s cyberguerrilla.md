---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 21.66
stations: [5, 6, 20]
locus: "T0435 · Key Terms"
count: 7
pattern: "nick land|cyberguerrilla|circuitries|land \\(who is cis\\)"
weight: minor
stance: attaches
kin:
  - "time travel"
  - "cisness"
readers: [GB04]
---

Circuitries (2001): smuggled back out of the future in human camouflage — Land, who is cis, momentarily achieving a simulation of trans experience the author regrets she can’t dodge.

> How would it feel to be smuggled back out of the future in order to subvert its antecedent conditions?

- key · [[Magic is nature from the future]]
- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- see · [[Stranded-in-the-past time-traveller]]
- see · [[David Harvey]]
- see · [[I’m from the future]]
- see · [[Cis hermeneutics]]
