---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.46
stations: [1, 2, 12, 13, 20]
locus: "T0121 · Coda"
count: 53
pattern: "fictocritic|\\bgibbs\\b"
weight: major
stance: extends
kin:
  - "precedents"
  - "method"
readers: [GB01]
---

Anna Gibbs’s fictocriticism — ‘writing as research’, ‘a precise and local intervention’ — the third precedent, which the ergodic picture of False Cows does not quite square with.

> Gibbs’s description of the fictocritical text as “a precise and local intervention” (2005)? Not really, no.

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Fictoanalysis]]
- see · [[Metafiction (Gass)]]
- see · [[Borges]]
- see · [[Nabokov’s flying machines]]
