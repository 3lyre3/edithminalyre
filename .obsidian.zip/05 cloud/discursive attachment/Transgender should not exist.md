---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Cisness (2)"
position: 73.21
stations: [15]
locus: "T1124 · Cisness (2)"
count: 4
pattern: "transgender[”\"]? should not|multimillionaires|new england|popular genesis"
weight: major
stance: conflicts
kin:
  - "terminology"
  - "history"
  - "transsexuality"
readers: [GB13]
---

‘Transgender’ born among New England multimillionaires flagging their fluidity — refurbishing a few for a cis public, which took it as the new ‘transsexual’, then as attachable to itself.

> I might as well put the argument in my own words: “transgender” should not exist.

- key · [[Gill-Peterson underestimates the arcane potential of stamps on paper]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Clean, reversible, makeup-removable]]
- see · [[Checking In]]
- see · [[Transgenderists as avatars]]
- see · [[Rainforest under the Sink]]
- see · [[Compulsory transsexuality]]
