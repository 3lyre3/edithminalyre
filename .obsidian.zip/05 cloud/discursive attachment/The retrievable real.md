---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 19.84
stations: [4, 7]
locus: "T0424 · Key Terms"
count: 7
pattern: "retrievable|illimitable|recognisable|recognise in relation"
weight: major
stance: conflicts
kin:
  - "magical realism"
  - "genre"
  - "the real"
readers: [GB04]
---

Bowers and Scholes presume a retrievable, illimitable real known to them and their critics; to the left hand realist ‘recognisable’, ‘material’ and ‘reality’ are already anxieties.

> their presumption of a retrievable and illimitable real – and indeed, and most importantly, a real known both to them and the critics they reference

- key · [[Survival is no excuse for atrocity]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Philip K. Dick]]
- see · [[Secular magic]]
- see · [[Franz Roh’s magischer Realismus]]
- see · [[The Real (More Terms)]]
