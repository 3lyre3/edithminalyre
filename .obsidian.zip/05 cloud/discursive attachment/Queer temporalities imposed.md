---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Coda"
position: 3.25
stations: [1, 6]
locus: "T0120 · Coda"
count: 4
pattern: "temporalit|temporal order"
weight: major
stance: conflicts
kin:
  - "queer temporality"
  - "queer theory s limit"
readers: [GB01]
---

The queer-but-not-trans subject’s temporalities and temporal orders impose themselves on the thesis’s structure and on trans lives; the thesis resents being seen as of them.

> the queer but not trans subject whose temporalities and temporal orders impose themselves on the structure of both this thesis and our lives

- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- key · [[Optimism need not be teleological]]
- see · [[Trans versus queer imaginary]]
- see · [[David Harvey]]
- see · [[Queer Time and Place]]
- see · [[Counterpublics]]
