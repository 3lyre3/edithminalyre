---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "The Still Truth or I Don't See You at All"
position: 40.27
stations: [1, 8, 17, 18, 19]
locus: "T0740 · The Still Truth or I Don't See You at All"
count: 26
pattern: "nanda|neither man nor woman"
weight: major
stance: conflicts
kin:
  - "bhatt"
  - "hijra"
  - "ethnography"
readers: [GB08]
---

Nanda’s Neither Man Nor Woman: ‘I am a woman’ recorded verbatim, then ‘a religious community of men who dress and act like women’; ‘Can you give birth?’ as evidence.

> the voice of the oppressing hegemony is the only voice and must, therefore, be the intended expression of the tale

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Lord Mousefrog]]
- see · [[Invisible in their own storytelling]]
