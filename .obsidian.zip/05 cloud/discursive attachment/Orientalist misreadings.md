---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "The Still Truth or I Don't See You at All"
position: 39.64
stations: [8]
locus: "T0735 · The Still Truth or I Don't See You at All"
count: 7
pattern: "orientalis|exoticis|per said"
weight: major
stance: intervenes
kin:
  - "orientalism"
  - "spectacle"
  - "ethnography"
readers: [GB08]
---

Representations of dysphoria and third genders in non-Western contexts exoticised as spectacle, per Said — but spectacles hide within spectacles, othered by local systems before the anthropologists arrive.

> Yet, spectacles hide within spectacles.

- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[To get horror, combine spectacle and illegibility]]
- see · [[Talia Bhatt]]
- see · [[Active ethnography]]
- see · [[Nanda’s hijra ethnography]]
- see · [[The mundane occluded by spectacle]]
- see · [[Illegibility and spectacle]]
- see · [[Invisible in their own storytelling]]
