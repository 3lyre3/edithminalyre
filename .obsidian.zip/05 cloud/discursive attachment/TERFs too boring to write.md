---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "1.9"
position: 28.51
stations: [6, 8, 9, 15]
locus: "T0555 · 1.9"
count: 10
pattern: "\\bterfs?\\b|gender reveal|tuck woodstock"
weight: minor
stance: intervenes
kin:
  - "terfs"
  - "public argument"
  - "the too real"
readers: [GB06]
---

Felker-Martin on real TERFs: single-minded, thuddingly dull-witted, mundane to the point of unspeakability — written complex or they’d be too boring to believe.

> you can’t just show the single-minded thuddingly dull-witted way that real TERFs act

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Should I lie and write so-called realism or tell the truth and write so-called speculative fiction]]
- see · [[Getting too real]]
