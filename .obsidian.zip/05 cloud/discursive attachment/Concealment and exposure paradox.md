---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 13.03
stations: [3]
locus: "T0341 · Quivering Haecceities"
count: 3
pattern: "malicious concealment|indecent exposure|proper appearance"
weight: major
stance: extends
kin:
  - "bettcher"
  - "secrets"
  - "presentation"
readers: [GB03]
---

Bettcher: proper appearance must hide the information it also provides — gendered performance announces and covers the genitals; trans people punished for malicious concealment and indecent exposure.

> Trans people are simultaneously, thus, punished for malicious concealment and indecent exposure.

- key · [[Sister Aloysius must go to the movies]]
- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[Talia Mae Bettcher]]
- see · [[Overworld and underworld]]
- see · [[Lugones’s ontological pluralism]]
- see · [[The dysphoria dispute]]
- see · [[Secret hope]]
- see · [[Boymode and mascara]]
- see · [[Dear Amaldéu (presentation)]]
- see · [[Nineteen things]]
- see · [[Exit — why Bunnings]]
