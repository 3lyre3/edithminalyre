---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "1.9"
position: 29.51
stations: [6, 13]
locus: "T0577 · 1.9"
count: 5
pattern: "twin that queer|ate in the womb|warmed-over pieties|is strife"
weight: major
stance: extends
kin:
  - "chu"
  - "queer theory s limit"
readers: [GB06]
---

Chu: ‘Trans studies is the twin that queer studies ate in the womb. (The womb, as usual, was feminism.)’ — warmed-over pieties, church; what matters for theory-building is strife.

> Trans studies is the twin that queer studies ate in the womb. (The womb, as usual, was feminism.)

- key · [[Obsessive recitation of the real cannot change it]]
- key · [[Optimism need not be teleological]]
- key · [[It’s a problem that I matter]]
- key · [[Sister Aloysius must go to the movies]]
- see · [[After Trans Studies]]
