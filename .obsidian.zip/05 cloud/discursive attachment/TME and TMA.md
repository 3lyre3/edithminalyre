---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "the Dark Materials"
position: 49.92
stations: [9]
locus: "T0864 · the Dark Materials"
count: 6
pattern: "\\btme\\b|\\btma\\b|transmisogyny-exempt|non-transfem"
weight: major
stance: attaches
kin:
  - "transmisogyny"
  - "intracommunity discourse"
readers: [GB09]
---

The transfem/non-transfem intracommunity discourse: transmisogyny-exempt versus -affected; non-transfems more mobile in queer spaces and better able to control narratives of transness.

> non-transfems are transmisogyny-exempt and transfems are transmisogyny-affected (TME and TMA)

- key · [[To live for the future is to live in glimmered moments]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Imogen Binnie’s Nevada]]
- see · [[Julia Serano]]
- see · [[Trans masc hermeneutic]]
- see · [[Halberstam’s tranny]]
- see · [[Trans men are the men]]
- see · [[Isabel Fall]]
- see · [[Women who were men]]
- see · [[Transfeminine belonging as unattractive]]
- see · [[Nine parts to one]]
- see · [[Judith Butler on trans women]]
- see · [[Kai Green and Marquis Bey]]
