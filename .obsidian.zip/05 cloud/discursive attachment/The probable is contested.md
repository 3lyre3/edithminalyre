---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "No, no Tiger"
position: 77.31
stations: [3, 16]
locus: "T1213 · No, no Tiger"
count: 9
pattern: "probable|occur very rarely|running the numbers|false memory"
weight: major
stance: conflicts
kin:
  - "probability"
  - "anti trans politics"
readers: [GB14]
---

Trump (29 Jan 2025): transition should ‘occur very rarely’ — anti-trans advocacy’s message: not probable that you are trans; cis and trans alike running the numbers.

> This is the overriding message of anti-trans advocacy: it is not probable that so many of you are trans.

- key · [[That’s all the bars are, Mr Losse. They’re honesty]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- key · [[Survival is no excuse for atrocity]]
- see · [[Unshareably great destiny]]
