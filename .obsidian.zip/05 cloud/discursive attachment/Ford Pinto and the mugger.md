---
type: "discursive attachment"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 8.23
stations: [2]
locus: "T0258 · Faerieland"
count: 3
pattern: "pinto|mugger|airliners"
weight: minor
stance: attaches
kin:
  - "responsibility"
  - "public argument"
readers: [GB02]
---

The mugger has the gun, airliners brought the towers down, Ford held no obligation to reinforce the Pinto — public arguments about where blame properly lands.

> Ford held no obligation to reinforce the Pinto rear engine

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
- see · [[I was twelve]]
- see · [[That’s America]]
- see · [[Towers by their own weight]]
- see · [[Keeping suffering in play]]
- see · [[TERFs too boring to write]]
- see · [[Symptom not agent]]
