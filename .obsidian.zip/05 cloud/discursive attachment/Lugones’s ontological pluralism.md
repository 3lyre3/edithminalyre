---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Quivering Haecceities"
position: 13.54
stations: [3]
locus: "T0346 · Quivering Haecceities"
count: 2
pattern: "lugones|ontological pluralism"
weight: minor
stance: attaches
kin:
  - "worlds"
  - "bettcher"
readers: [GB03]
---

Bettcher’s solder of María Lugones’s ontological pluralism onto the trans ontic — the archipelago of enclaves and exclaves — lends the thesis crucial support.

> the first aesthetic solder of María Lugones’s ontological pluralism onto the scaffold of the trans ontic

- key · [[Sister Aloysius must go to the movies]]
- key · [[In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’]]
- see · [[The dysphoria dispute]]
- see · [[Maplevels]]
- see · [[Christ on this maplevel]]
- see · [[Elysicester]]
