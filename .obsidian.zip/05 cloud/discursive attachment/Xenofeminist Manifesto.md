---
type: "discursive attachment"
voice: "Lyre"
source: thesis
section: "Key Terms"
position: 21.3
stations: [5, 20]
locus: "T0434 · Key Terms"
count: 7
pattern: "xenofeminis|cuboniks|if nature is unjust"
weight: major
stance: conflicts
kin:
  - "nature"
  - "justice"
  - "prophecy"
readers: [GB04]
---

Laboria Cuboniks (2015): ‘If nature is unjust, change nature’ — a philosophical outrage unless heard as an instruction to the universe: a prophecy that nature is always-already just.

> no more can nature be unjust than can mathematics be un-Ten

- key · [[Magic is nature from the future]]
- key · [[Provable but unspeakable truths are the seed and mechanism of prophecy]]
- see · [[Nature always-already just]]
- see · [[Magic and technology undelineated]]
- see · [[Dante’s falsa vacca]]
- see · [[Velle’s newspaper-clipping moment]]
- see · [[And Reconciliation, explained]]
