---
type: "discursive attachment"
voice: "Bryth"
source: thesis
section: "Faerieland"
position: 6.36
stations: [2, 3]
locus: "T0233 · Faerieland"
count: 7
pattern: "believe women|women accusing women|fae accusing"
weight: major
stance: conflicts
kin:
  - "accusation"
  - "feminism"
readers: [GB02]
---

‘Believe women’ — great for the Uplands’ tidy division, but here it’s fae accusing fae, or women accusing women; the principle meets communities without the division it assumes.

> “Here it’s fae accusing fae. Or in aufGaolaí communities, often enough still, it’s women accusing women.”

- key · [[Every muscle that counts for anything keeps itself a secret]]
- key · [[Survival is no excuse for atrocity]]
- see · [[The therapist]]
- see · [[Mutual accusation]]
- see · [[The therapist tweet]]
- see · [[Night]]
- see · [[Not enough woman]]
