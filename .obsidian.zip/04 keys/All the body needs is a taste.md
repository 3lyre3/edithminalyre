---
ring: key
old_number: 18
handoff_range: "85,001–90,000"
arc: "Nature, Yet"
category: "Red Light Necropolis"
chunks: 12
station: 19
position: 94.26
span: "92.68–96.16"
---

“All the body needs is a taste”

> …a real sickness-amount. Belief's worth peanuts. All their bodies need's a taste. Why sicken themselves outside what's needed?"…

*in situ · station 19 of 20 · 94.26% of the running text · span 92.68–96.16%*

- hub · [[o aufÝfua]]