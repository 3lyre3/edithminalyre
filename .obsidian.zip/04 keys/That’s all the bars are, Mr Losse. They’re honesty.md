---
ring: key
old_number: 15
handoff_range: "70,001–75,000"
arc: "My Body’s Another"
category: "New Francisco Beat"
chunks: 11
station: 16
position: 75.3
span: "73.34–78.02"
---

“That’s all the bars are, Mr Losse. They’re honesty”

> …honesty is excessive. Be honest yourself. That's all the bars are, Mr Losse. They're honesty." Whenever she said 'you' she…

*in situ · station 16 of 20 · 75.3% of the running text · span 73.34–78.02%*

- hub · [[o aufÝfua]]