---
ring: key
old_number: 17
handoff_range: "80,001–85,000"
arc: "Mattering"
category: "God’s Police"
chunks: 9
station: 18
position: 91.1
span: "85.92–92.68"
---

“In stillness, all is clean”

> …coursing vertical. Warmth drains. The long sea freezes. In stillness, all is clean. Nothing is dust nor has dust…

*in situ · station 18 of 20 · 91.1% of the running text · span 85.92–92.68%*

- hub · [[o aufÝfua]]