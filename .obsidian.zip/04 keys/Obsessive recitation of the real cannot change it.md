---
ring: key
old_number: 6
handoff_range: "25,001–30,000"
arc: "Nature, Yet"
category: "Undo undo Undo undo un…"
chunks: 8
station: 6
position: 28.41
span: "25.06–30.44"
---

“Obsessive recitation of the real cannot change it”

> …– knows it. Her obsessive recitation of the real cannot change it, however, only intensifying it to a point of…

*in situ · station 6 of 20 · 28.41% of the running text · span 25.06–30.44%*

- hub · [[o aufÝfua]]