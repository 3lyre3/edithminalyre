---
ring: key
old_number: 1
handoff_range: "1–5,000"
arc: "Left Hand Realism"
category: "Better Lie"
chunks: 10
station: 1
position: 1.05
span: "0–4.07"
---

“Should I lie and write so-called realism or tell the truth and write so-called speculative fiction”

> …they are imperilled: should I lie and write so-called realism or tell the truth and write so-called speculative fiction? Left…

*in situ · station 1 of 20 · 1.05% of the running text · span 0–4.07%*

- hub · [[o aufÝfua]]