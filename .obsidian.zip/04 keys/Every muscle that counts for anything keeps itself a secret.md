---
ring: key
old_number: 2
handoff_range: "5,001–10,000"
arc: "Left Hand Realism"
category: "Most Secret Muscle"
chunks: 10
station: 2
position: 7.08
span: "4.07–9.61"
---

“Every muscle that counts for anything keeps itself a secret”

> …can't. Every muscle that counts for anything keeps itself a secret. 'Stop, stop.' No like really stop.…

*in situ · station 2 of 20 · 7.08% of the running text · span 4.07–9.61%*

- hub · [[o aufÝfua]]