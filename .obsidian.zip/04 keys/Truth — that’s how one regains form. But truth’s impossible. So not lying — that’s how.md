---
ring: key
old_number: 11
handoff_range: "50,001–55,000"
arc: "Left Hand Realism"
category: "A Woman Regains Form"
chunks: 14
station: 11
position: 54.54
span: "53.92–58.08"
---

“Truth — that’s how one regains form. But truth’s impossible. So not lying — that’s how”

> …wriggling of a fingertip. Truth: that's how one regains form. But truth's impossible. So not lying: that's how.…

*in situ · station 11 of 20 · 54.54% of the running text · span 53.92–58.08%*

- hub · [[o aufÝfua]]