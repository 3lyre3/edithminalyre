---
ring: key
old_number: 14
handoff_range: "65,001–70,000"
arc: "Nature, Yet"
category: "The Blesses-Devils-Magics Registry"
chunks: 12
station: 15
position: 71.38
span: "69.47–73.34"
---

“Gill-Peterson underestimates the arcane potential of stamps on paper”

> …bear no role in my "deep-rooted, interior … identity." But Gill-Peterson understates the terrible, arcane potency of stamps…

*in situ · station 15 of 20 · 71.38% of the running text · span 69.47–73.34%*

- hub · [[o aufÝfua]]