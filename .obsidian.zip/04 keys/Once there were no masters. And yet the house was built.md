---
ring: key
old_number: 12
handoff_range: "55,001–60,000"
arc: "My Body’s Another"
category: "A Doll’s Universe"
chunks: 5
station: 12
position: 61.62
span: "58.08–63.13"
---

“Once there were no masters. And yet the house was built”

> …were no masters, and yet the house was built. Most do not write toward normativity as is, but toward an…

*in situ · station 12 of 20 · 61.62% of the running text · span 58.08–63.13%*

- hub · [[o aufÝfua]]