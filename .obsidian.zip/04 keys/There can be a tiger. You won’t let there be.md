---
ring: key
old_number: 19
handoff_range: "90,001–93,160"
arc: "My Body’s Another"
category: "Bulls"
chunks: 15
station: 20
position: 98.05
span: "96.16–100"
---

“There can be a tiger. You won’t let there be”

> …never let you ride were it not safe." Children need lies. After all there can be a tiger.…

*in situ · station 20 of 20 · 98.05% of the running text · span 96.16–100%*

- hub · [[o aufÝfua]]