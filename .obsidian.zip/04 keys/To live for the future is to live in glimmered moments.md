---
ring: key
old_number: 9
handoff_range: "40,001–45,000"
arc: "Nature, Yet"
category: "Breathe & Dive"
chunks: 10
station: 9
position: 47.48
span: "43.61–50.39"
---

“To live for the future is to live in glimmered moments”

> …things evident only after scrutiny, such that to live for utopia one must live in flickered moments, so do…

*in situ · station 9 of 20 · 47.48% of the running text · span 43.61–50.39%*

- hub · [[o aufÝfua]]