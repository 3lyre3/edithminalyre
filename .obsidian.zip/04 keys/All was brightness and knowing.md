---
ring: key
old_number: 13
handoff_range: "60,001–65,000"
arc: "My Body’s Another"
category: "The Pure Light of Love"
chunks: 14
station: 14
position: 67.55
span: "66.09–69.47"
---

“All was brightness and knowing”

> …eye. Gained and gained from fifteen on. All was brightness and knowing. A kind of rottenness and evil had, by…

*in situ · station 14 of 20 · 67.55% of the running text · span 66.09–69.47%*

- hub · [[o aufÝfua]]