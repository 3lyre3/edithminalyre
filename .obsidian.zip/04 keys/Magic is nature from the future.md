---
ring: key
old_number: 5
handoff_range: "20,001–25,000"
arc: "Nature, Yet"
category: "A Future for Animals"
chunks: 8
station: 5
position: 21.72
span: "19.87–25.06"
---

“Magic is nature from the future”

> …nature, as here magic is nothing other than nature from the future. E.G: "I am not my…

*in situ · station 5 of 20 · 21.72% of the running text · span 19.87–25.06%*

- hub · [[o aufÝfua]]