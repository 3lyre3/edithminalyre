---
ring: key
old_number: 16
handoff_range: "75,001–80,000"
arc: "Mattering"
category: "Doctor-Prescribed Service Husband"
chunks: 9
station: 17
position: 80.74
span: "78.02–85.92"
---

“To get horror, combine spectacle and illegibility”

> …another in everyday life. (2013) This simultaneity of illegibility and spectacle allows for the production of horror…

*in situ · station 17 of 20 · 80.74% of the running text · span 78.02–85.92%*

- hub · [[o aufÝfua]]