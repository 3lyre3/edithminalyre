---
ring: key
old_number: 4
handoff_range: "15,001–20,000"
arc: "Mattering"
category: "Why Survive"
chunks: 17
station: 4
position: 18.02
span: "15.08–19.87"
---

“Survival is no excuse for atrocity”

> …of their own. Survival is no excuse for atrocity: one of our institute's oldest principles, one we must treasure.…

*in situ · station 4 of 20 · 18.02% of the running text · span 15.08–19.87%*

- hub · [[o aufÝfua]]