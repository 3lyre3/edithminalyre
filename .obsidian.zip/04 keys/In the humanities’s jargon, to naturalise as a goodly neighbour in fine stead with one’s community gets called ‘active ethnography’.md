---
ring: key
old_number: 8
handoff_range: "35,001–40,000"
arc: "My Body’s Another"
category: "Oath Day Blood Offering"
chunks: 11
station: 8
position: 39.75
span: "36.11–43.61"
---

“In the humanities’s jargon, to naturalise as a goodly neighbour in fine stead with one’s community gets called ‘active ethnography’”

> …integrations undertaken by ethnographers are, give or take, processes by which one becomes an upright citizen in good standing…

*in situ · station 8 of 20 · 39.75% of the running text · span 36.11–43.61%*

- hub · [[o aufÝfua]]