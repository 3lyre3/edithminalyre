---
ring: key
old_number: 3
handoff_range: "10,001–15,000"
arc: "Mattering"
category: "Mother Aloysius’s Top 6 Movies"
chunks: 8
station: 3
position: 12.14
span: "9.61–15.08"
---

“Sister Aloysius must go to the movies”

> …Sister Aloysius must go to the movies. Meanwhile, queer art-theory (Halberstam 2011): '[In] Chicken Run, a film…

*in situ · station 3 of 20 · 12.14% of the running text · span 9.61–15.08%*

- hub · [[o aufÝfua]]