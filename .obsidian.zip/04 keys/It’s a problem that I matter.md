---
ring: key
old_number: 7
handoff_range: "30,001–35,000"
arc: "Mattering"
category: "Good Things Happen"
chunks: 12
station: 7
position: 32.47
span: "30.44–36.11"
---

“It’s a problem that I matter”

> …I matter, but maybe it's a problem that I matter, because it's good when things get done well –…

*in situ · station 7 of 20 · 32.47% of the running text · span 30.44–36.11%*

- hub · [[o aufÝfua]]